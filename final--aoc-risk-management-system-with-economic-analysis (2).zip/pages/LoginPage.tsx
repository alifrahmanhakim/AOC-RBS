
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth, MOCK_USER_PROFILES } from '../contexts/AuthContext';
import { PlaneIcon } from '../components/icons'; // Assuming you have a PlaneIcon or similar
import toast from 'react-hot-toast';

export const LoginPage: React.FC = () => {
  const [selectedUserId, setSelectedUserId] = useState<string>(MOCK_USER_PROFILES.length > 0 ? MOCK_USER_PROFILES[0].id : '');
  const { login, authError, isAuthLoading } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUserId) {
      toast.error('Please select a user profile to login.');
      return;
    }
    const success = login(selectedUserId);
    if (success) {
      toast.success('Login successful!');
      navigate('/');
    } else {
      // AuthError will be set by useAuth context, potentially shown in header or here
      toast.error(authError || 'Login failed. Please try again.');
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-200px)] px-4">
      <div className="w-full max-w-md bg-white p-8 rounded-xl shadow-2xl">
        <div className="flex flex-col items-center mb-6">
          <PlaneIcon className="h-16 w-16 text-brand-primary mb-3" />
          <h1 className="text-2xl font-bold text-slate-800">Welcome</h1>
          <p className="text-slate-600 text-sm">Select a profile to access the AOC Risk Management System.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="userProfile" className="block text-sm font-medium text-slate-700 mb-1">
              Select User Profile (Simulated Login)
            </label>
            <select
              id="userProfile"
              value={selectedUserId}
              onChange={(e) => setSelectedUserId(e.target.value)}
              className="w-full p-3 border border-slate-300 rounded-lg shadow-sm focus:ring-2 focus:ring-brand-secondary focus:border-transparent outline-none bg-white"
              required
            >
              {MOCK_USER_PROFILES.map(profile => (
                <option key={profile.id} value={profile.id}>
                  {profile.displayName} ({profile.role})
                </option>
              ))}
            </select>
          </div>

          {authError && (
            <p className="text-xs text-red-500 bg-red-50 p-2 rounded-md border border-red-200">{authError}</p>
          )}

          <div>
            <button
              type="submit"
              disabled={isAuthLoading}
              className="w-full flex justify-center items-center px-4 py-3 bg-brand-primary hover:bg-blue-800 text-white font-semibold rounded-lg shadow-md hover:shadow-lg transition-all disabled:opacity-70"
            >
              {isAuthLoading ? 'Logging in...' : 'Login'}
            </button>
          </div>
        </form>
         <p className="mt-6 text-xs text-center text-slate-500">
          This is a simulated login for demonstration purposes. No actual authentication is performed.
        </p>
      </div>
    </div>
  );
};
