
import React, { useState, useRef, useMemo, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useOperators } from '../hooks/useOperators';
import { OperatorCard } from '../components/OperatorCard';
import { PlusIcon, ChartBarIcon, UploadIcon, DownloadIcon, UserGroupIcon, ClipboardDocumentCheckIcon, ClockIcon, AcademicCapIcon, ChartPieIcon, ExclamationTriangleIcon, InformationCircleIcon } from '../components/icons'; // Fixed import
import { LoadingSpinner } from '../components/shared/LoadingSpinner';
import { Operator, RiskLevel, DEFAULT_COMPLEXITY_FACTORS, DEFAULT_COMPLIANCE_DATA, DEFAULT_DEVIATION_DATA, DEFAULT_IMPROVEMENT_DATA, DEFAULT_LEGACY_RISK_FACTORS, ComplexityFactors, ComplianceData, DeviationData, ImprovementData, LegacyRiskFactors, ComplianceFindingCounts, SurveillanceFinding, FindingCategoryLevel, ExposureLevel, UserRole } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend as RechartsLegend, ResponsiveContainer, Cell, PieChart, Pie, Legend } from 'recharts'; // Added PieChart, Pie, Legend for new chart
import { CHART_HEX_RISK_LEVEL_COLORS, CHART_HEX_EXPOSURE_LEVEL_COLORS } from '../constants'; // Added CHART_HEX_EXPOSURE_LEVEL_COLORS
import toast from 'react-hot-toast';
import { GoogleGenAI, GenerateContentResponse } from '@google/genai';
import { exportToJSON } from '../utils/exportUtils';
import { useAuth } from '../contexts/AuthContext'; // Import useAuth

// Helper to map Risk Indicator Level (1-5) to a general RiskLevel for color consistency
const mapIndicatorToRiskLevel = (indicatorLevel: number): RiskLevel => {
    if (indicatorLevel === 1) return RiskLevel.LOW;
    if (indicatorLevel === 2) return RiskLevel.MEDIUM;
    if (indicatorLevel === 3) return RiskLevel.MEDIUM;
    if (indicatorLevel === 4) return RiskLevel.HIGH;
    if (indicatorLevel === 5) return RiskLevel.CRITICAL;
    return RiskLevel.LOW;
};

interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ReactElement<React.SVGProps<SVGSVGElement>>;
  description?: string;
  colorClass?: string;
}

const StatCard: React.FC<StatCardProps> = ({ title, value, icon, description, colorClass = "text-brand-primary" }) => (
  <div className="bg-slate-50 p-4 rounded-lg shadow flex items-start">
    <div className={`mr-4 p-2.5 rounded-full bg-brand-secondary/20 ${colorClass}`}>
      {React.cloneElement(icon, { className: "h-5 w-5" })}
    </div>
    <div>
      <h4 className="text-sm font-medium text-slate-500">{title}</h4>
      <p className="text-2xl font-bold text-slate-700">{value}</p>
      {description && <p className="text-xs text-slate-400">{description}</p>}
    </div>
  </div>
);


export const DashboardPage: React.FC = () => {
  const { operators, addOperator } = useOperators();
  const { currentUser } = useAuth(); // Get current user for role-based access
  const [searchTerm, setSearchTerm] = useState('');
  const [isImporting, setIsImporting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [aiDashboardClient, setAiDashboardClient] = useState<GoogleGenAI | null>(null);
  const [aiAdvisory, setAiAdvisory] = useState('');
  const [isAiAdvisoryLoading, setIsAiAdvisoryLoading] = useState(false);
  const [aiAdvisoryError, setAiAdvisoryError] = useState<string | null>(null);
  const API_KEY = process.env.API_KEY;

  const [exposureChartReady, setExposureChartReady] = useState(false);
  const exposureChartContainerRef = useRef<HTMLDivElement>(null);

  const isAdmin = currentUser?.role === UserRole.ADMIN;


  useEffect(() => {
    if (API_KEY) {
      try {
        const client = new GoogleGenAI({ apiKey: API_KEY });
        setAiDashboardClient(client);
        setAiAdvisoryError(null);
      } catch (error) {
        console.error("Failed to initialize GoogleGenAI client for dashboard:", error);
        setAiAdvisoryError("Failed to initialize AI client. Check API key configuration.");
        setAiDashboardClient(null);
      }
    } else {
      setAiDashboardClient(null);
    }
  }, [API_KEY]);

  useEffect(() => {
    let timerId: number | null = null;

    const attemptSetReady = () => {
      const chartContainer = exposureChartContainerRef.current;
      if (chartContainer && chartContainer.offsetWidth > 0 && chartContainer.offsetHeight > 0) {
        setExposureChartReady(true);
      } else {
        timerId = window.setTimeout(attemptSetReady, 100);
      }
    };

    attemptSetReady(); // Initial attempt

    return () => {
      if (timerId) {
        clearTimeout(timerId);
      }
    };
  }, []); // Empty dependency array, runs once on mount.


  const filteredOperators = useMemo(() => {
    return operators.filter(op => {
      const matchesSearchTerm = op.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                                op.aocNumber.toLowerCase().includes(searchTerm.toLowerCase());
      if (!matchesSearchTerm) return false;

      if (isAdmin) return true; // Admin sees all operators matching search

      // Restricted user filtering
      if (currentUser?.role === UserRole.RESTRICTED_USER) {
        if (currentUser.managesOperatorNameContaining) {
          return op.name.toLowerCase().includes(currentUser.managesOperatorNameContaining.toLowerCase());
        }
        return true; // If no specific filter, restricted user sees all (can be adjusted)
      }
      return false; // Default deny
    }).sort((a,b) => {
      if (a.riskIndicatorLevel !== b.riskIndicatorLevel) {
          return b.riskIndicatorLevel - a.riskIndicatorLevel;
      }
      return a.overallPerformanceScore - b.overallPerformanceScore;
    });
  }, [operators, searchTerm, currentUser, isAdmin]);


  const chartData = useMemo(() => {
    return filteredOperators.map(op => ({
      name: op.name.length > 15 ? op.name.substring(0,12) + '...' : op.name,
      performanceScore: op.overallPerformanceScore * 100,
      fill: CHART_HEX_RISK_LEVEL_COLORS[mapIndicatorToRiskLevel(op.riskIndicatorLevel)],
      riskIndicatorLevel: op.riskIndicatorLevel,
      exposureLevel: op.exposureLevel
    })).sort((a,b) => {
      if (a.riskIndicatorLevel !== b.riskIndicatorLevel) {
          return b.riskIndicatorLevel - a.riskIndicatorLevel;
      }
      return a.performanceScore - b.performanceScore;
    }).slice(0,10);
  }, [filteredOperators]);


  const keyMetrics = useMemo(() => {
    // Key metrics should be based on the operators the current user can see
    const relevantOperators = filteredOperators;
    const totalOperators = relevantOperators.length;
    let totalOccurrences = 0;
    let totalFindings = 0;
    let openFindings = 0;
    let totalSurveillanceCycleMonths = 0;
    const exposureLevelCounts: Record<ExposureLevel, number> = { [ExposureLevel.A]: 0, [ExposureLevel.B]: 0, [ExposureLevel.C]: 0, [ExposureLevel.D]: 0, [ExposureLevel.E]: 0 };

    relevantOperators.forEach(op => {
      totalOccurrences += op.legacyRiskFactors.occurrences.length;
      totalFindings += op.surveillanceFindings?.length || 0;
      openFindings += op.surveillanceFindings?.filter(sf => !sf.isCompleted).length || 0;
      totalSurveillanceCycleMonths += op.suggestedSurveillanceCycleMonths;
      if (op.exposureLevel) {
        exposureLevelCounts[op.exposureLevel]++;
      }
    });

    const avgSurveillanceCycle = totalOperators > 0 ? (totalSurveillanceCycleMonths / totalOperators).toFixed(1) : 'N/A';

    return {
      totalOperators,
      totalOccurrences,
      totalFindings,
      openFindings,
      avgSurveillanceCycle,
      exposureLevelCountsArray: Object.entries(exposureLevelCounts).map(([name, value]) => ({ name: `Level ${name}`, value, fill: CHART_HEX_EXPOSURE_LEVEL_COLORS[name as ExposureLevel] }))
    };
  }, [filteredOperators]);


  const handleImportButtonClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsImporting(true);
    const toastId = 'json-import';
    toast.loading('Importing JSON...', { id: toastId });

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const text = e.target?.result;
        if (typeof text !== 'string') {
          throw new Error('Failed to read file content.');
        }
        const data = JSON.parse(text);

        if (!Array.isArray(data)) {
          throw new Error('Invalid JSON format: Not an array of operators.');
        }

        let importedCount = 0;
        let skippedCount = 0;
        
        (data as Partial<Operator>[]).forEach((op, index) => {
          if (!op.name || !op.aocNumber) {
            toast.error(`Item ${index + 1}: Skipped. Operator Name and AOC Number are required.`);
            skippedCount++;
            return;
          }

          // Sanitize financialReportSources to ensure it only contains valid GroundingSource objects
          if (op.financialReportSources && Array.isArray(op.financialReportSources)) {
              op.financialReportSources = op.financialReportSources.filter(source => 
                  typeof source === 'object' && source !== null && 'uri' in source && 'title' in source
              );
          }
          
          try {
            // The addOperator function expects a specific partial type, but passing a full Operator object is fine.
            // Using 'as any' to avoid type mismatch on a complex partial type.
            addOperator(op as any);
            importedCount++;
          } catch (err: any) {
            toast.error(`Error adding operator "${op.name || `item ${index + 1}`}": ${err.message}`);
            skippedCount++;
          }
        });

        if (importedCount > 0) {
          toast.success(`${importedCount} operator(s) imported successfully.`, { id: toastId });
        } else {
          toast.dismiss(toastId);
        }

        if (skippedCount > 0) {
          toast.error(`${skippedCount} item(s) could not be imported. Please check file format and content.`);
        }
        
        if (data.length === 0 && importedCount === 0) {
            toast.success('JSON file appears to be empty.');
        }

      } catch (error: any) {
        toast.error(`Import Failed: ${error.message}`, { id: toastId });
      } finally {
        setIsImporting(false);
        // Reset file input so the same file can be re-uploaded
        if (fileInputRef.current) {
          fileInputRef.current.value = '';
        }
      }
    };
    reader.onerror = () => {
      toast.error('Failed to read the selected file.', { id: toastId });
      setIsImporting(false);
    };

    reader.readAsText(file);
  };


  const handleExportAllOperators = () => {
    if (operators.length === 0) {
      toast.error("No operators to export.");
      return;
    }
    // Use the full, unfiltered operators array for a complete backup, as requested.
    exportToJSON(operators, `all_operators_backup_${new Date().toISOString().split('T')[0]}.json`);
    toast.success("All operator data exported to JSON file.");
  };

  const topSurveillanceFindings = useMemo(() => {
    const oneYearAgo = new Date();
    oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1);

    const findingCounts: Record<string, number> = {};

    filteredOperators.forEach(op => { // Use filteredOperators
      (op.surveillanceFindings || []).forEach(sf => {
        if (new Date(sf.dateAdded) >= oneYearAgo) {
          const findingText = sf.finding.trim().toLowerCase();
          findingCounts[findingText] = (findingCounts[findingText] || 0) + 1;
        }
      });
    });

    return Object.entries(findingCounts)
      .map(([finding, count]) => ({ finding, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);
  }, [filteredOperators]);

  const handleGenerateOverallRecommendations = async () => {
    if (!aiDashboardClient) {
      setAiAdvisoryError("AI client is not initialized.");
      return;
    }
    setIsAiAdvisoryLoading(true);
    setAiAdvisory('');
    setAiAdvisoryError(null);

    const idrDistribution = filteredOperators.reduce((acc, op) => { // Use filteredOperators
      const level = `IDR ${op.riskIndicatorLevel}`;
      acc[level] = (acc[level] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const openFindingsByCategory = filteredOperators.reduce((acc, op) => { // Use filteredOperators
        (op.surveillanceFindings || []).filter(sf => !sf.isCompleted).forEach(sf => {
            acc[sf.findingCategory] = (acc[sf.findingCategory] || 0) + 1;
        });
        return acc;
    }, {} as Record<FindingCategoryLevel, number>);

    const legacyOccurrenceCounts = filteredOperators.reduce((acc, op) => { // Use filteredOperators
        (op.legacyRiskFactors.occurrences || []).forEach(occ => {
            acc[occ.type] = (acc[occ.type] || 0) + 1;
        });
        return acc;
    }, {} as Record<string, number>);


    const context = `
      Overall Operator Risk Profile (based on currently visible operators):
      ${Object.entries(idrDistribution).map(([level, count]) => `- ${count} operators at ${level}`).join('\n') || "No operators visible."}

      Top 5 Surveillance Findings (Last Year, from visible operators):
      ${topSurveillanceFindings.map(f => `- "${f.finding}" (Count: ${f.count})`).join('\n') || "No recent findings."}

      Open Surveillance Findings by Category (from visible operators):
      ${Object.entries(openFindingsByCategory).map(([cat, count]) => `- ${cat}: ${count}`).join('\n') || "No open findings."}

      Total Legacy Occurrences by Type (from visible operators):
      ${Object.entries(legacyOccurrenceCounts).map(([type, count]) => `- ${type}: ${count}`).join('\n') || "No legacy occurrences."}
    `;

    const prompt = `
      You are a strategic advisor to an aviation regulatory body (like the DGCA). Based on the following aggregated data trends across currently visible AOC holders,
      provide a concise set of 3-5 high-level, actionable recommendations.
      Focus on systemic issues, potential areas for focused oversight, safety promotion, or regulatory attention.
      Provide a plain text response in English, well-formatted with bullet points or numbered lists for clarity. Do not use markdown.

      Aggregated Data Context:
      ${context}

      Recommendations for the Regulatory Body:
    `;

    try {
      const response: GenerateContentResponse = await aiDashboardClient.models.generateContent({
        model: 'gemini-2.5-flash-preview-04-17',
        contents: prompt,
      });
      setAiAdvisory(response.text);
    } catch (error: any) {
      console.error("Error querying Gemini API for dashboard advisory:", error);
      setAiAdvisoryError(`Failed to get recommendations: ${error.message || 'Unknown AI error.'}`);
      setAiAdvisory('');
    } finally {
      setIsAiAdvisoryLoading(false);
    }
  };


  if (operators === undefined && !isImporting) { // operators can be an empty array
    return <LoadingSpinner />;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-center gap-3">
        <h2 className="text-2xl font-bold text-slate-800">RBS - Operator Dashboard</h2>
        <div className="flex space-x-2">
            {isAdmin && (
              <>
                <input
                    type="file"
                    accept=".json"
                    ref={fileInputRef}
                    onChange={handleFileUpload}
                    className="hidden"
                    disabled={isImporting}
                />
                <button
                    onClick={handleImportButtonClick}
                    className="bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-3 rounded-lg shadow-sm hover:shadow-lg transition-all flex items-center text-sm"
                    disabled={isImporting}
                >
                  <>
                    {isImporting ? (
                      <LoadingSpinner size="sm" />
                    ) : (
                      <UploadIcon className="h-4 w-4 mr-1.5" />
                    )}
                    <span className={isImporting ? "ml-1.5" : ""}>
                        {isImporting ? 'Importing...' : 'Import JSON'}
                    </span>
                  </>
                </button>
                <button
                    onClick={handleExportAllOperators}
                    className="bg-purple-600 hover:bg-purple-700 text-white font-semibold py-2 px-3 rounded-lg shadow-sm hover:shadow-lg transition-all flex items-center text-sm"
                >
                    <DownloadIcon className="h-4 w-4 mr-1.5" />
                    Export All (JSON)
                </button>
                <Link
                  to="/operator/new"
                  className="bg-brand-primary hover:bg-blue-800 text-white font-semibold py-2 px-3 rounded-lg shadow-sm hover:shadow-lg transition-all flex items-center text-sm"
                >
                    <PlusIcon className="h-4 w-4 mr-1.5" />
                    Add New Operator
                </Link>
              </>
            )}
        </div>
      </div>

      {/* Key Metrics Stat Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Total Visible Operators" value={keyMetrics.totalOperators} icon={<UserGroupIcon />} />
        <StatCard title="Total Occurrences (Visible Ops)" value={keyMetrics.totalOccurrences} icon={<ExclamationTriangleIcon />} colorClass="text-orange-500" />
        <StatCard title="Surveillance Findings (Visible Ops)" value={`${keyMetrics.openFindings} Open / ${keyMetrics.totalFindings} Total`} icon={<ClipboardDocumentCheckIcon />} colorClass="text-teal-500" />
        <StatCard title="Avg. Surveillance Cycle (Visible Ops)" value={`${keyMetrics.avgSurveillanceCycle} mo.`} icon={<ClockIcon />} colorClass="text-indigo-500" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Operator Performance Overview Chart */}
        <div className="lg:col-span-2 bg-white p-4 sm:p-6 rounded-xl shadow-lg">
          <h3 className="text-lg font-semibold text-slate-700 mb-3 flex items-center">
            <span>
              <ChartBarIcon className="h-5 w-5 mr-2 text-brand-secondary" />
              Operator Performance Overview (Top 10 by Risk, Visible Operators)
            </span>
          </h3>
          {filteredOperators.length > 0 ? (
          <ResponsiveContainer width="100%" height={300}>
              <BarChart data={chartData} margin={{ top: 5, right: 0, left: -10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" angle={-35} textAnchor="end" height={75} interval={0} tick={{fontSize: 9}} />
              <YAxis tick={{fontSize: 10}} label={{ value: 'Performance Score F(P) %', angle: -90, position: 'insideLeft', fontSize: 10, offset:10 }} />
              <Tooltip
                  contentStyle={{backgroundColor: 'rgba(255,255,255,0.9)', border: '1px solid #ccc', borderRadius: '5px', fontSize: '10px', padding: '5px'}}
                  labelStyle={{color: '#333', fontWeight: 'bold'}}
                  formatter={(value: number, name: string, props) => [`${value.toFixed(1)}% (IDR: ${props.payload.riskIndicatorLevel}, Exp: ${props.payload.exposureLevel})`, "F(P) Score"]}
              />
              <RechartsLegend wrapperStyle={{fontSize: "10px"}}/>
              <Bar dataKey="performanceScore" name="Performance Score F(P)">
                  {chartData.map((entry, index) => (
                       <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
              </Bar>
              </BarChart>
          </ResponsiveContainer>
          ) : (
              <p className="text-slate-500 text-sm">No operator data available for the current filter. Add operators or adjust filter to see the risk overview.</p>
          )}
        </div>

        {/* Operators by Exposure Level Pie Chart */}
        <div ref={exposureChartContainerRef} className="lg:col-span-1 bg-white p-4 sm:p-6 rounded-xl shadow-lg h-[400px]"> {/* Set fixed height for container */}
          <h3 className="text-lg font-semibold text-slate-700 mb-4 flex items-center">
            <span>
              <ChartPieIcon className="h-5 w-5 mr-2 text-brand-secondary" />
              Operators by Exposure Level (Visible Operators)
            </span>
          </h3>
          {!exposureChartReady ? (
            <div className="flex items-center justify-center h-[300px]"> {/* Adjust height based on parent */}
                <LoadingSpinner /> <span className="ml-2 text-sm text-slate-500">Loading chart...</span>
            </div>
          ) : filteredOperators.length > 0 && keyMetrics.exposureLevelCountsArray.some(d => d.value > 0) ? (
            <ResponsiveContainer width="100%" height={300}> {/* Height for the chart itself */}
              <PieChart>
                <Pie
                  data={keyMetrics.exposureLevelCountsArray}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {keyMetrics.exposureLevelCountsArray.map((entry, index) => (
                    <Cell key={`cell-exp-${index}`} fill={entry.fill || '#8884d8'} />
                  ))}
                </Pie>
                <Tooltip
                   contentStyle={{backgroundColor: 'rgba(255,255,255,0.9)', border: '1px solid #ccc', borderRadius: '5px', fontSize: '10px', padding: '5px'}}
                />
                <Legend wrapperStyle={{fontSize: "10px", paddingTop: "10px"}}/>
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex items-center justify-center h-[300px]">
                <p className="text-slate-500 text-sm italic">No operator data or exposure levels for visible operators.</p>
            </div>
          )}
        </div>
      </div>

      {/* AI-Powered DGCA Advisory */}
        <div className="bg-white p-4 sm:p-6 rounded-xl shadow-lg">
            <h3 className="text-lg font-semibold text-slate-700 mb-3 flex items-center">
              <span>
                <AcademicCapIcon className="h-5 w-5 mr-2 text-brand-secondary" />
                AI-Powered Regulatory Advisory
              </span>
            </h3>
            {!API_KEY && (
                <div className="p-3 text-sm text-yellow-700 bg-yellow-100 rounded-md border border-yellow-300">
                    AI Advisory feature is unavailable. API_KEY is not configured.
                </div>
            )}
            {API_KEY && !aiDashboardClient && aiAdvisoryError &&(
                 <div className="p-3 text-sm text-red-700 bg-red-100 rounded-md border border-red-300">
                    {aiAdvisoryError}
                </div>
            )}
            {API_KEY && !aiDashboardClient && !aiAdvisoryError && (
                <div className="p-3 text-sm text-blue-700 bg-blue-100 rounded-md border border-blue-300">
                  <div className="flex items-center">
                    <>
                      <LoadingSpinner size="sm"/>
                      <span className="ml-2">Initializing AI Advisory service...</span>
                    </>
                  </div>
                </div>
            )}
            {API_KEY && aiDashboardClient && (
                <>
                    <button
                        onClick={handleGenerateOverallRecommendations}
                        disabled={isAiAdvisoryLoading || filteredOperators.length === 0}
                        className="bg-sky-600 hover:bg-sky-700 text-white font-semibold py-2 px-4 rounded-lg shadow-sm transition-all flex items-center text-sm disabled:bg-slate-400 disabled:cursor-not-allowed"
                    >
                        {isAiAdvisoryLoading ? (
                            <span className="flex items-center">
                                <LoadingSpinner size="sm" />
                                <span className="ml-2">Generating...</span>
                            </span>
                        ) : (
                            <span>Generate Overall Recommendations</span>
                        )}
                    </button>
                    {isAiAdvisoryLoading && <div className="mt-3"><LoadingSpinner /></div>}
                    {aiAdvisoryError && !isAiAdvisoryLoading && (
                        <div className="mt-3 p-3 text-sm text-red-700 bg-red-100 rounded-md border border-red-300">
                            <p className="font-semibold">Error generating advisory:</p>
                            <p>{aiAdvisoryError}</p>
                        </div>
                    )}
                    {aiAdvisory && !isAiAdvisoryLoading && (
                        <div className="mt-4 p-3 bg-slate-50 border border-slate-200 rounded-md">
                            <h4 className="text-md font-semibold text-slate-800 mb-2">Regulatory Recommendations:</h4>
                            <pre className="whitespace-pre-wrap text-sm text-slate-700 font-sans leading-relaxed">{aiAdvisory}</pre>
                        </div>
                    )}
                    {filteredOperators.length === 0 && !isAiAdvisoryLoading && (
                        <p className="text-slate-500 text-sm italic mt-2">No operators visible to generate recommendations. Adjust filters or check permissions.</p>
                    )}
                </>
            )}
        </div>


      <div>
        <input
            type="text"
            placeholder="Search operators by name or AOC..."
            className="w-full p-2.5 border border-slate-300 rounded-lg shadow-sm focus:ring-1 focus:ring-brand-secondary focus:border-transparent outline-none text-sm"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {filteredOperators.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredOperators.map((operator) => (
            <OperatorCard key={operator.id} operator={operator} />
          ))}
        </div>
      ) : (
        <div className="text-center py-10">
          <svg className="mx-auto h-10 w-10 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
            <path vectorEffect="non-scaling-stroke" strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 13h6m-3-3v6m-9 1V7a2 2 0 012-2h6l2 2h6a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2z" />
          </svg>
          <h3 className="mt-2 text-md font-medium text-slate-800">No Operators Found</h3>
          <p className="mt-1 text-xs text-slate-500">
            {searchTerm ? "Adjust your search criteria. " : ""}
            {isAdmin ? (
                <>Or get started by <Link to="/operator/new" className="font-medium text-brand-primary hover:text-blue-800">adding a new operator</Link>.</>
            ) : "You may not have permission to view or add operators."}
          </p>
        </div>
      )}
    </div>
  );
};
