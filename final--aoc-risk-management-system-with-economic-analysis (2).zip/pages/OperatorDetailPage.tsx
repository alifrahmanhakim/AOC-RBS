

import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Link } from 'react-router-dom';
import { useParams, useNavigate } from 'react-router';
import { useOperators } from '../hooks/useOperators';
import { useAuth } from '../contexts/AuthContext'; // Import useAuth
import { 
    Operator, 
    Occurrence, 
    OccurrenceType, 
    SeverityLevel, 
    ComplexityFactors,
    ComplianceData,
    ComplianceFindingCounts, 
    DeviationData,
    ImprovementData,
    SurveillanceFinding,
    FindingCategoryLevel, 
    OccurrenceCategory,
    OCCURRENCE_CATEGORY_LABELS,
    OCCURRENCE_CATEGORY_USAGE_NOTES,
    DEFAULT_OCCURRENCE_REPORT_FORM_STATE,
    DEFAULT_COMPLEXITY_FACTORS,
    DEFAULT_COMPLIANCE_DATA,
    DEFAULT_DEVIATION_DATA,
    DEFAULT_IMPROVEMENT_DATA,
    ExposureLevel,
    Location,
    WeatherForecast,
    WMO_WEATHER_CODES,
    RouteDetails,
    GroundingSource,
    OPERATOR_CATEGORIES,
    RiskLevel,
    SurveillanceLogCategory, 
    PredefinedSurveillanceArea,
    SurveillanceLogItem,
    EconomicFactors,
    UserRole, // Import UserRole
    SurveillanceLogStatus,
    AirportDbResponse // Added for airportdb.io
} from '../types';
import { LoadingSpinner } from '../components/shared/LoadingSpinner';
import { RiskBadge } from '../components/shared/RiskBadge'; 
import { Modal } from '../components/shared/Modal';
import { PencilIcon, TrashIcon, PlusIcon, ExclamationTriangleIcon, CheckCircleIcon, XCircleIcon, MapPinIcon, CloudIcon, PlaneIcon as PlaneIconSolid, DownloadIcon, BuildingLibraryIcon, PresentationChartLineIcon, ChartPieIcon, AcademicCapIcon, InformationCircleIcon as InfoCircleIconSolid, ArrowPathIcon, TableCellsIcon, ListBulletIcon, CalendarDaysIcon, SparklesIcon, CurrencyDollarIcon, ChevronDownIcon, ChevronUpIcon, UploadIcon } from '../components/icons';
import toast from 'react-hot-toast';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend as RechartsLegend } from 'recharts';
import { 
    CHART_HEX_RISK_LEVEL_COLORS, 
    CHART_HEX_EXPOSURE_LEVEL_COLORS, 
    RBS_PERFORMANCE_TO_INDICATOR_LEVEL, 
    FINDING_CATEGORY_OPTIONS, 
    CHART_HEX_SURVEILLANCE_STATUS_COLORS,
    RBS_MATRIX_CELL_KEYS, 
    RBS_MATRIX_CELL_COLORS, 
    RBS_MATRIX_SURVEILLANCE_CYCLES,
    PREDEFINED_SURVEILLANCE_AREAS
} from '../../constants';
import { GoogleGenAI, GenerateContentResponse } from '@google/genai';
import L from 'leaflet'; 
import { exportToJSON } from '../utils/exportUtils'; 
import { SafetyRiskAreaChart } from '../components/charts/SafetyRiskAreaChart';
import { RiskIndicatorTrendChart } from '../components/charts/RiskIndicatorTrendChart';
import { SurveillanceLogSection } from '../components/operatorDetails/SurveillanceLogSection';
import { SurveillanceComplianceHeatmap } from '../components/charts/SurveillanceComplianceHeatmap';
import { EconomicSpiderwebChart } from '../components/charts/EconomicSpiderwebChart';
import { EconomicIndexesTable } from '../components/operatorDetails/EconomicIndexesTable';
import { SurveillanceFindingFormModal } from '../components/operatorDetails/SurveillanceFindingFormModal';
import { MasterFindingsList } from '../components/operatorDetails/MasterFindingsList';
import { FindingsDisplayModal } from '../components/operatorDetails/FindingsDisplayModal';


const initialOccurrenceReportFormState = DEFAULT_OCCURRENCE_REPORT_FORM_STATE;

const exposureLevelFullLabels: Record<ExposureLevel, string> = {
    [ExposureLevel.A]: "Very Low",
    [ExposureLevel.B]: "Low",
    [ExposureLevel.C]: "Medium",
    [ExposureLevel.D]: "High",
    [ExposureLevel.E]: "Very High",
};

delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

const mapWmoCodeToDescription = (code?: number): string => {
    if (code === undefined || code === null) return "N/A";
    return WMO_WEATHER_CODES[code] || `Unknown code (${code})`;
};

export type HistoricalPathPeriod = 'Daily' | 'Weekly' | 'Monthly' | 'Yearly';

// AirportDB API Token
const AIRPORTDB_API_TOKEN = "7605ed5a7a9c32b9128549776cb0ec14ef11ac8cec39cc11155ce03346b582412394bbad521b4727171218b15131b2dd";


export const OperatorDetailPage: React.FC = () => {
  const { operatorId } = useParams<{ operatorId: string }>();
  const navigate = useNavigate();
  const { 
    operators, 
    getOperatorById, 
    updateOperatorBasicInfo,
    updateOperatorRBSData,
    updateOperatorMiscData, 
    deleteOperator, 
    addLegacyOccurrence, 
    updateLegacyOccurrence, 
    deleteLegacyOccurrence,
    addSurveillanceFinding,
    updateSurveillanceFinding,
    deleteSurveillanceFinding,
    toggleSurveillanceFindingCompletion,
    upsertSurveillanceLogItem,
    deleteSurveillanceLogItem,
    importOperatorData // New import from context
  } = useOperators();
  const { currentUser, isAuthLoading } = useAuth(); 

  const [operator, setOperator] = useState<Operator | undefined>(undefined); 
  const [isLoadingOperator, setIsLoadingOperator] = useState(true);
  const [isEditingBasicInfo, setIsEditingBasicInfo] = useState(false);
  
  const [basicInfoForm, setBasicInfoForm] = useState({ name: '', aocNumber: '', logoUrl: '' });
  const [complexityFactorsForm, setComplexityFactorsForm] = useState<ComplexityFactors>(DEFAULT_COMPLEXITY_FACTORS);
  const [complianceDataForm, setComplianceDataForm] = useState<ComplianceData>(DEFAULT_COMPLIANCE_DATA); 
  const [deviationDataForm, setDeviationDataForm] = useState<DeviationData>(DEFAULT_DEVIATION_DATA); 
  
  const [economicTechnicalProfileForm, setEconomicTechnicalProfileForm] = useState({
    economicIndicatorScore: 2.5, 
    operatorCategory: OPERATOR_CATEGORIES[0],
    hadFatalAccidentLast3Years: false,
  });
  const [historicalPathPeriod, setHistoricalPathPeriod] = useState<HistoricalPathPeriod>('Monthly');


  const [isOccurrenceReportModalOpen, setIsOccurrenceReportModalOpen] = useState(false);
  const [editingOccurrenceReport, setEditingOccurrenceReport] = useState<Occurrence | null>(null);
  const [occurrenceReportFormData, setOccurrenceReportFormData] = useState<Omit<Occurrence, 'id'>>(initialOccurrenceReportFormState);
  const [selectedCategoryUsageNotes, setSelectedCategoryUsageNotes] = useState<string>('');
  const [isFetchingWeather, setIsFetchingWeather] = useState(false);
  
  const [isFetchingFlightDetails, setIsFetchingFlightDetails] = useState(false);
  const [flightDetailsError, setFlightDetailsError] = useState<string | null>(null);

  // State for AirportDB fetching
  const [isFetchingOriginAirport, setIsFetchingOriginAirport] = useState(false);
  const [originAirportError, setOriginAirportError] = useState<string | null>(null);
  const [isFetchingDestinationAirport, setIsFetchingDestinationAirport] = useState(false);
  const [destinationAirportError, setDestinationAirportError] = useState<string | null>(null);

  // State for Finding Modal (lifted up)
  const [isFindingModalOpen, setIsFindingModalOpen] = useState(false);
  const [findingModalConfig, setFindingModalConfig] = useState<{ area?: PredefinedSurveillanceArea; finding?: SurveillanceFinding } | null>(null);
  
  // State for Heatmap Click Modal
  const [isFindingsDisplayModalOpen, setIsFindingsDisplayModalOpen] = useState(false);
  const [findingsForDisplay, setFindingsForDisplay] = useState<SurveillanceFinding[]>([]);
  const [findingsDisplayModalTitle, setFindingsDisplayModalTitle] = useState('');


  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markerRef = useRef<L.Marker | null>(null);
  const [isReverseGeocoding, setIsReverseGeocoding] = useState(false);

  const [aiClient, setAiClient] = useState<GoogleGenAI | null>(null);
  const [generalAiQuery, setGeneralAiQuery] = useState('');
  const [generalAiResponse, setGeneralAiResponse] = useState('');
  const [isGeneralAiLoading, setIsGeneralAiLoading] = useState(false);
  const [generalAiError, setGeneralAiError] = useState<string | null>(null);
  const [inspectorAiQuery, setInspectorAiQuery] = useState('');
  const [inspectorAiResponse, setInspectorAiResponse] = useState('');
  const [isInspectorAiLoading, setIsInspectorAiLoading] = useState(false);
  const [inspectorAiError, setInspectorAiError] = useState<string | null>(null);

  const [isGeneralAiThinkingVisible, setIsGeneralAiThinkingVisible] = useState(false);
  const [generalAiPromptSent, setGeneralAiPromptSent] = useState<string | null>(null);
  const [isInspectorAiThinkingVisible, setIsInspectorAiThinkingVisible] = useState(false);
  const [inspectorAiPromptSent, setInspectorAiPromptSent] = useState<string | null>(null);

  const API_KEY = process.env.API_KEY;
  const AVIATION_STACK_API_KEY = process.env.AVIATION_STACK_API_KEY;

  const [isFinancialReportLoading, setIsFinancialReportLoading] = useState<boolean>(false);
  const [financialReportError, setFinancialReportError] = useState<string | null>(null);
  const [financialReportFile, setFinancialReportFile] = useState<File | null>(null);
  const [financialReportFileError, setFinancialReportFileError] = useState<string | null>(null);
  const [isAiRBSDataLoading, setIsAiRBSDataLoading] = useState(false);
  const [aiRBSDataError, setAiRBSDataError] = useState<string | null>(null);

  const jsonFileInputRef = useRef<HTMLInputElement>(null); // Ref for JSON file input
  const [isProcessingJsonImport, setIsProcessingJsonImport] = useState(false); // Loading state for JSON import
  const [isImportConfirmModalOpen, setIsImportConfirmModalOpen] = useState(false);
  const [jsonDataForImport, setJsonDataForImport] = useState<Partial<Operator> | null>(null);

  const isAdmin = useMemo(() => currentUser?.role === UserRole.ADMIN, [currentUser]);


  useEffect(() => {
    setIsLoadingOperator(true);
    if (operatorId) {
      const foundOperator = getOperatorById(operatorId);
      
      if (foundOperator) {
        if (!isAdmin && currentUser?.role === UserRole.RESTRICTED_USER && currentUser.managesOperatorNameContaining) {
          if (!foundOperator.name.toLowerCase().includes(currentUser.managesOperatorNameContaining.toLowerCase())) {
            toast.error("Access Denied: You do not have permission to view this operator.");
            navigate('/'); 
            return;
          }
        }
        setOperator(foundOperator);
        setBasicInfoForm({ name: foundOperator.name, aocNumber: foundOperator.aocNumber, logoUrl: foundOperator.logoUrl || '' });
        setComplexityFactorsForm(foundOperator.complexityFactors);
        setComplianceDataForm(foundOperator.complianceData); 
        setDeviationDataForm(foundOperator.deviationData); 
        setEconomicTechnicalProfileForm({
            economicIndicatorScore: foundOperator.economicIndicatorScore ?? 2.5,
            operatorCategory: foundOperator.operatorCategory ?? OPERATOR_CATEGORIES[0],
            hadFatalAccidentLast3Years: foundOperator.hadFatalAccidentLast3Years ?? false,
        });
      } else {
         setOperator(undefined); 
         toast.error(`Operator with ID "${operatorId}" not found.`);
         navigate('/');
      }
    } else {
        setOperator(undefined); 
    }
    setIsLoadingOperator(false);
  }, [operatorId, getOperatorById, operators, navigate, currentUser, isAdmin]); 

  useEffect(() => {
    if (API_KEY) {
      try {
        const client = new GoogleGenAI({ apiKey: API_KEY });
        setAiClient(client);
        setGeneralAiError(null); 
        setInspectorAiError(null);
        setFinancialReportError(null);
        setAiRBSDataError(null);
      } catch (error) {
        console.error("Failed to initialize GoogleGenAI client:", error);
        const errorMsg = "Failed to initialize AI client. Check API key configuration.";
        setGeneralAiError(errorMsg);
        setInspectorAiError(errorMsg);
        setFinancialReportError(errorMsg);
        setAiRBSDataError(errorMsg);
        setAiClient(null);
      }
    } else {
      setAiClient(null); 
    }
  }, [API_KEY]);

  useEffect(() => {
    if (occurrenceReportFormData.category) {
      setSelectedCategoryUsageNotes(OCCURRENCE_CATEGORY_USAGE_NOTES[occurrenceReportFormData.category] || '');
    } else {
      setSelectedCategoryUsageNotes('');
    }
  }, [occurrenceReportFormData.category]);

  const fetchWeatherForecast = async (dateTimeISO: string, latitude?: number, longitude?: number) => {
    if (!latitude || !longitude || !dateTimeISO) {
      setOccurrenceReportFormData(prev => ({ ...prev, weatherForecast: { temperature: undefined, weatherCode: undefined, weatherDescription: undefined, windSpeed: undefined, source: undefined, fetchedAt: undefined } }));
      return;
    }
    setIsFetchingWeather(true);
    setOccurrenceReportFormData(prev => ({ ...prev, weatherForecast: { ...prev.weatherForecast, source: 'Open-Meteo', weatherDescription: 'Fetching...' } }));

    const datePart = dateTimeISO.split('T')[0];
    const hourPart = parseInt(dateTimeISO.split('T')[1].split(':')[0], 10);

    const apiUrl = `https://api.open-meteo.com/v1/forecast?latitude=${latitude.toFixed(4)}&longitude=${longitude.toFixed(4)}&hourly=temperature_2m,weathercode,windspeed_10m&start_date=${datePart}&end_date=${datePart}&timezone=auto`;

    try {
      const response = await fetch(apiUrl);
      if (!response.ok) {
        throw new Error(`Open-Meteo API request failed: ${response.statusText}`);
      }
      const data = await response.json();
      
      if (data.hourly && data.hourly.time && data.hourly.time.length > 0) {
        let bestMatchIndex = -1;
        let minHourDiff = Infinity;

        data.hourly.time.forEach((timeStr: string, index: number) => {
            const forecastHour = parseInt(timeStr.split('T')[1].split(':')[0], 10);
            const diff = Math.abs(forecastHour - hourPart);
            if (diff < minHourDiff) {
                minHourDiff = diff;
                bestMatchIndex = index;
            }
        });
        
        if (bestMatchIndex !== -1) {
            setOccurrenceReportFormData(prev => ({ 
                ...prev, 
                weatherForecast: {
                    ...prev.weatherForecast,
                    temperature: data.hourly.temperature_2m[bestMatchIndex],
                    weatherCode: data.hourly.weathercode[bestMatchIndex],
                    weatherDescription: mapWmoCodeToDescription(data.hourly.weathercode[bestMatchIndex]),
                    windSpeed: data.hourly.windspeed_10m[bestMatchIndex],
                    source: 'Open-Meteo',
                    fetchedAt: new Date().toISOString()
                } 
            }));
        } else {
             throw new Error("Could not find matching hourly forecast.");
        }
      } else {
        throw new Error("No hourly forecast data returned.");
      }
    } catch (error: any) {
      console.error('Open-Meteo fetch failed:', error);
      setOccurrenceReportFormData(prev => ({ ...prev, weatherForecast: { ...prev.weatherForecast, source: 'Open-Meteo', weatherDescription: `Failed: ${error.message}` }}));
    } finally {
      setIsFetchingWeather(false);
    }
  };
  
  useEffect(() => {
    const { dateTime, location } = occurrenceReportFormData;
    if (isOccurrenceReportModalOpen && dateTime && location && location.latitude && location.longitude) {
        fetchWeatherForecast(dateTime, location.latitude, location.longitude);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [occurrenceReportFormData.dateTime, occurrenceReportFormData.location?.latitude, occurrenceReportFormData.location?.longitude, isOccurrenceReportModalOpen]);


  useEffect(() => {
    let mapPollTimer: number | null = null;
    let attemptCount = 0;
    const maxAttempts = 30; // Max attempts to find map dimensions (e.g., 30 * 100ms = 3 seconds)
  
    if (isOccurrenceReportModalOpen && mapRef.current && !mapInstanceRef.current) {
      const initialLat = occurrenceReportFormData.location?.latitude || -2.5489;
      const initialLng = occurrenceReportFormData.location?.longitude || 118.0149;
      const initialZoom = (occurrenceReportFormData.location?.latitude && occurrenceReportFormData.location?.longitude) ? 15 : 5;
  
      const map = L.map(mapRef.current).setView([initialLat, initialLng], initialZoom);
      mapInstanceRef.current = map;
  
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
      }).addTo(map);
  
      const marker = L.marker([initialLat, initialLng], { draggable: isAdmin }).addTo(map);
      markerRef.current = marker;
  
      if (occurrenceReportFormData.location?.latitude && occurrenceReportFormData.location?.longitude) {
        marker.setOpacity(1);
        if (!occurrenceReportFormData.location.addressString) {
          performReverseGeocoding(occurrenceReportFormData.location.latitude, occurrenceReportFormData.location.longitude);
        }
      } else {
        marker.setOpacity(0);
      }
  
      if (isAdmin) {
        map.on('click', (e: L.LeafletMouseEvent) => {
          if (!mapInstanceRef.current || !markerRef.current) return;
          const { lat, lng } = e.latlng;
          markerRef.current.setLatLng(e.latlng).setOpacity(1);
          performReverseGeocoding(lat, lng);
          setOccurrenceReportFormData(prev => ({
            ...prev,
            location: { ...prev.location, latitude: lat, longitude: lng, addressString: 'Fetching address...' }
          }));
          // No need for immediate invalidateSize here, other effects handle it or it's part of form data change.
        });
  
        marker.on('dragend', () => {
          if (!markerRef.current || !mapInstanceRef.current) return;
          const { lat, lng } = markerRef.current.getLatLng();
          performReverseGeocoding(lat, lng);
          setOccurrenceReportFormData(prev => ({
            ...prev,
            location: { ...prev.location, latitude: lat, longitude: lng, addressString: 'Fetching address...' }
          }));
        });
      }
  
      const checkMapSizeAndInvalidate = () => {
        if (mapPollTimer) clearTimeout(mapPollTimer); 
  
        if (mapInstanceRef.current && mapRef.current && mapRef.current.offsetWidth > 0 && mapRef.current.offsetHeight > 0) {
          mapInstanceRef.current.invalidateSize();
          if (occurrenceReportFormData.location?.latitude && occurrenceReportFormData.location?.longitude) {
            mapInstanceRef.current.setView(
              [occurrenceReportFormData.location.latitude, occurrenceReportFormData.location.longitude],
              mapInstanceRef.current.getZoom()
            );
          } else {
            mapInstanceRef.current.setView([initialLat, initialLng], initialZoom);
          }
        } else if (isOccurrenceReportModalOpen && mapInstanceRef.current && attemptCount < maxAttempts) {
          attemptCount++;
          mapPollTimer = window.setTimeout(checkMapSizeAndInvalidate, 100);
        } else if (attemptCount >= maxAttempts) {
          console.warn("Map container did not become ready for invalidateSize after multiple attempts.");
        }
      };
      
      mapPollTimer = window.setTimeout(checkMapSizeAndInvalidate, 50); // Start polling shortly after map object is created
  
    } else if (!isOccurrenceReportModalOpen && mapInstanceRef.current) {
      if (mapPollTimer) clearTimeout(mapPollTimer);
      mapInstanceRef.current.remove();
      mapInstanceRef.current = null;
      markerRef.current = null;
    }
  
    return () => { // Cleanup function for the effect
      if (mapPollTimer) clearTimeout(mapPollTimer);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOccurrenceReportModalOpen, isAdmin]); // Minimal dependencies for init/cleanup.
                                                 // Initial location data read is fine.
  
  useEffect(() => {
      if (mapInstanceRef.current && markerRef.current && isOccurrenceReportModalOpen) {
        if (occurrenceReportFormData.location?.latitude !== undefined && occurrenceReportFormData.location?.longitude !== undefined) {
            const newPos: L.LatLngTuple = [occurrenceReportFormData.location.latitude, occurrenceReportFormData.location.longitude];
            const currentMarkerPos = markerRef.current.getLatLng();
            
            if (currentMarkerPos.lat.toFixed(5) !== newPos[0].toFixed(5) || currentMarkerPos.lng.toFixed(5) !== newPos[1].toFixed(5)) {
                markerRef.current.setLatLng(newPos);
                 if (!occurrenceReportFormData.location.addressString || occurrenceReportFormData.location.addressString === "Fetching address...") {
                    performReverseGeocoding(newPos[0], newPos[1]);
                }
            }
            markerRef.current.setOpacity(1);
            
            const currentMapCenter = mapInstanceRef.current.getCenter();
            if (currentMapCenter.lat.toFixed(5) !== newPos[0].toFixed(5) || currentMapCenter.lng.toFixed(5) !== newPos[1].toFixed(5)) {
                 mapInstanceRef.current.setView(newPos, mapInstanceRef.current.getZoom());
            }
            // A short delay before invalidateSize might still be beneficial after programmatic changes
            const timer = setTimeout(() => { 
                if (mapInstanceRef.current && isOccurrenceReportModalOpen) {
                    mapInstanceRef.current.invalidateSize();
                }
            }, 50); // Reduced delay as this is an update, not initial load.
            return () => clearTimeout(timer);
        } else {
           markerRef.current.setOpacity(0);
        }
      }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [occurrenceReportFormData.location?.latitude, occurrenceReportFormData.location?.longitude, isOccurrenceReportModalOpen]);

  useEffect(() => {
    // Effect to invalidate map size if other form data changes while modal is open
    // This helps if other parts of the form cause layout shifts affecting the map container.
    if (isOccurrenceReportModalOpen && mapInstanceRef.current) {
      const timer = setTimeout(() => {
        if (mapInstanceRef.current && isOccurrenceReportModalOpen && mapRef.current && mapRef.current.offsetWidth > 0) {
          mapInstanceRef.current.invalidateSize();
        }
      }, 150); // Delay to allow DOM to settle after re-render
      return () => clearTimeout(timer);
    }
  }, [occurrenceReportFormData, isOccurrenceReportModalOpen]);


  const performReverseGeocoding = async (lat: number, lng: number) => {
    if (isNaN(lat) || isNaN(lng)) {
        setOccurrenceReportFormData(prev => ({ ...prev, location: { ...prev.location, latitude: lat, longitude: lng, addressString: "Invalid coordinates." }}));
        return;
    }
    setIsReverseGeocoding(true);
    setOccurrenceReportFormData(prev => ({ ...prev, location: { ...prev.location, latitude: lat, longitude: lng, addressString: "Fetching address..." }}));
    try {
      const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lng}&accept-language=en`);
      if (!response.ok) {
        throw new Error(`Nominatim API request failed: ${response.statusText}`);
      }
      const data = await response.json();
      if (data && data.display_name) {
        setOccurrenceReportFormData(prev => ({
          ...prev,
          location: { ...prev.location, latitude: lat, longitude: lng, addressString: data.display_name }
        }));
      } else {
        setOccurrenceReportFormData(prev => ({ ...prev, location: { ...prev.location, latitude: lat, longitude: lng, addressString: "No address found." }}));
      }
    } catch (error) {
      console.error('Nominatim reverse geocoding failed:', error);
      setOccurrenceReportFormData(prev => ({ ...prev, location: { ...prev.location, latitude: lat, longitude: lng, addressString: "Geocoding failed." }}));
    } finally {
        setIsReverseGeocoding(false);
    }
  };

  const fetchFlightDetails = async () => {
    if (!AVIATION_STACK_API_KEY) {
      setFlightDetailsError("AviationStack API key not configured.");
      return;
    }
    const flightNumber = occurrenceReportFormData.flightNumber;
    if (!flightNumber || !flightNumber.trim()) {
      setFlightDetailsError("Please enter a Flight Number to fetch details.");
      return;
    }

    setIsFetchingFlightDetails(true);
    setFlightDetailsError(null);
    setOccurrenceReportFormData(prev => ({
      ...prev,
      routeDetails: {
        ...prev.routeDetails,
        flightDataSource: "Fetching..."
      }
    }));
    
    const apiUrl = `http://api.aviationstack.com/v1/flights?access_key=${AVIATION_STACK_API_KEY}&flight_iata=${flightNumber.trim().toUpperCase()}&limit=1`;

    try {
      const response = await fetch(apiUrl);
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({})); 
        throw new Error(errorData?.error?.message || `API request failed: ${response.status} ${response.statusText}`);
      }
      const result = await response.json();
      
      if (result.data && result.data.length > 0) {
        const flight = result.data[0];
        const dep = flight.departure;
        const arr = flight.arrival;
        const airline = flight.airline;

        let routeDesc = `Dep: ${dep.airport || 'N/A'} (${dep.icao || 'N/A'}) at ${dep.scheduled?.split('T')[1]?.substring(0,5) || 'N/A'}. `;
        routeDesc += `Arr: ${arr.airport || 'N/A'} (${arr.icao || 'N/A'}) at ${arr.scheduled?.split('T')[1]?.substring(0,5) || 'N/A'}. `;
        routeDesc += `Airline: ${airline.name || 'N/A'}. Status: ${flight.flight_status || 'N/A'}.`;
        
        setOccurrenceReportFormData(prev => ({
          ...prev,
          routeDetails: {
            originAirportICAO: dep.icao || '',
            destinationAirportICAO: arr.icao || '',
            originAirportName: dep.airport || prev.routeDetails?.originAirportName,
            destinationAirportName: arr.airport || prev.routeDetails?.destinationAirportName,
            routeDescription: routeDesc,
            flightDataSource: 'AviationStack'
          }
        }));
        toast.success(`Flight details fetched for ${flightNumber}.`);
      } else {
        setFlightDetailsError(`No flight details found for ${flightNumber}. It might be a general aviation flight or not in the live database.`);
        setOccurrenceReportFormData(prev => ({
            ...prev,
            routeDetails: {
              ...prev.routeDetails,
              flightDataSource: 'Manual' 
            }
        }));
      }
    } catch (error: any) {
      console.error("AviationStack API fetch failed:", error);
      setFlightDetailsError(`Failed to fetch flight details: ${error.message}`);
      setOccurrenceReportFormData(prev => ({
        ...prev,
        routeDetails: {
            ...prev.routeDetails,
            flightDataSource: 'Manual' 
        }
      }));
    } finally {
      setIsFetchingFlightDetails(false);
    }
  };

  const fetchAirportDetails = async (icao: string, fieldType: 'origin' | 'destination') => {
    if (!AIRPORTDB_API_TOKEN) {
        const errorMsg = "AirportDB API token not available.";
        if (fieldType === 'origin') setOriginAirportError(errorMsg);
        else setDestinationAirportError(errorMsg);
        return;
    }
    if (icao.length !== 4) { // Only fetch for full ICAO codes
        if (fieldType === 'origin') {
            setOriginAirportError(null);
            setOccurrenceReportFormData(prev => ({...prev, routeDetails: {...prev.routeDetails, originAirportName: ''}}));
        } else {
            setDestinationAirportError(null);
            setOccurrenceReportFormData(prev => ({...prev, routeDetails: {...prev.routeDetails, destinationAirportName: ''}}));
        }
        return;
    }

    if (fieldType === 'origin') {
        setIsFetchingOriginAirport(true);
        setOriginAirportError(null);
    } else {
        setIsFetchingDestinationAirport(true);
        setDestinationAirportError(null);
    }

    try {
        const response = await fetch(`https://airportdb.io/api/v1/airport/${icao.toUpperCase()}?apiToken=${AIRPORTDB_API_TOKEN}`);
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({ message: `HTTP error ${response.status}`}));
            throw new Error(errorData.message || `Airport ${icao.toUpperCase()} not found or API error.`);
        }
        const data: AirportDbResponse = await response.json();
        const airportDisplayName = `${data.name}${data.city ? `, ${data.city}` : ''}${data.country_name ? `, ${data.country_name}` : ''}`;

        setOccurrenceReportFormData(prev => {
            const newRouteDetails = { ...prev.routeDetails };
            if (fieldType === 'origin') {
                newRouteDetails.originAirportName = airportDisplayName;
            } else {
                newRouteDetails.destinationAirportName = airportDisplayName;
            }
            // Auto-update route description
            let newRouteDesc = '';
            if (newRouteDetails.originAirportName) newRouteDesc += `From: ${newRouteDetails.originAirportName}`;
            if (newRouteDetails.destinationAirportName) newRouteDesc += `${newRouteDesc ? ' to: ' : 'To: '}${newRouteDetails.destinationAirportName}`;
            if (!newRouteDesc && prev.routeDetails?.routeDescription?.includes('Manually entered')) {
                // Keep manual if both names are cleared
                newRouteDesc = prev.routeDetails.routeDescription;
            } else if (!newRouteDesc && prev.routeDetails?.routeDescription) {
                 newRouteDesc = prev.routeDetails.routeDescription; // Preserve if not enough data to auto-generate fully
            }

            return {
                ...prev,
                routeDetails: {
                    ...newRouteDetails,
                    routeDescription: newRouteDesc || prev.routeDetails?.routeDescription || '', // Fallback to existing if new is empty
                    flightDataSource: 'AirportDB'
                }
            };
        });

    } catch (error: any) {
        console.error(`Error fetching airport ${icao}:`, error);
        if (fieldType === 'origin') setOriginAirportError(error.message);
        else setDestinationAirportError(error.message);
        setOccurrenceReportFormData(prev => {
            const newRouteDetails = { ...prev.routeDetails };
            if (fieldType === 'origin') newRouteDetails.originAirportName = '';
            else newRouteDetails.destinationAirportName = '';
            return { ...prev, routeDetails: newRouteDetails };
        });
    } finally {
        if (fieldType === 'origin') setIsFetchingOriginAirport(false);
        else setIsFetchingDestinationAirport(false);
    }
  };


  const handleBasicInfoSave = () => {
    if (!isAdmin) { toast.error("Access Denied."); return; }
    if (operator && basicInfoForm.name.trim() && basicInfoForm.aocNumber.trim()) {
      updateOperatorBasicInfo(operator.id, { name: basicInfoForm.name, aocNumber: basicInfoForm.aocNumber, logoUrl: basicInfoForm.logoUrl });
      setIsEditingBasicInfo(false);
    } else {
      toast.error("Name and AOC number cannot be empty.");
    }
  };

  const handleRBSDataSave = () => {
    if (!isAdmin) { toast.error("Access Denied."); return; }
    if (!operator) return;
    updateOperatorRBSData(operator.id, {
        complexityFactors: complexityFactorsForm,
        complianceData: complianceDataForm,
        deviationData: { 
            totalFlightCycles: deviationDataForm.totalFlightCycles 
        },
    });
  };

  const handleEconomicTechnicalProfileSave = () => {
    if (!isAdmin) { toast.error("Access Denied."); return; }
    if (!operator) return;
    const { economicIndicatorScore, operatorCategory, hadFatalAccidentLast3Years } = economicTechnicalProfileForm;
    if (economicIndicatorScore === undefined || economicIndicatorScore < 0 || economicIndicatorScore > 5) {
        toast.error("Economic Indicator Score must be between 0 and 5.");
        return;
    }
    if (!operatorCategory) {
        toast.error("Operator Category is required.");
        return;
    }
    updateOperatorMiscData(operator.id, {
        economicIndicatorScore, 
        operatorCategory,
        hadFatalAccidentLast3Years
    });
    toast.success("Economic and Technical Profile updated.");
  };
  
  const handleDeleteOperator = () => {
    if (!isAdmin) { toast.error("Access Denied."); return; }
    if (operator && window.confirm(`Are you sure you want to delete operator "${operator.name}"? This action cannot be undone.`)) {
      deleteOperator(operator.id);
      navigate('/');
    }
  };

  const openAddOccurrenceReportModal = () => {
    if (!isAdmin) { toast.error("Access Denied."); return; }
    setEditingOccurrenceReport(null);
    const defaultFormData = { ...initialOccurrenceReportFormState, 
        location: {latitude: undefined, longitude: undefined, addressString: undefined }, 
        weatherForecast: {},
        routeDetails: { 
            originAirportICAO: '', destinationAirportICAO: '', 
            originAirportName: '', destinationAirportName: '', // Reset names
            routeDescription: '', flightDataSource: 'Manual' 
        }
    };
    setOccurrenceReportFormData(defaultFormData);
    setSelectedCategoryUsageNotes(OCCURRENCE_CATEGORY_USAGE_NOTES[defaultFormData.category!] || '');
    setFlightDetailsError(null);
    setOriginAirportError(null);
    setDestinationAirportError(null);
    setIsOccurrenceReportModalOpen(true);
  };

  const openEditOccurrenceReportModal = (occurrence: Occurrence) => {
    if (!isAdmin) { toast.error("Access Denied."); return; }
    const category = occurrence.category || OccurrenceCategory.OTHR;
    setEditingOccurrenceReport(occurrence);
    setOccurrenceReportFormData({
      dateTime: occurrence.dateTime ? occurrence.dateTime.slice(0, 16) : DEFAULT_OCCURRENCE_REPORT_FORM_STATE.dateTime,
      type: occurrence.type,
      severity: occurrence.severity,
      description: occurrence.description,
      category: category,
      location: occurrence.location || { latitude: undefined, longitude: undefined, addressString: undefined },
      weatherForecast: occurrence.weatherForecast || {},
      flightNumber: occurrence.flightNumber || '',
      aircraftRegistration: occurrence.aircraftRegistration || '',
      routeDetails: occurrence.routeDetails || { 
          originAirportICAO: '', destinationAirportICAO: '', 
          originAirportName: '', destinationAirportName: '',
          routeDescription: '', flightDataSource: 'Manual' 
      },
    });
    setSelectedCategoryUsageNotes(OCCURRENCE_CATEGORY_USAGE_NOTES[category] || '');
    setFlightDetailsError(null);
    setOriginAirportError(null);
    setDestinationAirportError(null);
    setIsOccurrenceReportModalOpen(true);
  };

  const handleOpenFindingModal = (config: { area?: PredefinedSurveillanceArea; finding?: SurveillanceFinding }) => {
    if (!isAdmin) {
        toast.error("Access Denied.");
        return;
    }
    setFindingModalConfig(config);
    setIsFindingModalOpen(true);
  };

  const handleOccurrenceReportFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    
    if (name === 'originAirportICAO' || name === 'destinationAirportICAO' || name === 'routeDescription') {
        const isICAOField = name === 'originAirportICAO' || name === 'destinationAirportICAO';
        const fieldType = name === 'originAirportICAO' ? 'origin' : 'destination';

        setOccurrenceReportFormData(prev => ({
            ...prev,
            routeDetails: {
                ...(prev.routeDetails || { originAirportICAO: '', destinationAirportICAO: '', originAirportName: '', destinationAirportName: '', routeDescription: '', flightDataSource: 'Manual' }),
                [name]: value.toUpperCase(),
                flightDataSource: isICAOField && value.length === 4 ? 'AirportDB' : (isICAOField ? 'Manual' : prev.routeDetails?.flightDataSource || 'Manual')
            } as RouteDetails
        }));
        if (isICAOField) {
            fetchAirportDetails(value.toUpperCase(), fieldType);
        }
    } else if (name === 'flightNumber') {
         setOccurrenceReportFormData(prev => ({
            ...prev,
            [name]: value,
            routeDetails: value.trim() === '' ? { 
                originAirportICAO: '', destinationAirportICAO: '',
                originAirportName: '', destinationAirportName: '', 
                routeDescription: '', flightDataSource: 'Manual'
            } : (prev.routeDetails || { originAirportICAO: '', destinationAirportICAO: '', originAirportName: '', destinationAirportName: '', routeDescription: '', flightDataSource: 'Manual' })
        }));
    } else {
        setOccurrenceReportFormData(prev => ({ 
            ...prev, 
            [name]: name === 'category' ? value as OccurrenceCategory : (name === 'type' ? value as OccurrenceType : (name === 'severity' ? value as SeverityLevel : value))
        }));
    }
  };

  const handleLocationInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!isAdmin && !isOccurrenceReportModalOpen && !editingOccurrenceReport) return; 
    
    const { name, value } = e.target;
    const newCoord = value === '' ? undefined : parseFloat(value);

    setOccurrenceReportFormData(prev => {
        const newLocationData: Partial<Location> = {
            ...(prev.location || {}), 
            [name]: newCoord
        }; 
        
        const latIsInvalid = newLocationData.latitude === undefined || isNaN(newLocationData.latitude);
        const lngIsInvalid = newLocationData.longitude === undefined || isNaN(newLocationData.longitude);

        if (latIsInvalid || lngIsInvalid) {
            newLocationData.latitude = name === 'latitude' ? newCoord : prev.location?.latitude; // Keep old if only one is invalid
            newLocationData.longitude = name === 'longitude' ? newCoord : prev.location?.longitude;
            newLocationData.addressString = undefined; 
        } else if (newLocationData.latitude !== undefined && newLocationData.longitude !== undefined) {
             // Only geocode if one of the coordinates that define the point changed to a valid number
             const prevLat = prev.location?.latitude;
             const prevLng = prev.location?.longitude;
             const latChangedAndValid = name === 'latitude' && newCoord !== undefined && !isNaN(newCoord) && newCoord !== prevLat;
             const lngChangedAndValid = name === 'longitude' && newCoord !== undefined && !isNaN(newCoord) && newCoord !== prevLng;

             if (latChangedAndValid || lngChangedAndValid) {
                performReverseGeocoding(newLocationData.latitude, newLocationData.longitude);
             }
        }
        
        return { ...prev, location: newLocationData as Location };
    });
  };


  const handleOccurrenceReportSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) { toast.error("Access Denied."); return; }
    if (!operator) return;
    if(!occurrenceReportFormData.description.trim()){
        toast.error("Description is required for an occurrence.");
        return;
    }
    const occurrenceToSave: Omit<Occurrence, 'id'> = {
        ...occurrenceReportFormData,
        dateTime: new Date(occurrenceReportFormData.dateTime).toISOString(), 
        location: {
            latitude: occurrenceReportFormData.location?.latitude,
            longitude: occurrenceReportFormData.location?.longitude,
            addressString: occurrenceReportFormData.location?.addressString
        },
        routeDetails: {
            originAirportICAO: occurrenceReportFormData.routeDetails?.originAirportICAO,
            destinationAirportICAO: occurrenceReportFormData.routeDetails?.destinationAirportICAO,
            originAirportName: occurrenceReportFormData.routeDetails?.originAirportName,
            destinationAirportName: occurrenceReportFormData.routeDetails?.destinationAirportName,
            routeDescription: occurrenceReportFormData.routeDetails?.routeDescription,
            flightDataSource: occurrenceReportFormData.routeDetails?.flightDataSource
        }
    };

    if (editingOccurrenceReport) {
      updateLegacyOccurrence(operator.id, editingOccurrenceReport.id, occurrenceToSave);
    } else {
      addLegacyOccurrence(operator.id, occurrenceToSave);
    }
    setIsOccurrenceReportModalOpen(false);
  };

  const deleteOccurrenceReport = (occurrenceId: string) => {
    if (!isAdmin) { toast.error("Access Denied."); return; }
    if (operator && window.confirm("Are you sure you want to delete this occurrence report?")) {
      deleteLegacyOccurrence(operator.id, occurrenceId);
    }
  };

  const handleGeneralAiQuerySubmit = async () => { 
    if (!aiClient) {
      setGeneralAiError("AI client is not initialized. Please ensure the API key is correctly configured.");
      toast.error("AI client is not initialized.");
      return;
    }
    if (!generalAiQuery.trim()) {
      setGeneralAiError("Please enter a query for the AI assistant.");
      toast.error("Please enter a query for the AI assistant.");
      return;
    }
    if (!operator) {
      setGeneralAiError("Operator data not available for context.");
      toast.error("Operator data not available for context.");
      return;
    }

    setIsGeneralAiLoading(true);
    setGeneralAiResponse('');
    setGeneralAiError(null);

    let surveillanceFindingsContext = "\nSurveillance Findings Log:\n";
    if (operator.surveillanceFindings && operator.surveillanceFindings.length > 0) {
      operator.surveillanceFindings.forEach(sf => {
        const areaInfo = sf.surveillanceLogCategoryId && sf.predefinedAreaId 
            ? `(Area: ${sf.surveillanceLogCategoryId.split('(')[0].trim()} - ${sf.itemNumber} ${sf.areaDescription}) ` 
            : '';
        surveillanceFindingsContext += `- Finding: "${sf.finding}" ${areaInfo}(Category: ${sf.findingCategory}, Target: ${new Date(sf.targetCompletionDate).toLocaleDateString()}, Status: ${sf.isCompleted ? `Completed on ${sf.actualCompletionDate ? new Date(sf.actualCompletionDate).toLocaleDateString() : 'N/A'}` : 'Open'})\n  RCA: ${sf.rootCauseAnalysis || 'N/A'}\n  CAP: ${sf.correctiveActionPlan || 'N/A'}\n`;
      });
    } else {
      surveillanceFindingsContext += "No surveillance findings recorded.\n";
    }

    let occurrenceReportsContext = "\nOccurrence Reports:\n";
    if (operator.legacyRiskFactors.occurrences && operator.legacyRiskFactors.occurrences.length > 0) {
      operator.legacyRiskFactors.occurrences.forEach(occ => {
        const locationStr = occ.location?.addressString 
            ? occ.location.addressString 
            : (occ.location?.latitude && occ.location?.longitude ? `Lat: ${occ.location.latitude.toFixed(4)}, Lon: ${occ.location.longitude.toFixed(4)}` : 'N/A');
        
        let weatherOutput = 'Weather N/A';
        if(occ.weatherForecast){
            const parts = [];
            if(occ.weatherForecast.weatherDescription) parts.push(occ.weatherForecast.weatherDescription);
            if(occ.weatherForecast.temperature !== undefined) parts.push(`Temp: ${occ.weatherForecast.temperature.toFixed(1)}°C`);
            if(occ.weatherForecast.windSpeed !== undefined) parts.push(`Wind: ${occ.weatherForecast.windSpeed.toFixed(1)} km/h`);
            if(parts.length > 0) weatherOutput = parts.join(', ');
        }
        const flightInfo = [];
        if (occ.flightNumber) flightInfo.push(`Flight No: ${occ.flightNumber}`);
        if (occ.aircraftRegistration) flightInfo.push(`Aircraft Reg: ${occ.aircraftRegistration}`);
        const flightInfoStr = flightInfo.length > 0 ? ` (${flightInfo.join(', ')})` : '';

        const routeInfoParts = [];
        if (occ.routeDetails?.originAirportName) routeInfoParts.push(`Origin: ${occ.routeDetails.originAirportICAO} (${occ.routeDetails.originAirportName})`);
        else if(occ.routeDetails?.originAirportICAO) routeInfoParts.push(`Origin: ${occ.routeDetails.originAirportICAO}`);

        if (occ.routeDetails?.destinationAirportName) routeInfoParts.push(`Dest: ${occ.routeDetails.destinationAirportICAO} (${occ.routeDetails.destinationAirportName})`);
        else if(occ.routeDetails?.destinationAirportICAO) routeInfoParts.push(`Dest: ${occ.routeDetails.destinationAirportICAO}`);
        
        if (occ.routeDetails?.routeDescription) routeInfoParts.push(`Route Desc: ${occ.routeDetails.routeDescription}`);
        if (occ.routeDetails?.flightDataSource && occ.routeDetails.flightDataSource !== 'Manual') routeInfoParts.push(`(Source: ${occ.routeDetails.flightDataSource})`);
        const routeInfoStr = routeInfoParts.length > 0 ? `Route: ${routeInfoParts.join('; ')}` : 'Route N/A';


        occurrenceReportsContext += `- DateTime: ${new Date(occ.dateTime).toLocaleString()}${flightInfoStr}, Type: ${occ.type}, Category: ${occ.category || 'N/A'}, Severity: ${occ.severity}, Loc: ${locationStr}, ${weatherOutput}, ${routeInfoStr}, Desc: "${occ.description}"\n`;
      });
    } else {
      occurrenceReportsContext += "No occurrence reports recorded.\n";
    }

    let financialContext = "\nFinancial and Economic Profile:\n";
    if (operator.financialReportText) {
        financialContext += `Latest Financial Summary: ${operator.financialReportText}\n`;
        if (operator.financialReportSources && operator.financialReportSources.length > 0) {
            financialContext += `Sources: ${operator.financialReportSources.map(s => `${s.title} (${s.uri})`).join(', ')}\n`;
        }
    } else {
        financialContext += "No financial report data available for this operator.\n";
    }
     financialContext += `Stated Economic Indicator Score (0-5, lower is better for chart): ${operator.economicIndicatorScore?.toFixed(1) ?? 'N/A'}\n`;
     if (operator.economicFactors) {
        financialContext += `Detailed Economic Factors (0-10, higher is worse):\n`;
        financialContext += `  Liquidity: ${operator.economicFactors.liquidity.toFixed(1)}\n`;
        financialContext += `  Short-Term Debt: ${operator.economicFactors.shortTermDebt.toFixed(1)}\n`;
        financialContext += `  Long-Term Debt: ${operator.economicFactors.longTermDebt.toFixed(1)}\n`;
        financialContext += `  Decapitalization: ${operator.economicFactors.decapitalization.toFixed(1)}\n`;
        financialContext += `  Profitability/Cash Flows: ${operator.economicFactors.profitabilityAndCashFlows.toFixed(1)}\n`;
     }


    const operatorContext = `
      Operator Name: ${operator.name}
      AOC Number: ${operator.aocNumber}
      Exposure Level: ${operator.exposureLevel} (Score: ${operator.exposureScore})
      Risk Indicator Level (IDR): ${operator.riskIndicatorLevel}
      Overall Performance Score (F(P)): ${(operator.overallPerformanceScore * 100).toFixed(2)}%
      Compliance Factor Score (C(p)): ${(operator.complianceFactorScore * 100).toFixed(1)}% (Source: ${operator.surveillanceFindings && operator.surveillanceFindings.filter(sf => !sf.isCompleted).length > 0 ? 'Open Surveillance Findings' : 'Manual Compliance Data'})
      Deviation Factor Score (D(p)): ${(operator.deviationFactorScore * 10000).toFixed(3)} per 10k cycles (raw: ${operator.deviationFactorScore.toFixed(5)})
      Improvement Factor Score (I(p)): ${(operator.improvementFactorScore * 100).toFixed(1)}%
      ${financialContext}
      ${surveillanceFindingsContext}
      ${occurrenceReportsContext}
    `;

    const prompt = `
      You are an AI assistant for aviation risk management specialists at a regulatory body.
      Your goal is to provide concise, insightful, and actionable information in English based on the provided operator data and the user's query.
      Focus on safety, risk assessment, compliance with aviation regulations (e.g., ICAO standards, local CASRs), and potential areas for surveillance or investigation.
      Consider the operator's financial profile (including their stated Economic Indicator Score, the AI-generated financial summary, its sources, and the detailed Economic Factors where higher values from 0-10 indicate worse conditions), surveillance findings (including their area, category and target dates) and occurrence reports (including their ECCAIRS category, flight number, aircraft registration, location/address, general weather forecast, and route details including flight data source if available) if they seem relevant to the user's query.
      Provide a plain text response only. Do not use any markdown formatting, including asterisks for bolding or italics.
      
      Operator Context:
      ${operatorContext}

      User Query:
      "${generalAiQuery}"

      Based on this context and query, please provide your analysis. Be specific and practical. If regulatory documents are relevant, mention them.
    `;
    setGeneralAiPromptSent(prompt); 

    try {
      const response: GenerateContentResponse = await aiClient.models.generateContent({
        model: 'gemini-2.5-flash-preview-04-17',
        contents: prompt,
      });
       if (!response.text || response.text.trim() === '') {
        throw new Error("AI returned an empty response.");
      }
      setGeneralAiResponse(response.text);
    } catch (error: any) {
      console.error("Error querying Gemini API:", error);
      setGeneralAiError(`Failed to get response from AI: ${error.message || 'Unknown error. Check console for details.'}`);
      setGeneralAiResponse('');
    } finally {
      setIsGeneralAiLoading(false);
    }
  };

  const handleInspectorAiQuerySubmit = async () => {
    if (!aiClient) {
      setInspectorAiError("AI client is not initialized. Please ensure the API key is correctly configured.");
      toast.error("AI client for Inspector Agent is not initialized.");
      return;
    }
    if (!inspectorAiQuery.trim()) {
      setInspectorAiError("Please enter a query for the AI Safety Inspector.");
      toast.error("Please enter a query for the AI Safety Inspector.");
      return;
    }
    if (!operator) {
      setInspectorAiError("Operator data not available for context.");
      toast.error("Operator data not available for AI Safety Inspector context.");
      return;
    }

    setIsInspectorAiLoading(true);
    setInspectorAiResponse('');
    setInspectorAiError(null);

    let contextString = `Operator: ${operator.name} (AOC: ${operator.aocNumber})\n`;
    contextString += `RBS Exposure Level: ${operator.exposureLevel} (Score: ${operator.exposureScore.toFixed(2)})\n`;
    contextString += `RBS Risk Indicator (IDR): ${operator.riskIndicatorLevel}\n`;
    contextString += `RBS Overall Performance F(P): ${(operator.overallPerformanceScore * 100).toFixed(1)}%\n`;
    contextString += `RBS C(p) Score: ${(operator.complianceFactorScore * 100).toFixed(1)}%\n`;
    contextString += `RBS D(p) Score: ${(operator.deviationFactorScore * 10000).toFixed(3)}/10k cycles\n`;
    contextString += `RBS I(p) Score: ${(operator.improvementFactorScore * 100).toFixed(1)}%\n`;
    contextString += `Suggested Surveillance Cycle: ${operator.suggestedSurveillanceCycleMonths} months\n`;
    contextString += `Operator Category: ${operator.operatorCategory || 'N/A'}\n`;
    contextString += `Had Fatal Accident (3 yrs): ${operator.hadFatalAccidentLast3Years ? 'Yes' : 'No'}\n`;
    contextString += `Economic Indicator Score (0-5, lower is better for chart): ${operator.economicIndicatorScore?.toFixed(1) ?? 'N/A'}\n`;
    if(operator.financialReportText) {
        contextString += `\nAI Financial Summary:\n${operator.financialReportText}\n`;
        if(operator.financialReportSources && operator.financialReportSources.length > 0){
            contextString += `Financial Summary Sources: ${operator.financialReportSources.map(s => s.title).join(', ')}\n`;
        }
    }
    if (operator.economicFactors) {
        contextString += `Detailed Economic Factors (0-10, higher score = worse condition):\n`;
        contextString += `  Liquidity: ${operator.economicFactors.liquidity.toFixed(1)}\n`;
        contextString += `  Short-Term Debt: ${operator.economicFactors.shortTermDebt.toFixed(1)}\n`;
        contextString += `  Long-Term Debt: ${operator.economicFactors.longTermDebt.toFixed(1)}\n`;
        contextString += `  Decapitalization: ${operator.economicFactors.decapitalization.toFixed(1)}\n`;
        contextString += `  Profitability/Cash Flows: ${operator.economicFactors.profitabilityAndCashFlows.toFixed(1)}\n`;
        if(operator.economicFactors.lastUpdatedByAI) contextString += `  (Last updated: ${new Date(operator.economicFactors.lastUpdatedByAI).toLocaleDateString()})\n`;
    }


    contextString += "\n--- Surveillance Findings Log ---\n";
    if (operator.surveillanceFindings && operator.surveillanceFindings.length > 0) {
        operator.surveillanceFindings.forEach(sf => {
            const areaDetails = PREDEFINED_SURVEILLANCE_AREAS.find(pa => pa.id === sf.predefinedAreaId);
            contextString += `Finding: "${sf.finding}"\n`;
            contextString += `  Area: ${sf.surveillanceLogCategoryId ? sf.surveillanceLogCategoryId.split('(')[0].trim() : 'N/A'} - ${areaDetails ? `${areaDetails.itemNumber} ${areaDetails.areaDescription}` : 'Custom Area'}\n`;
            contextString += `  Category: ${sf.findingCategory}\n`;
            contextString += `  RCA: ${sf.rootCauseAnalysis || 'N/A'}\n  Hazard ID (CAP): ${sf.correctiveActionPlan || 'N/A'}\n  Risk Assessment: ${sf.riskAssessment || 'N/A'}\n  Mitigation Action: ${sf.correctiveActionTaken || 'N/A'}\n`;
            contextString += `  Status: ${sf.isCompleted ? `Completed (${new Date(sf.actualCompletionDate || Date.now()).toLocaleDateString()})` : `Open (Target: ${new Date(sf.targetCompletionDate).toLocaleDateString()})`}\n\n`;
        });
    } else {
        contextString += "No surveillance findings recorded.\n";
    }

    contextString += "\n--- Occurrence Reports ---\n";
    if (operator.legacyRiskFactors.occurrences && operator.legacyRiskFactors.occurrences.length > 0) {
        operator.legacyRiskFactors.occurrences.forEach(occ => {
            contextString += `Occurrence Date: ${new Date(occ.dateTime).toLocaleString()}\n`;
            contextString += `  Type: ${occ.type}, Category: ${occ.category ? OCCURRENCE_CATEGORY_LABELS[occ.category] : 'N/A'} (${occ.category || 'N/A'}), Severity: ${occ.severity}\n`;
            contextString += `  Flight: ${occ.flightNumber || 'N/A'}, Aircraft: ${occ.aircraftRegistration || 'N/A'}\n`;
            let routeDisplay = `${occ.routeDetails?.originAirportICAO || 'N/A'} (${occ.routeDetails?.originAirportName || 'Name N/A'}) -> ${occ.routeDetails?.destinationAirportICAO || 'N/A'} (${occ.routeDetails?.destinationAirportName || 'Name N/A'})`;
            if (occ.routeDetails?.flightDataSource && occ.routeDetails.flightDataSource !== 'Manual') routeDisplay += ` (Src: ${occ.routeDetails.flightDataSource})`;
            contextString += `  Route: ${routeDisplay}\n`;
            if (occ.routeDetails?.routeDescription) contextString += `    Route Desc: ${occ.routeDetails.routeDescription}\n`;
            contextString += `  Location: ${occ.location?.addressString || (occ.location?.latitude ? `${occ.location.latitude.toFixed(3)},${occ.location.longitude?.toFixed(3)}` : 'N/A')}\n`;
            if (occ.weatherForecast?.weatherDescription) {
                contextString += `  Weather: ${occ.weatherForecast.weatherDescription} (Temp: ${occ.weatherForecast.temperature?.toFixed(1)}°C, Wind: ${occ.weatherForecast.windSpeed?.toFixed(1)} km/h)\n`;
            }
            contextString += `  Description: "${occ.description}"\n\n`;
        });
    } else {
        contextString += "No occurrence reports recorded.\n";
    }
    
    contextString += "\n--- Surveillance Program Log Summary ---\n";
    if(operator.surveillanceLogs && operator.surveillanceLogs.length > 0){
        const logSummary: Record<string, { done: number, notDone: number, total: number }> = {};
        
        PREDEFINED_SURVEILLANCE_AREAS.forEach(pa => {
            if (!logSummary[pa.category]) {
                logSummary[pa.category] = { done: 0, notDone: 0, total: 0};
            }
            logSummary[pa.category].total++;
            const logItem = operator.surveillanceLogs?.find(sl => sl.predefinedAreaId === pa.id);
            if (logItem?.status === 'Done') {
                logSummary[pa.category].done++;
            } else { 
                logSummary[pa.category].notDone++;
            }
        });

        Object.entries(logSummary).forEach(([cat, counts]) => {
            contextString += `${cat.split('(')[0].trim()}: ${counts.done} Done / ${counts.total} Total Areas.\n`;
        });
        if(Object.keys(logSummary).length === 0) contextString += "No areas with status in surveillance program log.\n";
    } else {
        contextString += "Surveillance program log is empty (all areas effectively 'Not Done').\n";
    }


    const prompt = `
      You are an AI Aviation Safety Inspector working for the DGCA Indonesia. You are reviewing the data for operator ${operator.name} (AOC: ${operator.aocNumber}).
      Your analysis must be strictly guided by Indonesian Civil Aviation Safety Regulations (CASR) and relevant ICAO Annexes.
      Based on the detailed operator data provided below and the user's query, provide a concise and actionable analysis in English.
      Focus on identifying safety risks, potential compliance issues (with CASR and ICAO Annexes), and suggest areas for further surveillance or investigation.
      Cite specific data points from the context to support your analysis. Use plain text for your response, without any markdown formatting.

      Operator Data Context:
      ---
      ${contextString}
      ---

      User Query: "${inspectorAiQuery}"

      AI Safety Inspector's Analysis (DGCA Indonesia Perspective, adhering to CASR and ICAO Annexes):
    `;
    setInspectorAiPromptSent(prompt); 

    try {
      const response: GenerateContentResponse = await aiClient.models.generateContent({
        model: 'gemini-2.5-flash-preview-04-17',
        contents: prompt,
      });
      if (!response.text || response.text.trim() === '') {
        throw new Error("AI Safety Inspector returned an empty response.");
      }
      setInspectorAiResponse(response.text);
    } catch (error: any) {
      console.error("Error querying Gemini API for AI Safety Inspector:", error);
      setInspectorAiError(`AI Inspector response failed: ${error.message || 'Unknown AI error.'}`);
      setInspectorAiResponse('');
    } finally {
      setIsInspectorAiLoading(false);
    }
  };

  const handleFinancialFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
        const allowedTypes = [
            'application/pdf',
            'application/vnd.ms-excel', 
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        ];
        if (!allowedTypes.includes(file.type)) {
            setFinancialReportFileError(`Invalid file type. Please upload a PDF, XLS, or XLSX file. Detected: ${file.type}`);
            setFinancialReportFile(null);
            event.target.value = ''; 
            return;
        }
        if (file.size > 5 * 1024 * 1024) { // 5MB limit
            setFinancialReportFileError('File size exceeds 5MB. Please upload a smaller file.');
            setFinancialReportFile(null);
            event.target.value = ''; 
            return;
        }
        setFinancialReportFile(file);
        setFinancialReportFileError(null);
    } else {
        setFinancialReportFile(null);
        setFinancialReportFileError(null);
    }
  };


  const handleFetchFinancialReport = async () => {
    if (!aiClient) {
      const errorMsg = "AI client is not initialized.";
      setFinancialReportError(errorMsg);
      toast.error(errorMsg);
      return;
    }
    if(!operator) {
        const errorMsg = "Operator data not available.";
        setFinancialReportError(errorMsg);
        toast.error(errorMsg);
        return;
    }

    setIsFinancialReportLoading(true);
    setFinancialReportError(null);
    const toastId = 'financial-report-fetch';
    toast.loading(financialReportFile ? 'Fetching financial data using uploaded file...' : 'Fetching financial data using web search...', { id: toastId });

    let filePart = null;
    if (financialReportFile) {
        try {
            const base64Data = await new Promise<string>((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = () => resolve((reader.result as string).split(',')[1]);
                reader.onerror = error => reject(error);
                reader.readAsDataURL(financialReportFile);
            });
            filePart = {
                inlineData: {
                    mimeType: financialReportFile.type,
                    data: base64Data,
                },
            };
        } catch (error: any) {
            setIsFinancialReportLoading(false);
            setFinancialReportError(`Error reading file: ${error.message}`);
            toast.error(`Error reading file: ${error.message}`, { id: toastId });
            return;
        }
    }
    
    let summaryInstruction;
    if (filePart) {
        summaryInstruction = `1. Provide a concise summary in English of its financial standing. The primary source for this summary MUST be the content of the provided document. Focus on revenue trends, profitability (net profit/loss), debt situation, and any significant financial events or outlook. Extract key figures if possible from the document.`;
    } else {
        summaryInstruction = `1. Provide a concise summary in English of its latest publicly available financial report and key financial standing. Focus on revenue trends, profitability (net profit/loss), debt situation, and any significant financial events or outlook. Extract key figures if possible. Cite your sources from public web search.`;
    }

    const summaryPrompt = `
      For the airline operator "${operator.name}" (AOC Holder: ${operator.aocNumber}):
      ${summaryInstruction}
      2. Based on this summary and adhering to the AESA "Methodology of Safety Assessment for CAT Operators - Economic Area" (Doc Ref: A-SPI-RIA-01 Iss. 2.4), provide an overall Economic Indicator Score. This score should be a single number between 0.0 (very good financial health, for charting purposes where lower is better on a 0-5 scale) and 5.0 (very poor financial health).
      3. Also provide the five detailed Economic Indexes. Each index should be a single numeric score from 0.0 to 10.0, where a higher score indicates a worse economic situation. The five indexes are: "Liquidity", "Short-Term Debt", "Long-Term Debt", "Decapitalization", and "Profitability & Cash Flows".
      4. If possible, for each of the five detailed Economic Indexes, include a sub-object detailing the key financial ratios or factors you considered and their values that contributed to the score (e.g., for "Liquidity", you might include "Liquidity Ratio" and "Acid Test Ratio" values).

      Return your response ONLY as a JSON object with the following top-level keys: "financialSummaryText", "sources", "overallEconomicIndicatorScore", and "detailedEconomicFactors".
      The "detailedEconomicFactors" object should contain keys: "liquidity", "shortTermDebt", "longTermDebt", "decapitalization", "profitabilityAndCashFlows" (each with a 0-10 score).
      Optionally, "detailedEconomicFactors" can also contain "liquidityDetails", "shortTermDebtDetails", etc., for the sub-components.

      Example structure for "detailedEconomicFactors":
      {
        "liquidity": 3.5,
        "shortTermDebt": 4.0,
        "decapitalization": 2.0,
        "longTermDebt": 6.1,
        "profitabilityAndCashFlows": 1.5,
        "liquidityDetails": { "Liquidity Ratio": "150%", "Acid Test Ratio": "110%" }
      }
    `;
    
    const generateContentConfig: any = { model: 'gemini-2.5-flash-preview-04-17' };
    if (filePart) {
        generateContentConfig.contents = { parts: [filePart, { text: summaryPrompt }] };
        generateContentConfig.config = { responseMimeType: "application/json" };
    } else {
        generateContentConfig.contents = summaryPrompt;
        generateContentConfig.config = { tools: [{ googleSearch: {} }] }; 
    }
    
    try {
      const response: GenerateContentResponse = await aiClient.models.generateContent(generateContentConfig);
      
      const responseText = response.text;
      if (!responseText || responseText.trim() === '') {
        throw new Error("AI returned an empty response for financial data.");
      }
      
      let jsonStr = responseText.trim();
      // For web search, Gemini wraps JSON in ```json ```, for file upload with responseMimeType: "application/json" it does not.
      if (!filePart) { 
          const fenceRegex = /```(?:json)?\s*\n?([\s\S]*?)\n?\s*```/; 
          const match = jsonStr.match(fenceRegex);
          if (match && match[1]) {
            jsonStr = match[1].trim();
          }
      }

      let parsedData;
      try {
        parsedData = JSON.parse(jsonStr);
      } catch (e: any) {
        console.error("Failed to parse AI financial response:", e, "Raw response received:", responseText, "Processed JSON string:", jsonStr);
        throw new Error(`Failed to parse AI financial response: ${e.message}. Response snippet: ${jsonStr.substring(0,100)}`);
      }
      
      const reportText = parsedData.financialSummaryText || "AI did not provide a financial summary.";
      
      let sourcesDataResult: GroundingSource[] = parsedData.sources || [];
      if (filePart && financialReportFile) {
          sourcesDataResult = [{ uri: `file://${financialReportFile.name}`, title: `Uploaded: ${financialReportFile.name}` }, ...sourcesDataResult];
      } else if (!filePart && response.candidates?.[0]?.groundingMetadata?.groundingChunks) {
           const webSources = response.candidates[0].groundingMetadata.groundingChunks
              .filter(chunk => chunk.web)
              .map(chunk => ({
                  uri: chunk.web!.uri!,
                  title: chunk.web!.title || chunk.web!.uri!,
              }));
          sourcesDataResult = [...sourcesDataResult, ...webSources];
      }
      sourcesDataResult = sourcesDataResult.filter((source, index, self) =>
          index === self.findIndex((s) => (s.uri === source.uri && s.title === source.title))
      );
      
      const overallScore = parsedData.overallEconomicIndicatorScore;
      const detailedFactors = parsedData.detailedEconomicFactors;

      let derivedOverallScore: number | undefined = undefined;
      if (typeof overallScore === 'number' && overallScore >= 0 && overallScore <= 5) {
        derivedOverallScore = overallScore;
      } else {
        setFinancialReportError(prev => (prev ? prev + "\n" : "") + "AI returned an invalid overall economic score format or value.");
      }

      let derivedDetailedFactors: EconomicFactors | undefined = undefined;
      if (detailedFactors && typeof detailedFactors.liquidity === 'number') { 
        derivedDetailedFactors = {
            liquidity: parseFloat(String(detailedFactors.liquidity)) || 0,
            shortTermDebt: parseFloat(String(detailedFactors.shortTermDebt)) || 0,
            longTermDebt: parseFloat(String(detailedFactors.longTermDebt)) || 0,
            decapitalization: parseFloat(String(detailedFactors.decapitalization)) || 0,
            profitabilityAndCashFlows: parseFloat(String(detailedFactors.profitabilityAndCashFlows)) || 0,
            liquidityDetails: detailedFactors.liquidityDetails,
            shortTermDebtDetails: detailedFactors.shortTermDebtDetails,
            longTermDebtDetails: detailedFactors.longTermDebtDetails,
            decapitalizationDetails: detailedFactors.decapitalizationDetails,
            profitabilityAndCashFlowsDetails: detailedFactors.profitabilityAndCashFlowsDetails,
            lastUpdatedByAI: new Date().toISOString()
        };
      } else {
         setFinancialReportError(prev => (prev ? prev + "\n" : "") + "AI did not provide valid detailed economic factors.");
      }
      
      updateOperatorMiscData(operator.id, { 
        financialReportText: reportText, 
        financialReportSources: sourcesDataResult,
        economicIndicatorScore: derivedOverallScore ?? operator.economicIndicatorScore, 
        economicFactors: derivedDetailedFactors ?? operator.economicFactors, 
        economicIndicatorScoreLastUpdatedByAI: derivedOverallScore !== undefined ? new Date().toISOString() : operator.economicIndicatorScoreLastUpdatedByAI,
      });

      if(derivedOverallScore !== undefined) {
        setEconomicTechnicalProfileForm(prev => ({...prev, economicIndicatorScore: derivedOverallScore}));
      }
      
      if (derivedOverallScore !== undefined && derivedDetailedFactors !== undefined) {
        toast.success(`Financial report, overall score, and detailed factors (from ${financialReportFile ? 'uploaded file' : 'web search'}) fetched and saved.`, { id: toastId, duration: 4000 });
      } else {
        let partialSuccessMsg = `Financial report summary (from ${financialReportFile ? 'uploaded file' : 'web search'}) fetched. `;
        if (derivedOverallScore === undefined) partialSuccessMsg += "Overall score generation failed. ";
        if (derivedDetailedFactors === undefined) partialSuccessMsg += "Detailed factors generation failed. ";
        toast.error(partialSuccessMsg + "Please review and set manually if needed.", { id: toastId, duration: 7000 });
      }

    } catch (error: any) {
      console.error("Error fetching financial data via Gemini:", error);
      const errorMsg = `Failed to fetch financial data: ${error.message || 'Unknown AI error.'}`;
      setFinancialReportError(errorMsg); 
      updateOperatorMiscData(operator.id, { 
          financialReportText: (operator.financialReportText || '') + `\n\nFetch Error (${financialReportFile ? 'uploaded file' : 'web search'}): ${errorMsg}`, 
      });
      toast.error(errorMsg, { id: toastId, duration: 5000 });
    } finally {
      setIsFinancialReportLoading(false);
    }
  };

  const handleSuggestRBSDataWithAI = async () => {
    if (!aiClient) {
        const errorMsg = "AI client is not initialized.";
        setAiRBSDataError(errorMsg);
        toast.error(errorMsg);
        return;
    }
    if (!operator) {
        const errorMsg = "Operator data not available.";
        setAiRBSDataError(errorMsg);
        toast.error(errorMsg);
        return;
    }
    setIsAiRBSDataLoading(true);
    setAiRBSDataError(null);
    const toastId = 'rbs-data-suggestion';
    toast.loading('Suggesting RBS data with AI...', { id: toastId });

    const prompt = `
      For an airline operator named "${operator.name}" with AOC number "${operator.aocNumber}", provide realistic estimates in English for the following Risk-Based Surveillance (RBS) input parameters.
      Return your response ONLY as a JSON object with the following structure and keys. Ensure all numeric values are numbers, not strings. Ensure 'hasInternationalOps' is a boolean.

      {
        "complexityFactors": {
          "annualFlightCount": <number>,
          "numEmployees": <number>,
          "numAircraft": <number>,
          "numAircraftModels": <number>,
          "numDestinations": <number>,
          "hasInternationalOps": <boolean>,
          "avgFleetAge": <number>,
          "numDomesticBases": <number>
        },
        "complianceData": {
          "findings": {
            "ncp": <number>,
            "ncf": <number>,
            "nad": <number>
          },
          "totalChecklistItems": <number>
        },
        "deviationData": {
          "totalFlightCycles": <number>
        }
      }
    `;

    try {
      const response: GenerateContentResponse = await aiClient.models.generateContent({
        model: 'gemini-2.5-flash-preview-04-17',
        contents: prompt,
        config: { responseMimeType: "application/json" }
      });

      const responseText = response.text;
      if (!responseText || responseText.trim() === '') {
        throw new Error("AI returned an empty response for RBS data suggestions.");
      }
      let jsonStr = responseText.trim();
      const fenceRegex = /```(?:json)?\s*\n?([\s\S]*?)\n?\s*```/; 
      const match = jsonStr.match(fenceRegex);
      if (match && match[1]) {
        jsonStr = match[1].trim();
      }

      const suggestedData = JSON.parse(jsonStr);

      if (suggestedData.complexityFactors) {
        setComplexityFactorsForm(prev => ({ ...prev, ...suggestedData.complexityFactors }));
      }
      if (suggestedData.complianceData) {
        setComplianceDataForm(prev => ({
          ...prev,
          findings: { ...prev.findings, ...suggestedData.complianceData.findings },
          totalChecklistItems: suggestedData.complianceData.totalChecklistItems ?? prev.totalChecklistItems,
        }));
      }
      if (suggestedData.deviationData && suggestedData.deviationData.totalFlightCycles !== undefined) {
        setDeviationDataForm(prev => ({ ...prev, totalFlightCycles: suggestedData.deviationData.totalFlightCycles }));
      }
      toast.success('AI suggestions loaded into the form. Review and save.', { id: toastId, duration: 5000 });

    } catch (error: any) {
      console.error("Error getting RBS data suggestions from AI:", error);
      const errorMsg = `AI suggestion failed: ${error.message || 'Unknown AI error.'}`;
      setAiRBSDataError(errorMsg);
      toast.error(errorMsg, { id: toastId });
    } finally {
      setIsAiRBSDataLoading(false);
    }
  };


  const occurrenceReportSeverityData = useMemo(() => {
    if (!operator || !operator.legacyRiskFactors) return [];
    const counts = operator.legacyRiskFactors.occurrences.reduce((acc, occ) => {
      acc[occ.severity] = (acc[occ.severity] || 0) + 1;
      return acc;
    }, {} as Record<SeverityLevel, number>);
    return Object.entries(counts).map(([name, value]) => ({ name: name as SeverityLevel, value }));
  }, [operator]);

  const usesDynamicComplianceFactor = useMemo(() => {
    return operator?.surveillanceFindings && operator.surveillanceFindings.filter(sf => !sf.isCompleted).length > 0;
  }, [operator]);

  const handleExportOperatorData = () => {
    if (operator) {
      // Create a snapshot of the operator data that includes all current (potentially unsaved)
      // form values. This ensures the export matches what the user sees on screen.
      const operatorDataForExport = {
        ...operator, // Start with the saved operator state

        // Overwrite with values from the basic info form.
        // This form's state is updated on edit and reflects what's in the input boxes.
        name: basicInfoForm.name,
        aocNumber: basicInfoForm.aocNumber,
        logoUrl: basicInfoForm.logoUrl,

        // Overwrite with the data from the main RBS calculation form
        complexityFactors: complexityFactorsForm,
        complianceData: complianceDataForm,
        deviationData: {
          ...operator.deviationData, // Important: keep calculated counts (e.g., accidents) from the base state
          totalFlightCycles: deviationDataForm.totalFlightCycles, // Only update the value that is manually editable on the form
        },
        // improvementData is calculated in the context and doesn't have a dedicated form section, so it's already correct in 'operator'

        // Overwrite with the data from the economic profile form
        economicIndicatorScore: economicTechnicalProfileForm.economicIndicatorScore,
        operatorCategory: economicTechnicalProfileForm.operatorCategory,
        hadFatalAccidentLast3Years: economicTechnicalProfileForm.hadFatalAccidentLast3Years,
        
        // AI-generated data like economicFactors, financialReportText, etc. are saved
        // directly to the operator state when fetched, so they are already included in the initial spread.
      };

      exportToJSON(operatorDataForExport, `operator_${operatorDataForExport.aocNumber}_export.json`);
      toast.success(`Operator data for ${operatorDataForExport.name} exported to JSON.`);
    }
  };

  const handleJsonFileImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !operatorId) {
      if (event.target) event.target.value = '';
      return;
    }

    setIsProcessingJsonImport(true);
    const toastId = toast.loading('Processing JSON file...');

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const text = e.target?.result;
        if (typeof text !== 'string') throw new Error('Failed to read file content.');
        const jsonData = JSON.parse(text) as Partial<Operator>;
        if (typeof jsonData !== 'object' || jsonData === null) throw new Error('Invalid JSON format: Not an object.');

        if (jsonData.id && jsonData.id !== operatorId) {
          setJsonDataForImport(jsonData);
          setIsImportConfirmModalOpen(true);
          toast.dismiss(toastId);
          setIsProcessingJsonImport(false);
        } else {
          importOperatorData(operatorId, jsonData);
          toast.dismiss(toastId);
          setIsProcessingJsonImport(false);
          if (event.target) event.target.value = '';
        }
      } catch (error: any) {
        console.error("Error processing JSON import:", error);
        toast.error(`Import failed: ${error.message}`, { id: toastId });
        setIsProcessingJsonImport(false);
        if (event.target) event.target.value = '';
      }
    };
    reader.onerror = () => {
      toast.error('Failed to read the selected file.', { id: toastId });
      setIsProcessingJsonImport(false);
      if (event.target) event.target.value = '';
    };
    reader.readAsText(file);
  };

  const handleConfirmImport = () => {
    if (jsonDataForImport && operatorId) {
      importOperatorData(operatorId, jsonDataForImport);
    } else {
      toast.error('Import failed: Data was lost.');
    }
    setIsImportConfirmModalOpen(false);
    setJsonDataForImport(null);
    if (jsonFileInputRef.current) jsonFileInputRef.current.value = '';
  };

  const handleCancelImport = () => {
    setIsImportConfirmModalOpen(false);
    setJsonDataForImport(null);
    toast.error('Import aborted by user.');
    if (jsonFileInputRef.current) jsonFileInputRef.current.value = '';
  };
  
  const handleHeatmapCellClick = (findings: SurveillanceFinding[], title: string) => {
    setFindingsForDisplay(findings);
    setFindingsDisplayModalTitle(title);
    setIsFindingsDisplayModalOpen(true);
  };


  const isSystemInitializing = (API_KEY && !aiClient && !generalAiError && !inspectorAiError && !financialReportError && !aiRBSDataError) || isAuthLoading;

  if (isLoadingOperator || isSystemInitializing) {
    return (
      <div className="flex flex-col justify-center items-center h-64">
        <LoadingSpinner size="lg" />
        <p className="mt-3 text-slate-500">
          {isLoadingOperator ? "Loading Operator Data..." : "Initializing Systems..."}
        </p>
      </div>
    );
  }

  if (!operator) {
    return (
      <div className="text-center py-12">
        <ExclamationTriangleIcon className="mx-auto h-16 w-16 text-red-500" />
        <h2 className="mt-4 text-2xl font-bold text-slate-700">Operator Not Found</h2>
        <p className="mt-2 text-slate-500">The operator with ID "{operatorId}" could not be found, or you do not have permission to view it.</p>
        <Link to="/" className="mt-6 inline-block bg-brand-primary hover:bg-blue-800 text-white font-semibold py-2 px-4 rounded-lg">
          Go to Dashboard
        </Link>
      </div>
    );
  }


  const riskIndicatorLabel = RBS_PERFORMANCE_TO_INDICATOR_LEVEL.find(item => item.level === operator?.riskIndicatorLevel)?.label || "N/A";
  const exposureLevelColor = CHART_HEX_EXPOSURE_LEVEL_COLORS[operator?.exposureLevel || ExposureLevel.A] || '#ccc';

  const FactorScoreDetail: React.FC<{title: string, score: number, details: Array<{label: string, value: string | number}>, note?: string}> = ({title, score, details, note}) => (
    <div className="bg-slate-50 p-3 rounded-md border border-slate-200">
        <h4 className="text-xs font-semibold text-slate-500 uppercase flex justify-between items-center">
            {title}
            <span className="text-sm font-bold text-slate-700">{(score * 100).toFixed(1)}%</span>
        </h4>
        <ul className="mt-1 space-y-0.5 text-xs">
            {details.map(d => <li key={d.label} className="flex justify-between"><span className="text-slate-600">{d.label}:</span> <span className="font-medium text-slate-800">{d.value}</span></li>)}
        </ul>
        {note && <p className="text-xs text-slate-400 mt-1 italic">{note}</p>}
    </div>
  );

  const createNumberInput = (
      id: keyof ComplexityFactors | keyof ComplianceData | keyof ComplianceFindingCounts | keyof DeviationData | string, 
      value: number, 
      category: string, 
      subCategory?: string,
      isManuallyReadOnly: boolean = false 
    ) => {
    const effectiveReadOnly = !isAdmin || isManuallyReadOnly; 

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (effectiveReadOnly) return;
        const numValue = e.target.value === '' ? 0 : Number(e.target.value);
        if (category === 'complexity') setComplexityFactorsForm(prev => ({...prev, [id as keyof ComplexityFactors]: numValue}));
        else if (category === 'compliance' && subCategory === 'findings') setComplianceDataForm(prev => ({...prev, findings: {...prev.findings, [id as keyof ComplianceFindingCounts]: numValue}}));
        else if (category === 'compliance') setComplianceDataForm(prev => ({...prev, [id as keyof ComplianceData]: numValue}));
        else if (category === 'deviation') setDeviationDataForm(prev => ({...prev, [id as keyof DeviationData]: numValue}));
    };
    return (
        <div className="relative">
            <input 
                type="number" 
                id={String(id)} 
                value={value} 
                onChange={handleChange} 
                className={`mt-1 block w-full p-2 border border-slate-300 rounded-md shadow-sm text-sm ${effectiveReadOnly ? 'bg-slate-100 text-slate-500 cursor-not-allowed' : 'focus:ring-brand-secondary focus:border-brand-secondary'}`}
                readOnly={effectiveReadOnly}
                aria-readonly={effectiveReadOnly}
            />
        </div>
    );
  };

  const exposureLevelsSorted = [ExposureLevel.E, ExposureLevel.D, ExposureLevel.C, ExposureLevel.B, ExposureLevel.A];
  const riskIndicatorLevelsNumerical = [5, 4, 3, 2, 1]; 
  const riskIndicatorLabelsDKPPU = ["Very High", "High", "Medium", "Low", "Very Low"];

  // Calculate inspected areas for RBS Matrix
  const inspectedAreasCount = PREDEFINED_SURVEILLANCE_AREAS.filter(area =>
    operator.surveillanceLogs?.some(log => log.predefinedAreaId === area.id && log.status === 'Done')
  ).length;
  const totalPredefinedAreas = PREDEFINED_SURVEILLANCE_AREAS.length;
  const totalSatisfactoryInspections = operator.surveillanceLogs?.filter(log => log.status === 'Done').length || 0;


  return (
    <div className="space-y-6">
      <div className="bg-white shadow-xl rounded-xl p-6">
        <div className="flex flex-col sm:flex-row justify-between items-start mb-4">
            <div className="flex items-center mb-4 sm:mb-0">
                {operator.logoUrl && <img src={operator.logoUrl} alt={`${operator.name} logo`} className="h-16 w-auto mr-4 rounded border p-1" />}
                <div>
                    <h2 className="text-2xl font-bold text-brand-primary">{operator.name}</h2>
                    <p className="text-slate-600">AOC: {operator.aocNumber}</p>
                </div>
            </div>
            <div className="text-right">
                <p className="text-sm text-slate-500">Suggested Surveillance Cycle:</p>
                <p className="text-2xl font-bold text-brand-secondary">{operator.suggestedSurveillanceCycleMonths} Months</p>
                <p className="text-xs text-slate-500">Matrix Key: {operator.finalRiskCategoryKey}</p>
            </div>
        </div>
        {isAdmin && (
          <div className="flex space-x-2">
              <button onClick={() => setIsEditingBasicInfo(!isEditingBasicInfo)} className="text-sm bg-sky-500 hover:bg-sky-600 text-white font-medium py-1.5 px-3 rounded-md flex items-center">
                  <PencilIcon className="h-4 w-4 mr-1"/> {isEditingBasicInfo ? 'Cancel Edit' : 'Edit Info'}
              </button>
              <button 
                  onClick={handleExportOperatorData} 
                  className="text-sm bg-purple-600 hover:bg-purple-700 text-white font-medium py-1.5 px-3 rounded-md flex items-center"
              >
                  <DownloadIcon className="h-4 w-4 mr-1" /> Export Data (JSON)
              </button>
              <input
                type="file"
                accept=".json"
                ref={jsonFileInputRef}
                onChange={handleJsonFileImport}
                className="hidden"
                disabled={!isAdmin || isProcessingJsonImport}
              />
              <button
                onClick={() => jsonFileInputRef.current?.click()}
                className="text-sm bg-green-600 hover:bg-green-700 text-white font-medium py-1.5 px-3 rounded-md flex items-center disabled:bg-slate-400"
                disabled={!isAdmin || isProcessingJsonImport}
                title="Import operator data from JSON file"
              >
                {isProcessingJsonImport ? <LoadingSpinner size="sm"/> : <UploadIcon className="h-4 w-4 mr-1" />}
                {isProcessingJsonImport ? 'Importing...' : 'Import JSON'}
              </button>
              <button onClick={handleDeleteOperator} className="text-sm bg-red-500 hover:bg-red-600 text-white font-medium py-1.5 px-3 rounded-md flex items-center">
                  <TrashIcon className="h-4 w-4 mr-1"/> Delete Operator
              </button>
          </div>
        )}
        {isEditingBasicInfo && isAdmin && (
          <div className="mt-4 p-3 border border-sky-200 rounded-lg bg-sky-50 space-y-3">
            <div><label className="text-xs font-medium">Name</label><input type="text" value={basicInfoForm.name} onChange={e => setBasicInfoForm({...basicInfoForm, name: e.target.value})} className="w-full p-1.5 border rounded-md text-sm"/></div>
            <div><label className="text-xs font-medium">AOC</label><input type="text" value={basicInfoForm.aocNumber} onChange={e => setBasicInfoForm({...basicInfoForm, aocNumber: e.target.value})} className="w-full p-1.5 border rounded-md text-sm"/></div>
            <div><label className="text-xs font-medium">Logo URL</label><input type="text" value={basicInfoForm.logoUrl} onChange={e => setBasicInfoForm({...basicInfoForm, logoUrl: e.target.value})} className="w-full p-1.5 border rounded-md text-sm"/></div>
            <button onClick={handleBasicInfoSave} className="text-sm bg-green-500 hover:bg-green-600 text-white py-1.5 px-3 rounded-md">Save Info</button>
          </div>
        )}
      </div>

      
        <div className="bg-white shadow-xl rounded-xl p-6">
            <h3 className="text-xl font-semibold text-slate-700 mb-4 flex items-center">
                <AcademicCapIcon className="h-6 w-6 mr-2 text-brand-primary" />
                RBS Scores Overview & Contributing Factors
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6 items-start">
                <div className="space-y-4">
                    <div>
                        <p className="text-sm text-slate-500 uppercase tracking-wider">Exposure Level (FIde)</p>
                        <p className="text-2xl font-bold" style={{color: exposureLevelColor}}>{operator.exposureLevel} - {exposureLevelFullLabels[operator.exposureLevel]}</p>
                        <p className="text-xs text-slate-500">Score: {operator.exposureScore}</p>
                    </div>
                    <div>
                        <p className="text-sm text-slate-500 uppercase tracking-wider">Risk Indicator (IDR/FRp)</p>
                        <p className="text-2xl font-bold text-slate-800">{operator.riskIndicatorLevel} <span className="text-base font-normal">({riskIndicatorLabel})</span></p>
                    </div>
                    <div>
                        <p className="text-sm text-slate-500 uppercase tracking-wider">Performance Score F(P)</p>
                        <p className="text-2xl font-bold text-slate-800">{(operator.overallPerformanceScore * 100).toFixed(2)}%</p>
                    </div>
                </div>
                <div> {} </div>
            </div>

            <div className="mb-6">
                <h4 className="text-lg font-semibold text-slate-700 mb-1">Risk-Based Surveillance Matrix (Regulatory Model)</h4>
                <table className="w-full border-collapse text-xs text-center">
                    <thead>
                        <tr>
                            <th colSpan={2} className="p-2 border border-slate-300 bg-slate-100 font-normal">
                                Exposure Indicator (FIde)
                                <p className="text-xs font-light">(Intersection with RBS frequency)</p>
                            </th>
                            <th colSpan={5} className="p-2 border border-slate-300 bg-brand-primary text-white font-semibold">
                                Risk Indicator (FRp)
                            </th>
                        </tr>
                        <tr>
                            <th className="p-2 border border-slate-300 bg-slate-50 font-semibold">Label</th>
                            <th className="p-2 border border-slate-300 bg-slate-50 font-semibold">Code</th>
                            {riskIndicatorLevelsNumerical.map((ril, index) => (
                                <th key={`ril-header-${ril}`} className="p-2 border border-slate-300 bg-slate-50 font-semibold">
                                    <div>{riskIndicatorLabelsDKPPU[index]}</div>
                                    <div>({ril})</div>
                                </th>
                            ))}
                        </tr>
                    </thead>
                    <tbody>
                        {exposureLevelsSorted.map(expLvl => (
                            <tr key={`row-${expLvl}`}>
                                <td className="p-2 border border-slate-300 bg-slate-50 font-semibold">{exposureLevelFullLabels[expLvl]}</td>
                                <td className="p-2 border border-slate-300 bg-slate-50 font-semibold">{expLvl}</td>
                                {riskIndicatorLevelsNumerical.map(ril => {
                                    const cellKey = RBS_MATRIX_CELL_KEYS[expLvl]?.[ril];
                                    const cellColorClasses = RBS_MATRIX_CELL_COLORS[cellKey] || RBS_MATRIX_CELL_COLORS["default"];
                                    const isCurrentOperatorCell = cellKey === operator.finalRiskCategoryKey;
                                    const cycle = RBS_MATRIX_SURVEILLANCE_CYCLES[cellKey] || 'N/A';
                                    return (
                                        <td
                                            key={cellKey}
                                            className={`p-1.5 border border-slate-300 transition-all ${cellColorClasses}
                                                ${isCurrentOperatorCell ? 'ring-4 ring-brand-secondary ring-inset shadow-2xl scale-105 z-10' : ''}`}
                                            title={`Category: ${cellKey}, Cycle: ${cycle} months`}
                                        >
                                           <div className="flex flex-col items-center justify-center h-full">
                                                <div className="font-bold">{cellKey}</div>
                                                {isCurrentOperatorCell && (
                                                    <>
                                                        <div className="text-xs opacity-90 leading-tight">Cycle: {cycle} mo.</div>
                                                        <div className="text-xs opacity-90 leading-tight">
                                                            Coverage: {inspectedAreasCount}/{totalPredefinedAreas}
                                                        </div>
                                                        <div className="text-xs opacity-90 leading-tight">
                                                            Total Satisfactory: {totalSatisfactoryInspections}
                                                        </div>
                                                    </>
                                                )}
                                            </div>
                                        </td>
                                    );
                                })}
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                 <FactorScoreDetail 
                    title="Compliance C(p)"
                    score={operator.complianceFactorScore}
                    details={[
                        {label: "NCP Findings", value: usesDynamicComplianceFactor ? operator.surveillanceFindings?.filter(sf => !sf.isCompleted && sf.findingCategory === FindingCategoryLevel.LEVEL_1).length || 0 : operator.complianceData.findings.ncp},
                        {label: "NCF Findings", value: usesDynamicComplianceFactor ? operator.surveillanceFindings?.filter(sf => !sf.isCompleted && sf.findingCategory === FindingCategoryLevel.LEVEL_2).length || 0 : operator.complianceData.findings.ncf},
                        {label: "NAD Findings", value: usesDynamicComplianceFactor ? operator.surveillanceFindings?.filter(sf => !sf.isCompleted && sf.findingCategory === FindingCategoryLevel.LEVEL_3).length || 0 : operator.complianceData.findings.nad},
                        {label: "Total Checklist Items", value: operator.complianceData.totalChecklistItems},
                    ]}
                    note={usesDynamicComplianceFactor ? "Derived from Open Surveillance Findings" : "Using fallback manual Compliance Data"}
                />
                <FactorScoreDetail 
                    title="Deviation D(p)"
                    score={operator.deviationFactorScore}
                    details={[
                        {label: "Accidents", value: operator.deviationData.accidentCount},
                        {label: "Serious Incidents", value: operator.deviationData.seriousIncidentCount},
                        {label: "Incidents", value: operator.deviationData.incidentCount},
                        {label: "Total Flight Cycles", value: operator.deviationData.totalFlightCycles},
                    ]}
                    note={`Score: ${(operator.deviationFactorScore * 10000).toFixed(3)} per 10k cycles`}
                />
                <FactorScoreDetail 
                    title="Improvement I(p)"
                    score={operator.improvementFactorScore}
                    details={[
                        {label: "Total Deviations (Nd)", value: operator.improvementData.totalDeviationsNd},
                        {label: "Total Findings (Nf)", value: operator.improvementData.totalFindingsNf},
                        {label: "RCA Achieved", value: operator.improvementData.correctiveActionsRootCause},
                        {label: "Hazard ID Achieved", value: operator.improvementData.correctiveActionsHazardIdentified},
                        {label: "Risk Assessed Achieved", value: operator.improvementData.correctiveActionsRiskAssessed},
                        {label: "Risk Mitigated Achieved", value: operator.improvementData.correctiveActionsRiskMitigated},
                    ]}
                />
            </div>
        </div>
      

      {operator.riskIndicatorHistory && aiClient && (
        <div className="bg-white shadow-xl rounded-xl p-6">
          <h3 className="text-xl font-semibold text-slate-700 mb-4 flex items-center">
            <PresentationChartLineIcon className="h-6 w-6 mr-2 text-brand-primary" />
            Risk Indicator Level Trend
          </h3>
          <RiskIndicatorTrendChart 
            historyData={operator.riskIndicatorHistory} 
            aiClient={aiClient}
            operatorName={operator.name}
            operatorAoc={operator.aocNumber}
          />
        </div>
      )}
      
       
        <div className="bg-white shadow-xl rounded-xl p-6">
            <h3 className="text-xl font-semibold text-slate-700 mb-4 flex items-center">
            <CurrencyDollarIcon className="h-6 w-6 mr-2 text-brand-primary" />
             Financial & Economic Analysis
            </h3>
            
            {!API_KEY && (
                <div className="p-3 mb-4 text-sm text-yellow-700 bg-yellow-100 rounded-md border border-yellow-300">
                    Financial analysis AI features are unavailable. API_KEY is not configured.
                </div>
            )}
            {API_KEY && !aiClient && financialReportError &&(
                <div className="p-3 mb-4 text-sm text-red-700 bg-red-100 rounded-md border border-red-300">
                    {financialReportError}
                </div>
            )}
            {API_KEY && !aiClient && !financialReportError && (
                <div className="p-3 mb-4 text-sm text-blue-700 bg-blue-100 rounded-md border border-blue-300 flex items-center">
                <LoadingSpinner size="sm"/> <span className="ml-2">Initializing AI service for financial analysis...</span>
                </div>
            )}

            {API_KEY && aiClient && isAdmin && (
            <div className="mb-6">
                <div className="mb-4">
                    <label htmlFor="financialFile" className="block text-sm font-medium text-slate-700 mb-1">
                        Upload Financial Document (PDF, XLS, XLSX - Optional, Max 5MB)
                    </label>
                    <div className="flex items-center space-x-2">
                        <input
                            type="file"
                            id="financialFile"
                            accept=".pdf,.xls,.xlsx,application/pdf,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                            onChange={handleFinancialFileChange}
                            className="block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-brand-secondary file:text-white hover:file:bg-sky-700 disabled:opacity-50"
                            disabled={isFinancialReportLoading || !isAdmin}
                            aria-describedby="financialFileHelp"
                        />
                        {financialReportFile && (
                            <button
                                onClick={() => {
                                    setFinancialReportFile(null);
                                    setFinancialReportFileError(null);
                                    const input = document.getElementById('financialFile') as HTMLInputElement;
                                    if (input) input.value = '';
                                }}
                                className="text-xs text-red-500 hover:text-red-700 p-1"
                                title="Remove file"
                                disabled={isFinancialReportLoading || !isAdmin}
                            >
                                <XCircleIcon className="h-5 w-5" />
                            </button>
                        )}
                    </div>
                    {financialReportFile && <p className="text-xs text-slate-600 mt-1">Selected: {financialReportFile.name} ({(financialReportFile.size / 1024).toFixed(1)} KB)</p>}
                    {financialReportFileError && <p className="text-xs text-red-500 mt-1">{financialReportFileError}</p>}
                    <p id="financialFileHelp" className="text-xs text-slate-500 mt-1">If a file is uploaded, it will be used as the primary source for AI analysis. Otherwise, AI will use Google Search.</p>
                </div>

                <button
                onClick={handleFetchFinancialReport}
                disabled={isFinancialReportLoading || !aiClient || !isAdmin}
                className="px-4 py-2 bg-teal-600 text-white text-sm font-medium rounded-md shadow-sm hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 disabled:bg-slate-400 disabled:cursor-not-allowed flex items-center justify-center min-w-[250px]"
                >
                {isFinancialReportLoading ? (
                    <> <LoadingSpinner size="sm" /> <span className="ml-2">Fetching Financial Data...</span></>
                ) : (
                    <>
                        <SparklesIcon className="h-4 w-4 mr-1.5" />
                        {financialReportFile ? "Fetch (Using Uploaded File)" : "Fetch (Using Web Search)"}
                    </>
                )}
                </button>
            </div>
            )}
            {operator.financialReportText && (
            <div className="mt-4 p-4 bg-slate-50 border border-slate-200 rounded-md">
                <h4 className="text-md font-semibold text-slate-800 mb-2">AI-Generated Financial Summary:</h4>
                <pre className="whitespace-pre-wrap text-sm text-slate-700 font-sans leading-relaxed">{operator.financialReportText}</pre>
                {operator.financialReportSources && operator.financialReportSources.length > 0 && (
                <div className="mt-3 pt-3 border-t border-slate-300">
                    <h5 className="text-xs font-semibold text-slate-600 mb-1">Sources:</h5>
                    <ul className="list-disc list-inside text-xs space-y-0.5">
                    {operator.financialReportSources.map(source => (
                        <li key={source.uri}>
                        <a href={source.uri} target="_blank" rel="noopener noreferrer" className="text-sky-600 hover:text-sky-800 hover:underline">
                            {source.title || source.uri}
                        </a>
                        </li>
                    ))}
                    </ul>
                </div>
                )}
            </div>
            )}
            {financialReportError && !isFinancialReportLoading && ( 
                <div className="mt-3 p-3 text-sm text-red-700 bg-red-100 rounded-md border border-red-300">
                    <p className="font-semibold">Financial Data Fetch Note:</p>
                    <p>{financialReportError}</p>
                </div>
            )}


            {/* Economic Factors Display */}
             {operator.economicFactors && (
                <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <h4 className="text-lg font-semibold text-slate-700 mb-2 flex items-center">
                        <ChartPieIcon className="h-5 w-5 mr-2 text-brand-secondary" />
                        Economic Factors Radar
                    </h4>
                    <EconomicSpiderwebChart economicFactors={operator.economicFactors} />
                </div>
                <div>
                    <h4 className="text-lg font-semibold text-slate-700 mb-2 flex items-center">
                        <TableCellsIcon className="h-5 w-5 mr-2 text-brand-secondary" />
                        Economic Indexes Overview
                    </h4>
                    <EconomicIndexesTable economicFactors={operator.economicFactors} />
                </div>
                </div>
            )}
            {!operator.economicFactors && API_KEY && aiClient && (
                 <div className="mt-4">
                    <p className="text-sm text-slate-500 italic">
                        Detailed economic factors (Liquidity, Debt, etc.) have not been fetched for this operator. {isAdmin ? "Use the button above to fetch them." : ""}
                    </p>
                </div>
            )}


            {/* Existing Safety Risk Area Profile (Overall Economic Score) */}
            <div className="mt-8 pt-6 border-t border-slate-200">
                 <div className="flex flex-col sm:flex-row justify-between items-center mb-2">
                    <h4 className="text-lg font-semibold text-slate-700 mb-1 sm:mb-0 flex items-center">
                        <PresentationChartLineIcon className="h-5 w-5 mr-2 text-brand-secondary" />
                        Safety Risk Area Profile (using Overall Economic Score)
                    </h4>
                    <div className="flex space-x-1.5">
                        {(['Daily', 'Weekly', 'Monthly', 'Yearly'] as HistoricalPathPeriod[]).map((p) => (
                            <button
                            key={p}
                            onClick={() => setHistoricalPathPeriod(p)}
                            className={`px-2.5 py-1 text-xs rounded-md transition-colors ${
                                historicalPathPeriod === p
                                ? 'bg-brand-secondary text-white shadow-sm'
                                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                            }`}
                            >
                            {p}
                            </button>
                        ))}
                    </div>
                </div>
                <div className={`grid grid-cols-1 md:grid-cols-3 gap-4 p-4 border border-slate-200 rounded-lg bg-slate-50 text-sm ${!isAdmin ? 'pointer-events-none opacity-70' : ''}`}>
                    <div>
                        <label htmlFor="economicIndicatorScore" className="block font-medium text-slate-700">
                            Overall Economic Score (0-5)
                             {operator.economicIndicatorScoreLastUpdatedByAI && (
                                <span className="text-xs text-teal-600 ml-1 font-normal">(AI: {new Date(operator.economicIndicatorScoreLastUpdatedByAI).toLocaleDateString()})</span>
                            )}
                        </label>
                        <input
                            type="number"
                            id="economicIndicatorScore"
                            name="economicIndicatorScore"
                            value={economicTechnicalProfileForm.economicIndicatorScore}
                            onChange={(e) => {
                                const val = parseFloat(e.target.value);
                                setEconomicTechnicalProfileForm({...economicTechnicalProfileForm, economicIndicatorScore: isNaN(val) ? 0 : val});
                            }}
                            min="0" max="5" step="0.1"
                            className="mt-1 block w-full p-2 border border-slate-300 rounded-md shadow-sm"
                            readOnly={!isAdmin}
                        />
                    </div>
                    <div>
                        <label htmlFor="operatorCategory" className="block font-medium text-slate-700">Operator Category</label>
                        <select
                            id="operatorCategory"
                            name="operatorCategory"
                            value={economicTechnicalProfileForm.operatorCategory}
                            onChange={(e) => setEconomicTechnicalProfileForm({...economicTechnicalProfileForm, operatorCategory: e.target.value})}
                            className="mt-1 block w-full p-2 border border-slate-300 rounded-md shadow-sm bg-white"
                            disabled={!isAdmin}
                        >
                            {OPERATOR_CATEGORIES.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                        </select>
                    </div>
                    <div className="flex items-center mt-2 md:mt-6">
                        <input
                            type="checkbox"
                            id="hadFatalAccidentLast3Years"
                            name="hadFatalAccidentLast3Years"
                            checked={economicTechnicalProfileForm.hadFatalAccidentLast3Years}
                            onChange={(e) => setEconomicTechnicalProfileForm({...economicTechnicalProfileForm, hadFatalAccidentLast3Years: e.target.checked})}
                            className="h-4 w-4 text-brand-primary border-slate-300 rounded focus:ring-brand-secondary"
                            disabled={!isAdmin}
                        />
                        <label htmlFor="hadFatalAccidentLast3Years" className="ml-2 block text-sm font-medium text-slate-700">Had Fatal Accident (Last 3 Years)?</label>
                    </div>
                </div>
                {isAdmin && (
                  <button 
                      onClick={handleEconomicTechnicalProfileSave} 
                      className="mt-4 text-sm bg-sky-600 hover:bg-sky-700 text-white font-medium py-2 px-4 rounded-lg shadow-md"
                  >
                      Save Profile & Update Safety Risk Chart
                  </button>
                )}

                {operator.economicIndicatorScore !== undefined && operator.operatorCategory && (
                    <div className="mt-6">
                         <h4 className="text-md font-semibold text-slate-600 mb-1 flex items-center">
                            <ChartPieIcon className="h-5 w-5 mr-2 text-brand-secondary" />
                            Safety Risk Area Visualization
                        </h4>
                        <SafetyRiskAreaChart 
                            currentOperator={operator} 
                            allOperators={operators}
                            historicalPathPeriod={historicalPathPeriod} 
                        />
                        <div className="mt-2 p-3 text-xs text-slate-600 bg-slate-100 rounded-md border border-slate-200 space-y-1">
                            <p><strong className="text-green-600">Satisfactory Zone (Green):</strong> Good economic and technical status.</p>
                            <p><strong className="text-yellow-600">Negative Zone (Yellow):</strong> Indicates a potential imbalance; either economic or technical aspects need attention.</p>
                            <p><strong className="text-orange-600">Serious Zone (Orange):</strong> Both economic and technical indicators show significant concerns.</p>
                            <p><strong className="text-red-600">Critical Zone (Red):</strong> Poor economic and technical status, requiring immediate attention.</p>
                        </div>
                    </div>
                )}
            </div>
        </div>
      
      <SurveillanceLogSection 
        operator={operator}
        upsertLogItem={upsertSurveillanceLogItem}
        deleteSurveillanceLogItem={deleteSurveillanceLogItem}
        onOpenFindingModal={handleOpenFindingModal}
        deleteSurveillanceFinding={deleteSurveillanceFinding}
        toggleSurveillanceFindingCompletion={toggleSurveillanceFindingCompletion}
      />
      
      <MasterFindingsList
        operator={operator}
        onOpenFindingModal={handleOpenFindingModal}
        onDeleteFinding={deleteSurveillanceFinding}
        onToggleFindingCompletion={toggleSurveillanceFindingCompletion}
      />

      <SurveillanceComplianceHeatmap 
        operator={operator}
        onCellClick={handleHeatmapCellClick}
      />

      <div className="bg-white shadow-xl rounded-xl p-6">
        <h3 className="text-xl font-semibold text-slate-700 mb-4 flex items-center">
            <ExclamationTriangleIcon className="h-6 w-6 mr-2 text-brand-primary" />
            Occurrence Reports
        </h3>
        {isAdmin && (
            <button onClick={openAddOccurrenceReportModal} className="mb-4 text-sm bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-3 rounded-md flex items-center shadow-sm">
                <PlusIcon className="h-4 w-4 mr-1" /> Add Occurrence Report
            </button>
        )}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2">
                {(!operator.legacyRiskFactors.occurrences || operator.legacyRiskFactors.occurrences.length === 0) ? (
                    <div className="text-center py-10 bg-slate-50 rounded-lg">
                        <p className="text-sm text-slate-500">No occurrence reports logged for this operator.</p>
                    </div>
                ) : (
                    <div className="space-y-3 max-h-96 overflow-y-auto pr-2">
                        {operator.legacyRiskFactors.occurrences.sort((a, b) => new Date(b.dateTime).getTime() - new Date(a.dateTime).getTime()).map(occ => (
                           <div key={occ.id} className="p-3 border border-slate-200 rounded-lg bg-slate-50/70">
                                <div className="flex justify-between items-start">
                                    <div>
                                        <span className={`text-xs font-bold px-2 py-0.5 rounded-full text-white ${occ.type === OccurrenceType.ACCIDENT ? 'bg-red-600' : occ.type === OccurrenceType.SERIOUS_INCIDENT ? 'bg-orange-500' : 'bg-yellow-500 text-slate-800'}`}>{occ.type}</span>
                                        <span className="ml-2 text-xs font-semibold text-slate-600">Severity: {occ.severity}</span>
                                    </div>
                                    {isAdmin && (
                                        <div className="flex space-x-1">
                                            <button onClick={() => openEditOccurrenceReportModal(occ)} className="p-1 text-sky-600 hover:text-sky-800" title="Edit"><PencilIcon className="h-4 w-4" /></button>
                                            <button onClick={() => deleteOccurrenceReport(occ.id)} className="p-1 text-red-500 hover:text-red-700" title="Delete"><TrashIcon className="h-4 w-4" /></button>
                                        </div>
                                    )}
                                </div>
                                <p className="text-xs text-slate-500 mt-1">{new Date(occ.dateTime).toLocaleString()}</p>
                                <p className="text-sm text-slate-800 mt-2 font-medium">Description:</p>
                                <p className="text-sm text-slate-700 whitespace-pre-wrap">{occ.description}</p>
                                <div className="mt-2 pt-2 border-t border-slate-200 text-xs text-slate-600 space-y-1">
                                    <p><strong>Category:</strong> {occ.category ? `${OCCURRENCE_CATEGORY_LABELS[occ.category]} (${occ.category})` : 'N/A'}</p>
                                    <p><strong>Flight:</strong> {occ.flightNumber || 'N/A'} / <strong>Aircraft:</strong> {occ.aircraftRegistration || 'N/A'}</p>
                                    <p><strong>Route:</strong> {occ.routeDetails?.originAirportICAO || '?'} -> {occ.routeDetails?.destinationAirportICAO || '?'}</p>
                                    <p><strong>Location:</strong> {occ.location?.addressString || 'Not specified'}</p>
                                    {occ.weatherForecast?.weatherDescription && <p><strong>Weather:</strong> {occ.weatherForecast.weatherDescription}, {occ.weatherForecast.temperature?.toFixed(1)}°C</p>}
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
            <div>
                <h4 className="text-md font-semibold text-slate-600 mb-2 text-center">Severity Distribution</h4>
                {occurrenceReportSeverityData.length > 0 ? (
                    <ResponsiveContainer width="100%" height={250}>
                        <PieChart>
                            <Pie data={occurrenceReportSeverityData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                                {occurrenceReportSeverityData.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={CHART_HEX_RISK_LEVEL_COLORS[entry.name as unknown as RiskLevel]} />
                                ))}
                            </Pie>
                            <Tooltip contentStyle={{backgroundColor: 'rgba(255,255,255,0.9)', border: '1px solid #ccc', borderRadius: '5px', fontSize: '10px'}}/>
                            <RechartsLegend wrapperStyle={{ fontSize: "12px", paddingTop: "10px" }} />
                        </PieChart>
                    </ResponsiveContainer>
                ) : (
                    <p className="text-xs text-slate-500 text-center mt-8">No data for chart.</p>
                )}
            </div>
        </div>
      </div>
      
      <div className="bg-white shadow-xl rounded-xl p-6">
        <div className="flex justify-between items-center mb-4">
            <h3 className="text-xl font-semibold text-slate-700">Operator Data for RBS Calculation</h3>
            {isAdmin && API_KEY && aiClient && (
                <button
                    onClick={handleSuggestRBSDataWithAI}
                    disabled={isAiRBSDataLoading || !aiClient}
                    className="text-sm bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 px-4 rounded-lg shadow-md flex items-center disabled:bg-slate-400"
                    title="Suggest values for Complexity, Compliance (fallback), and Total Flight Cycles using AI"
                >
                    {isAiRBSDataLoading ? <LoadingSpinner size="sm"/> : <InfoCircleIconSolid className="h-4 w-4 mr-1.5"/>}
                    {isAiRBSDataLoading ? 'Suggesting...' : 'Suggest RBS Data with AI'}
                </button>
            )}
        </div>
        
        {!API_KEY && (
            <div className="p-3 mb-4 text-sm text-yellow-700 bg-yellow-100 rounded-md border border-yellow-300">
                AI features for RBS data suggestion are unavailable. API_KEY is not configured.
            </div>
        )}
          {API_KEY && !aiClient && aiRBSDataError &&(
              <div className="p-3 mb-4 text-sm text-red-700 bg-red-100 rounded-md border border-red-300">
                {aiRBSDataError}
            </div>
        )}
        {API_KEY && !aiClient && !aiRBSDataError && (
              <div className="p-3 mb-4 text-sm text-blue-700 bg-blue-100 rounded-md border border-blue-300 flex items-center">
                  <LoadingSpinner size="sm"/> <span className="ml-2">Initializing AI service for RBS data...</span>
              </div>
        )}

        {aiRBSDataError && !isAiRBSDataLoading && (
            <div className="mb-4 p-3 text-sm text-red-700 bg-red-100 rounded-md border border-red-300">
                <p className="font-semibold">AI Suggestion Error:</p>
                <p>{aiRBSDataError}</p>
            </div>
        )}
        {usesDynamicComplianceFactor && (
            <div className="p-3 mb-4 text-xs text-blue-700 bg-blue-100 rounded-md border border-blue-300 flex items-center">
                <InfoCircleIconSolid className="h-4 w-4 mr-2 text-blue-500" />
                Compliance Factor C(p) is currently being calculated dynamically based on open items in the Surveillance Findings Log. Manual NCP/NCF/NAD counts below are used if the log is empty.
            </div>
        )}
        <div className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-x-6 gap-y-4 text-sm ${!isAdmin ? 'opacity-70' : ''}`}>
            <div>
                <label htmlFor="annualFlightCount" className="font-medium text-slate-700">Annual Flight Count</label>
                {createNumberInput('annualFlightCount', complexityFactorsForm.annualFlightCount, 'complexity')}
            </div>
            <div>
                <label htmlFor="numEmployees" className="font-medium text-slate-700">Num. Employees</label>
                {createNumberInput('numEmployees', complexityFactorsForm.numEmployees, 'complexity')}
            </div>
             <div>
                <label htmlFor="numAircraft" className="font-medium text-slate-700">Num. Aircraft</label>
                {createNumberInput('numAircraft', complexityFactorsForm.numAircraft, 'complexity')}
            </div>
            <div>
                <label htmlFor="numAircraftModels" className="font-medium text-slate-700">Num. Aircraft Models</label>
                {createNumberInput('numAircraftModels', complexityFactorsForm.numAircraftModels, 'complexity')}
            </div>
            <div>
                <label htmlFor="numDestinations" className="font-medium text-slate-700">Num. Destinations</label>
                {createNumberInput('numDestinations', complexityFactorsForm.numDestinations, 'complexity')}
            </div>
            <div>
                <label htmlFor="avgFleetAge" className="font-medium text-slate-700">Avg. Fleet Age (Yrs)</label>
                {createNumberInput('avgFleetAge', complexityFactorsForm.avgFleetAge, 'complexity')}
            </div>
             <div>
                <label htmlFor="numDomesticBases" className="font-medium text-slate-700">Num. Domestic Bases</label>
                {createNumberInput('numDomesticBases', complexityFactorsForm.numDomesticBases, 'complexity')}
            </div>
             <div className="flex items-center mt-4">
                <input 
                    type="checkbox" 
                    id="hasInternationalOps" 
                    checked={complexityFactorsForm.hasInternationalOps} 
                    onChange={e => {if (isAdmin) setComplexityFactorsForm(p => ({...p, hasInternationalOps: e.target.checked}))}}
                    className={`h-4 w-4 rounded border-slate-300 text-brand-primary focus:ring-brand-secondary ${!isAdmin ? 'cursor-not-allowed' : ''}`}
                    disabled={!isAdmin}
                />
                <label htmlFor="hasInternationalOps" className="ml-2 font-medium text-slate-700">Has Int'l Ops?</label>
            </div>
            
            {/* Compliance Fallback */}
            <div className={`mt-4 pt-4 border-t col-span-full ${usesDynamicComplianceFactor ? 'opacity-50' : ''}`}>
                <h4 className="font-semibold text-slate-800">Compliance C(p) Fallback Data</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-x-6 gap-y-4">
                     <div>
                        <label htmlFor="ncp" className="font-medium text-slate-700">NCP Count</label>
                        {createNumberInput('ncp', complianceDataForm.findings.ncp, 'compliance', 'findings', usesDynamicComplianceFactor)}
                    </div>
                     <div>
                        <label htmlFor="ncf" className="font-medium text-slate-700">NCF Count</label>
                        {createNumberInput('ncf', complianceDataForm.findings.ncf, 'compliance', 'findings', usesDynamicComplianceFactor)}
                    </div>
                     <div>
                        <label htmlFor="nad" className="font-medium text-slate-700">NAD Count</label>
                        {createNumberInput('nad', complianceDataForm.findings.nad, 'compliance', 'findings', usesDynamicComplianceFactor)}
                    </div>
                     <div>
                        <label htmlFor="totalChecklistItems" className="font-medium text-slate-700">Total Checklist Items</label>
                        {createNumberInput('totalChecklistItems', complianceDataForm.totalChecklistItems, 'compliance', undefined, usesDynamicComplianceFactor)}
                    </div>
                </div>
            </div>

            {/* Deviation */}
            <div className="mt-4 pt-4 border-t col-span-full">
                <h4 className="font-semibold text-slate-800">Deviation D(p) Data</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-x-6 gap-y-4">
                     <div>
                        <label className="font-medium text-slate-700">Accident Count</label>
                        {createNumberInput('accidentCount', deviationDataForm.accidentCount, 'deviation', undefined, true)}
                    </div>
                     <div>
                        <label className="font-medium text-slate-700">Serious Incident Count</label>
                        {createNumberInput('seriousIncidentCount', deviationDataForm.seriousIncidentCount, 'deviation', undefined, true)}
                    </div>
                     <div>
                        <label className="font-medium text-slate-700">Incident Count</label>
                        {createNumberInput('incidentCount', deviationDataForm.incidentCount, 'deviation', undefined, true)}
                    </div>
                     <div>
                        <label htmlFor="totalFlightCycles" className="font-medium text-slate-700">Total Flight Cycles</label>
                        {createNumberInput('totalFlightCycles', deviationDataForm.totalFlightCycles, 'deviation')}
                    </div>
                </div>
                <p className="text-xs text-slate-500 mt-2">Note: Accident, Serious Incident, and Incident counts are automatically derived from the Occurrence Reports Log.</p>
            </div>
        </div>
         {isAdmin && (
            <div className="mt-6 flex justify-end">
                <button 
                    onClick={handleRBSDataSave} 
                    className="bg-brand-primary hover:bg-blue-800 text-white font-semibold py-2 px-4 rounded-lg shadow-md"
                >
                    Save RBS Data
                </button>
            </div>
        )}
      </div>
      
      {/* AI Assitant Sections */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white shadow-xl rounded-xl p-6">
                <h3 className="text-xl font-semibold text-slate-700 mb-4 flex items-center">
                    <InfoCircleIconSolid className="h-6 w-6 mr-2 text-brand-primary" />
                    General AI Assistant
                </h3>
                {API_KEY && aiClient ? (
                    <div className="space-y-3">
                        <textarea 
                            value={generalAiQuery}
                            onChange={(e) => setGeneralAiQuery(e.target.value)}
                            placeholder="Ask the AI a general question about this operator's profile, findings, or risk status..."
                            rows={3}
                            className="w-full p-2 border border-slate-300 rounded-md shadow-sm text-sm"
                        />
                        <button
                            onClick={handleGeneralAiQuerySubmit}
                            disabled={isGeneralAiLoading}
                            className="px-4 py-2 bg-brand-secondary text-white text-sm font-medium rounded-md shadow-sm hover:bg-sky-700 disabled:bg-slate-400 flex items-center"
                        >
                            {isGeneralAiLoading ? <><LoadingSpinner size="sm"/> <span className="ml-2">Analyzing...</span></> : 'Submit Query'}
                        </button>
                        {generalAiError && <p className="text-xs text-red-500 p-2 bg-red-50 rounded border border-red-200">{generalAiError}</p>}
                        {generalAiResponse && (
                            <div className="mt-4 p-3 bg-slate-50 border border-slate-200 rounded-md">
                                <h4 className="text-sm font-semibold text-slate-800 mb-2">AI Response:</h4>
                                <pre className="whitespace-pre-wrap text-sm text-slate-700 font-sans leading-relaxed">{generalAiResponse}</pre>
                            </div>
                        )}
                        <button onClick={() => setIsGeneralAiThinkingVisible(!isGeneralAiThinkingVisible)} className="text-xs text-slate-400 hover:text-slate-600 mt-2">
                            {isGeneralAiThinkingVisible ? 'Hide' : 'Show'} Full AI Prompt
                        </button>
                        {isGeneralAiThinkingVisible && generalAiPromptSent && (
                            <div className="mt-2 p-2 border bg-gray-50 text-xs text-gray-500 rounded-md">
                                <pre className="whitespace-pre-wrap font-mono">{generalAiPromptSent}</pre>
                            </div>
                        )}
                    </div>
                ) : (
                    <div className="p-3 text-sm text-yellow-700 bg-yellow-100 rounded-md border border-yellow-300">
                        AI Assistant feature is unavailable. API_KEY is not configured or client failed to initialize.
                    </div>
                )}
            </div>

            <div className="bg-white shadow-xl rounded-xl p-6">
                <h3 className="text-xl font-semibold text-slate-700 mb-4 flex items-center">
                    <AcademicCapIcon className="h-6 w-6 mr-2 text-brand-primary" />
                    AI Safety Inspector Agent
                </h3>
                {API_KEY && aiClient ? (
                     <div className="space-y-3">
                        <textarea 
                            value={inspectorAiQuery}
                            onChange={(e) => setInspectorAiQuery(e.target.value)}
                            placeholder="As a DGCA inspector, what specific areas should I focus on during my next surveillance of this operator? Analyze based on CASR and ICAO standards."
                            rows={3}
                            className="w-full p-2 border border-slate-300 rounded-md shadow-sm text-sm"
                        />
                        <button
                            onClick={handleInspectorAiQuerySubmit}
                            disabled={isInspectorAiLoading}
                            className="px-4 py-2 bg-brand-secondary text-white text-sm font-medium rounded-md shadow-sm hover:bg-sky-700 disabled:bg-slate-400 flex items-center"
                        >
                             {isInspectorAiLoading ? <><LoadingSpinner size="sm"/> <span className="ml-2">Analyzing...</span></> : 'Get Inspector Analysis'}
                        </button>
                        {inspectorAiError && <p className="text-xs text-red-500 p-2 bg-red-50 rounded border border-red-200">{inspectorAiError}</p>}
                        {inspectorAiResponse && (
                            <div className="mt-4 p-3 bg-slate-50 border border-slate-200 rounded-md">
                                <h4 className="text-sm font-semibold text-slate-800 mb-2">AI Inspector Analysis:</h4>
                                <pre className="whitespace-pre-wrap text-sm text-slate-700 font-sans leading-relaxed">{inspectorAiResponse}</pre>
                            </div>
                        )}
                        <button onClick={() => setIsInspectorAiThinkingVisible(!isInspectorAiThinkingVisible)} className="text-xs text-slate-400 hover:text-slate-600 mt-2">
                           {isInspectorAiThinkingVisible ? 'Hide' : 'Show'} Full AI Prompt
                        </button>
                        {isInspectorAiThinkingVisible && inspectorAiPromptSent && (
                            <div className="mt-2 p-2 border bg-gray-50 text-xs text-gray-500 rounded-md">
                                <pre className="whitespace-pre-wrap font-mono">{inspectorAiPromptSent}</pre>
                            </div>
                        )}
                    </div>
                ) : (
                    <div className="p-3 text-sm text-yellow-700 bg-yellow-100 rounded-md border border-yellow-300">
                        AI Inspector Agent feature is unavailable. API_KEY is not configured or client failed to initialize.
                    </div>
                )}
            </div>
      </div>


      {/* Modals */}
      {isAdmin && isOccurrenceReportModalOpen && (
        <Modal isOpen={isOccurrenceReportModalOpen} onClose={() => setIsOccurrenceReportModalOpen(false)} title={editingOccurrenceReport ? 'Edit Occurrence Report' : 'Add Occurrence Report'} size="xl">
          <form onSubmit={handleOccurrenceReportSubmit} className="space-y-4 text-sm max-h-[80vh] overflow-y-auto pr-3">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label htmlFor="dateTime" className="block font-medium text-slate-700">Date & Time</label>
                    <input type="datetime-local" id="dateTime" name="dateTime" value={occurrenceReportFormData.dateTime} onChange={handleOccurrenceReportFormChange} className="w-full mt-1 p-1.5 border border-slate-300 rounded" required/>
                  </div>
                   <div>
                    <label htmlFor="type" className="block font-medium text-slate-700">Type</label>
                    <select id="type" name="type" value={occurrenceReportFormData.type} onChange={handleOccurrenceReportFormChange} className="w-full mt-1 p-1.5 border border-slate-300 rounded bg-white">
                        {Object.values(OccurrenceType).map(t => <option key={t} value={t}>{t}</option>)}
                    </select>
                  </div>
                  <div>
                    <label htmlFor="severity" className="block font-medium text-slate-700">Severity</label>
                    <select id="severity" name="severity" value={occurrenceReportFormData.severity} onChange={handleOccurrenceReportFormChange} className="w-full mt-1 p-1.5 border border-slate-300 rounded bg-white">
                        {Object.values(SeverityLevel).map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </div>
              </div>

              <div>
                <label htmlFor="category" className="block font-medium text-slate-700">ECCAIRS Category</label>
                <select id="category" name="category" value={occurrenceReportFormData.category} onChange={handleOccurrenceReportFormChange} className="w-full mt-1 p-1.5 border border-slate-300 rounded bg-white">
                  {Object.entries(OCCURRENCE_CATEGORY_LABELS).map(([key, label]) => <option key={key} value={key}>{label} ({key})</option>)}
                </select>
                {selectedCategoryUsageNotes && <p className="text-xs text-slate-500 mt-1 p-2 bg-slate-50 rounded-md border">{selectedCategoryUsageNotes}</p>}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="flightNumber" className="block font-medium text-slate-700">Flight Number (IATA)</label>
                  <div className="flex items-center">
                    <input type="text" id="flightNumber" name="flightNumber" value={occurrenceReportFormData.flightNumber || ''} onChange={handleOccurrenceReportFormChange} className="w-full mt-1 p-1.5 border border-slate-300 rounded-l-md" placeholder="e.g., GA200"/>
                    <button 
                      type="button"
                      onClick={fetchFlightDetails}
                      disabled={isFetchingFlightDetails || !AVIATION_STACK_API_KEY}
                      className="mt-1 px-3 py-1.5 bg-sky-600 text-white rounded-r-md hover:bg-sky-700 disabled:bg-slate-400"
                      title={!AVIATION_STACK_API_KEY ? "AviationStack API Key Not Configured" : "Fetch Flight Details"}
                    >
                      {isFetchingFlightDetails ? <LoadingSpinner size="sm"/> : <PlaneIconSolid className="h-4 w-4"/>}
                    </button>
                  </div>
                  {flightDetailsError && <p className="text-xs text-red-500 mt-1">{flightDetailsError}</p>}
                  {!AVIATION_STACK_API_KEY && <p className="text-xs text-yellow-600 mt-1">Flight detail fetch disabled.</p>}
                </div>
                <div>
                  <label htmlFor="aircraftRegistration" className="block font-medium text-slate-700">Aircraft Registration</label>
                  <input type="text" id="aircraftRegistration" name="aircraftRegistration" value={occurrenceReportFormData.aircraftRegistration || ''} onChange={handleOccurrenceReportFormChange} className="w-full mt-1 p-1.5 border border-slate-300 rounded" placeholder="e.g., PK-GAA"/>
                </div>
              </div>
              
              <div>
                 <label className="block font-medium text-slate-700">Route Details</label>
                 <div className="p-3 mt-1 border border-slate-200 rounded-md space-y-2">
                   <div className="grid grid-cols-2 gap-x-4">
                        <div>
                            <label htmlFor="originAirportICAO" className="text-xs font-medium">Origin ICAO</label>
                            <input 
                                type="text" 
                                id="originAirportICAO" 
                                name="originAirportICAO" 
                                value={occurrenceReportFormData.routeDetails?.originAirportICAO || ''} 
                                onChange={handleOccurrenceReportFormChange} 
                                className="w-full mt-0.5 p-1 border border-slate-300 rounded" 
                                maxLength={4}
                                placeholder="e.g., WIII"
                            />
                            {isFetchingOriginAirport && <p className="text-xs text-slate-500 mt-0.5">Fetching name...</p>}
                            {originAirportError && <p className="text-xs text-red-500 mt-0.5">{originAirportError}</p>}
                            {occurrenceReportFormData.routeDetails?.originAirportName && !isFetchingOriginAirport && <p className="text-xs text-slate-600 mt-0.5 truncate" title={occurrenceReportFormData.routeDetails.originAirportName}>{occurrenceReportFormData.routeDetails.originAirportName}</p>}
                        </div>
                        <div>
                            <label htmlFor="destinationAirportICAO" className="text-xs font-medium">Destination ICAO</label>
                            <input 
                                type="text" 
                                id="destinationAirportICAO" 
                                name="destinationAirportICAO" 
                                value={occurrenceReportFormData.routeDetails?.destinationAirportICAO || ''} 
                                onChange={handleOccurrenceReportFormChange} 
                                className="w-full mt-0.5 p-1 border border-slate-300 rounded" 
                                maxLength={4}
                                placeholder="e.g., WADD"
                            />
                            {isFetchingDestinationAirport && <p className="text-xs text-slate-500 mt-0.5">Fetching name...</p>}
                            {destinationAirportError && <p className="text-xs text-red-500 mt-0.5">{destinationAirportError}</p>}
                            {occurrenceReportFormData.routeDetails?.destinationAirportName && !isFetchingDestinationAirport && <p className="text-xs text-slate-600 mt-0.5 truncate" title={occurrenceReportFormData.routeDetails.destinationAirportName}>{occurrenceReportFormData.routeDetails.destinationAirportName}</p>}
                        </div>
                   </div>
                    <div>
                        <label htmlFor="routeDescription" className="text-xs font-medium">Route Description</label>
                        <textarea id="routeDescription" name="routeDescription" value={occurrenceReportFormData.routeDetails?.routeDescription || ''} onChange={handleOccurrenceReportFormChange} rows={2} className="w-full mt-0.5 p-1 border border-slate-300 rounded" placeholder="Auto-filled by flight/airport fetch, or enter manually."/>
                         <p className="text-xs text-slate-500">Source: {occurrenceReportFormData.routeDetails?.flightDataSource || 'Manual'}</p>
                    </div>
                 </div>
              </div>


              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="block font-medium text-slate-700">Location</label>
                    <div ref={mapRef} className="h-48 w-full rounded-md border border-slate-300 bg-slate-200 z-10"></div>
                     <div className="grid grid-cols-2 gap-2 text-xs">
                       <div>
                         <label htmlFor="latitude" className="block text-slate-600">Latitude</label>
                         <input type="number" step="any" id="latitude" name="latitude" value={occurrenceReportFormData.location?.latitude ?? ''} onChange={handleLocationInputChange} className="w-full p-1 border rounded" />
                       </div>
                       <div>
                         <label htmlFor="longitude" className="block text-slate-600">Longitude</label>
                         <input type="number" step="any" id="longitude" name="longitude" value={occurrenceReportFormData.location?.longitude ?? ''} onChange={handleLocationInputChange} className="w-full p-1 border rounded"/>
                       </div>
                     </div>
                     <p className="text-xs text-slate-500 p-1 bg-slate-50 border rounded h-10 overflow-y-auto">
                        <MapPinIcon className="h-3 w-3 inline mr-1" />
                        {isReverseGeocoding ? 'Fetching address...' : (occurrenceReportFormData.location?.addressString || 'Click on map or enter coordinates.')}
                    </p>
                  </div>
                   <div className="space-y-2">
                      <label className="block font-medium text-slate-700">Weather Forecast</label>
                       <div className="h-full p-3 border border-slate-200 bg-slate-50 rounded-md flex flex-col justify-center">
                          {isFetchingWeather ? <LoadingSpinner size="md" /> : (
                            occurrenceReportFormData.weatherForecast && occurrenceReportFormData.weatherForecast.weatherDescription ? (
                                <div className="space-y-2 text-center">
                                    <CloudIcon className="h-10 w-10 text-brand-secondary mx-auto"/>
                                    <p className="font-semibold text-lg text-slate-800">{occurrenceReportFormData.weatherForecast.weatherDescription}</p>
                                    <div className="text-slate-600 grid grid-cols-2 gap-1">
                                        <p>Temp: <span className="font-medium">{occurrenceReportFormData.weatherForecast.temperature?.toFixed(1) ?? 'N/A'} °C</span></p>
                                        <p>Wind: <span className="font-medium">{occurrenceReportFormData.weatherForecast.windSpeed?.toFixed(1) ?? 'N/A'} km/h</span></p>
                                    </div>
                                    <p className="text-[10px] text-slate-400">Source: {occurrenceReportFormData.weatherForecast.source} (Fetched: {occurrenceReportFormData.weatherForecast.fetchedAt ? new Date(occurrenceReportFormData.weatherForecast.fetchedAt).toLocaleTimeString() : 'N/A'})</p>
                                </div>
                            ) : (
                                <p className="text-slate-500 text-center text-xs">Weather data will be fetched when Date & Time and Location are set.</p>
                            )
                          )}
                       </div>
                  </div>
              </div>

              <div>
                <label htmlFor="description" className="block font-medium text-slate-700">Description</label>
                <textarea id="description" name="description" value={occurrenceReportFormData.description} onChange={handleOccurrenceReportFormChange} required rows={4} className="w-full mt-1 p-1.5 border border-slate-300 rounded"/>
              </div>

              <div className="flex justify-end space-x-3 pt-3">
                <button type="button" onClick={() => setIsOccurrenceReportModalOpen(false)} className="px-4 py-2 border rounded-md shadow-sm hover:bg-slate-50">Cancel</button>
                <button type="submit" className="px-4 py-2 bg-brand-primary text-white rounded-md shadow-sm hover:bg-blue-800">{editingOccurrenceReport ? 'Update Report' : 'Add Report'}</button>
              </div>
          </form>
        </Modal>
      )}

      {isFindingModalOpen && findingModalConfig !== null && (
        <SurveillanceFindingFormModal
          isOpen={isFindingModalOpen}
          onClose={() => setIsFindingModalOpen(false)}
          operatorId={operator.id}
          addSurveillanceFinding={addSurveillanceFinding}
          updateSurveillanceFinding={updateSurveillanceFinding}
          areaForNewFinding={findingModalConfig.area}
          findingToEdit={findingModalConfig.finding}
        />
      )}
      
      {isFindingsDisplayModalOpen && (
          <FindingsDisplayModal 
            isOpen={isFindingsDisplayModalOpen}
            onClose={() => setIsFindingsDisplayModalOpen(false)}
            title={findingsDisplayModalTitle}
            findings={findingsForDisplay}
          />
      )}

      {isImportConfirmModalOpen && jsonDataForImport && operator && (
          <Modal
              isOpen={isImportConfirmModalOpen}
              onClose={handleCancelImport}
              title="Operator ID Mismatch Warning"
              size="md"
          >
              <div className="text-sm text-slate-700">
                  <div className="flex items-start space-x-4">
                      <div className="flex-shrink-0">
                          <ExclamationTriangleIcon className="h-6 w-6 text-red-500" aria-hidden="true" />
                      </div>
                      <div className="flex-1 space-y-2">
                          <p>The JSON file you are importing appears to belong to a different operator.</p>
                          <div className="p-2 bg-slate-100 rounded text-xs space-y-1 font-mono">
                              <p>File Operator ID: <strong className="text-red-700">{jsonDataForImport.id}</strong></p>
                              <p>Current Operator ID: <strong>{operator.id}</strong></p>
                          </div>
                          <p>
                              Importing will <strong className="font-semibold text-red-700">overwrite all data</strong> for operator "{operator.name}" with the contents of the file. The operator's current ID ({operator.id}) will be preserved.
                          </p>
                          <p className="font-bold">This action cannot be undone. Are you sure you want to proceed?</p>
                      </div>
                  </div>
              </div>
              <div className="mt-6 flex justify-end space-x-3">
                  <button
                      type="button"
                      onClick={handleCancelImport}
                      className="px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md shadow-sm"
                  >
                      Cancel
                  </button>
                  <button
                      type="button"
                      onClick={handleConfirmImport}
                      className="px-4 py-2 text-sm font-medium text-white bg-red-600 hover:bg-red-700 rounded-md shadow-sm"
                  >
                      Yes, Proceed with Import
                  </button>
              </div>
          </Modal>
      )}
    </div>
  );
};
