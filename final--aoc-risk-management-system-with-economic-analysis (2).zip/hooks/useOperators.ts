

import React, { createContext, useContext, useEffect, useCallback, ReactNode } from 'react';
import { 
    Operator,
    LegacyRiskFactors,
    Occurrence, 
    RiskLevel, 
    OccurrenceType, 
    SeverityLevel,
    ComplexityFactors,
    ComplianceData,
    DeviationData,
    ImprovementData,
    SurveillanceFinding,
    FindingCategoryLevel,
    DEFAULT_COMPLEXITY_FACTORS,
    DEFAULT_COMPLIANCE_DATA,
    DEFAULT_DEVIATION_DATA,
    DEFAULT_IMPROVEMENT_DATA,
    DEFAULT_LEGACY_RISK_FACTORS,
    ExposureLevel,
    GroundingSource,
    OPERATOR_CATEGORIES,
    RiskIndicatorHistoryEntry,
    SurveillanceLogItem, 
    SurveillanceLogCategory,
    PredefinedSurveillanceArea, 
    EconomicFactors,
    SurveillanceLogStatus // Added for typing
} from '../types';
import useLocalStorage from './useLocalStorage';
import { updatedOperatorLegacyRiskProfile } from '../utils/riskCalculator'; // Legacy
import { calculateAllRbsMetrics } from '../utils/rbsCalculator'; // New RBS
import { MOCK_OPERATOR_LOGOS, FINDING_CATEGORY_TARGET_DAYS, PREDEFINED_SURVEILLANCE_AREAS } from '../constants';
import toast from 'react-hot-toast';

interface OperatorContextType {
  operators: Operator[];
  getOperatorById: (id: string) => Operator | undefined;
  addOperator: (operatorData: Pick<Operator, 'name' | 'aocNumber'> & Partial<Pick<Operator, 'complexityFactors' | 'complianceData' | 'deviationData' | 'improvementData' | 'legacyRiskFactors' | 'surveillanceFindings' | 'surveillanceLogs' | 'economicIndicatorScore' | 'operatorCategory' | 'hadFatalAccidentLast3Years' | 'economicFactors'>>) => Operator;
  updateOperatorBasicInfo: (id: string, basicInfo: Pick<Operator, 'name' | 'aocNumber' | 'logoUrl'>) => void;
  updateOperatorRBSData: (
    id: string, 
    data: {
      complexityFactors?: Partial<ComplexityFactors>;
      complianceData?: Partial<ComplianceData>;
      deviationData?: Partial<Pick<DeviationData, 'totalFlightCycles'>>; 
      improvementData?: Partial<ImprovementData>; 
    }
  ) => void;
  updateOperatorMiscData: ( 
    id: string,
    data: Partial<Pick<Operator, 'economicIndicatorScore' | 'operatorCategory' | 'hadFatalAccidentLast3Years' | 'financialReportText' | 'financialReportSources' | 'economicIndicatorScoreLastUpdatedByAI' | 'economicFactors'>>
  ) => void;
  deleteOperator: (id: string) => void;
  addLegacyOccurrence: (operatorId: string, occurrenceData: Omit<Occurrence, 'id'>) => void;
  updateLegacyOccurrence: (operatorId: string, occurrenceId: string, updatedOccurrenceData: Partial<Omit<Occurrence, 'id'>>) => void;
  deleteLegacyOccurrence: (operatorId: string, occurrenceId: string) => void;

  addSurveillanceFinding: (operatorId: string, findingData: Omit<SurveillanceFinding, 'id' | 'isCompleted' | 'dateAdded' | 'actualCompletionDate' | 'targetCompletionDate'>) => void;
  updateSurveillanceFinding: (operatorId: string, findingId: string, updatedData: Partial<Omit<SurveillanceFinding, 'id' | 'dateAdded' | 'actualCompletionDate' | 'targetCompletionDate'> & { isCompleted?: boolean }>) => void;
  deleteSurveillanceFinding: (operatorId: string, findingId: string) => void;
  toggleSurveillanceFindingCompletion: (operatorId: string, findingId: string) => void;

  // Surveillance Logs
  upsertSurveillanceLogItem: (operatorId: string, predefinedAreaId: string, status: SurveillanceLogStatus, notes?: string) => void;
  deleteSurveillanceLogItem: (operatorId: string, predefinedAreaId: string) => void; // Changed to predefinedAreaId for deletion

  // JSON Import
  importOperatorData: (operatorId: string, jsonData: Partial<Operator>) => void;
}

const OperatorContext = createContext<OperatorContextType | undefined>(undefined);

const MAX_HISTORY_ENTRIES = 730; 

const DEFAULT_ECONOMIC_FACTORS: EconomicFactors = {
  liquidity: 5, 
  shortTermDebt: 5,
  longTermDebt: 5,
  decapitalization: 5,
  profitabilityAndCashFlows: 5,
  lastUpdatedByAI: undefined,
};


function processOperatorData(operator: Operator): Operator {
  const rbsMetrics = calculateAllRbsMetrics(operator);
  const legacyProfile = updatedOperatorLegacyRiskProfile(operator); 

  const today = new Date().toISOString().split('T')[0]; 
  let updatedHistory = [...(operator.riskIndicatorHistory || [])];
  const lastEntry = updatedHistory.length > 0 ? updatedHistory[updatedHistory.length - 1] : null;

  const currentEconomicIndicatorScore = operator.economicIndicatorScore ?? 2.5;

  if (!lastEntry || lastEntry.date !== today) {
    const newHistoryEntry: RiskIndicatorHistoryEntry = {
      date: today,
      technicalIndicator: rbsMetrics.riskIndicatorLevel!,
      economicIndicator: currentEconomicIndicatorScore, 
      performanceScore: rbsMetrics.overallPerformanceScore!,
      exposureLevel: rbsMetrics.exposureLevel!,
    };
    updatedHistory.push(newHistoryEntry);
  } else {
    lastEntry.technicalIndicator = rbsMetrics.riskIndicatorLevel!;
    lastEntry.economicIndicator = currentEconomicIndicatorScore; 
    lastEntry.performanceScore = rbsMetrics.overallPerformanceScore!;
    lastEntry.exposureLevel = rbsMetrics.exposureLevel!;
  }

  if (updatedHistory.length > MAX_HISTORY_ENTRIES) {
    updatedHistory = updatedHistory.slice(updatedHistory.length - MAX_HISTORY_ENTRIES);
  }
  
  return {
    ...operator,
    ...rbsMetrics,
    legacyOverallRiskScore: legacyProfile.legacyOverallRiskScore,
    legacyOverallRiskLevel: legacyProfile.legacyOverallRiskLevel,
    surveillanceFindings: operator.surveillanceFindings?.map(sf => ({
      ...sf,
      targetCompletionDate: calculateTargetDate(sf.dateAdded, sf.findingCategory) 
    })) || [],
    surveillanceLogs: operator.surveillanceLogs || [], // Processed in useEffect for migration
    lastUpdated: new Date().toISOString(),
    economicIndicatorScore: currentEconomicIndicatorScore, 
    operatorCategory: operator.operatorCategory ?? OPERATOR_CATEGORIES[0], 
    hadFatalAccidentLast3Years: operator.hadFatalAccidentLast3Years ?? false, 
    financialReportText: operator.financialReportText ?? '',
    financialReportSources: operator.financialReportSources ?? [],
    economicIndicatorScoreLastUpdatedByAI: operator.economicIndicatorScoreLastUpdatedByAI,
    economicFactors: operator.economicFactors ?? { ...DEFAULT_ECONOMIC_FACTORS },
    riskIndicatorHistory: updatedHistory,
  };
}
const initialOperators: Operator[] = [
].map(op => processOperatorData(op as Operator)); 


const calculateTargetDate = (dateAddedString: string, category: FindingCategoryLevel): string => {
  const dateAdded = new Date(dateAddedString);
  const daysToAdd = FINDING_CATEGORY_TARGET_DAYS[category] || 60; 
  dateAdded.setDate(dateAdded.getDate() + daysToAdd);
  return dateAdded.toISOString();
};


export const OperatorProvider = ({ children }: { children: ReactNode }): JSX.Element => {
  const [operators, setOperators] = useLocalStorage<Operator[]>('operators_rbs_v15', initialOperators.map(processOperatorData)); // Version bump for 'On Going' status

  const getOperatorById = useCallback((id: string) => operators.find(op => op.id === id), [operators]);

  const updateOperatorState = (updatedOperators: Operator[]) => {
    setOperators(updatedOperators.map(op => processOperatorData(op)));
  };

  const addOperator = (
    operatorData: Pick<Operator, 'name' | 'aocNumber'> & Partial<Pick<Operator, 'complexityFactors' | 'complianceData' | 'deviationData' | 'improvementData' | 'legacyRiskFactors' | 'surveillanceFindings' | 'surveillanceLogs' | 'economicIndicatorScore' | 'operatorCategory' | 'hadFatalAccidentLast3Years' | 'economicFactors'>>
  ): Operator => {
    const newOperatorBase = {
      name: operatorData.name,
      aocNumber: operatorData.aocNumber,
      complexityFactors: operatorData.complexityFactors || { ...DEFAULT_COMPLEXITY_FACTORS },
      complianceData: operatorData.complianceData || { ...DEFAULT_COMPLIANCE_DATA },
      deviationData: operatorData.deviationData || { ...DEFAULT_DEVIATION_DATA }, 
      improvementData: operatorData.improvementData || { ...DEFAULT_IMPROVEMENT_DATA }, 
      legacyRiskFactors: operatorData.legacyRiskFactors || { ...DEFAULT_LEGACY_RISK_FACTORS, occurrences: [] }, 
      surveillanceFindings: operatorData.surveillanceFindings || [],
      surveillanceLogs: operatorData.surveillanceLogs || [], 
      economicIndicatorScore: operatorData.economicIndicatorScore ?? 2.5,
      operatorCategory: operatorData.operatorCategory ?? OPERATOR_CATEGORIES[0],
      hadFatalAccidentLast3Years: operatorData.hadFatalAccidentLast3Years ?? false,
      financialReportText: '',
      financialReportSources: [],
      economicIndicatorScoreLastUpdatedByAI: undefined,
      economicFactors: operatorData.economicFactors || { ...DEFAULT_ECONOMIC_FACTORS },
      riskIndicatorHistory: [], 
    };
    
    const tempFullOperator: Operator = {
        ...newOperatorBase,
        id: `op-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
        logoUrl: MOCK_OPERATOR_LOGOS[operators.length % MOCK_OPERATOR_LOGOS.length],
        lastUpdated: new Date().toISOString(), 
        exposureScore:0, exposureLevel: ExposureLevel.A, complianceFactorScore:0, deviationFactorScore:0, improvementFactorScore:0, overallPerformanceScore:0, riskIndicatorLevel:1, finalRiskCategoryKey: "1A", suggestedSurveillanceCycleMonths:18, legacyOverallRiskScore:0, legacyOverallRiskLevel: RiskLevel.LOW
    }

    const finalNewOperator = processOperatorData(tempFullOperator);
    setOperators(prevOperators => [...prevOperators, finalNewOperator]); 
    toast.success(`Operator "${finalNewOperator.name}" added successfully!`);
    return finalNewOperator;
  };

  const updateOperatorBasicInfo = (id: string, basicInfo: Pick<Operator, 'name' | 'aocNumber' | 'logoUrl'>) => {
    const currentOperator = getOperatorById(id);
    if (!currentOperator) return;
    const updatedOperator = { ...currentOperator, ...basicInfo, lastUpdated: new Date().toISOString() };
    updateOperatorState(operators.map(op => op.id === id ? updatedOperator : op));
    toast.success(`Operator "${updatedOperator.name}" basic info updated.`);
  };

  const updateOperatorRBSData = (
    id: string, 
    data: {
      complexityFactors?: Partial<ComplexityFactors>;
      complianceData?: Partial<ComplianceData>;
      deviationData?: Partial<Pick<DeviationData, 'totalFlightCycles'>>; 
      improvementData?: Partial<ImprovementData>; 
    }
  ) => {
    const currentOperator = getOperatorById(id);
    if (!currentOperator) return;
    
    const updatedOperator = {
      ...currentOperator,
      complexityFactors: data.complexityFactors ? { ...currentOperator.complexityFactors, ...data.complexityFactors } : currentOperator.complexityFactors,
      complianceData: data.complianceData ? { ...currentOperator.complianceData, ...data.complianceData } : currentOperator.complianceData,
      deviationData: data.deviationData ? { ...currentOperator.deviationData, totalFlightCycles: data.deviationData.totalFlightCycles ?? currentOperator.deviationData.totalFlightCycles } : currentOperator.deviationData,
      improvementData: data.improvementData ? { ...currentOperator.improvementData, ...data.improvementData} : currentOperator.improvementData,
      lastUpdated: new Date().toISOString(),
    };
    updateOperatorState(operators.map(op => op.id === id ? updatedOperator : op));
    toast.success(`RBS data for "${currentOperator.name}" updated.`);
  };

  const updateOperatorMiscData = (
    id: string,
    data: Partial<Pick<Operator, 'economicIndicatorScore' | 'operatorCategory' | 'hadFatalAccidentLast3Years' | 'financialReportText' | 'financialReportSources' | 'economicIndicatorScoreLastUpdatedByAI' | 'economicFactors'>>
  ) => {
    const currentOperator = getOperatorById(id);
    if (!currentOperator) return;
    
    const updatedOperatorRaw = { 
      ...currentOperator,
      ...data,
      economicFactors: data.economicFactors ? { ...currentOperator.economicFactors, ...data.economicFactors } : currentOperator.economicFactors,
      lastUpdated: new Date().toISOString(),
    };
    const finalUpdatedOperator = processOperatorData(updatedOperatorRaw);
    setOperators(operators.map(op => op.id === id ? finalUpdatedOperator : op));
    toast.success(`Additional data for "${currentOperator.name}" updated.`);
  };


  const deleteOperator = (id: string) => {
    const opName = getOperatorById(id)?.name;
    setOperators(ops => ops.filter(op => op.id !== id));
    toast.success(`Operator "${opName || 'Unknown'}" deleted.`);
  };

  const addLegacyOccurrence = (operatorId: string, occurrenceData: Omit<Occurrence, 'id'>) => {
    const operator = getOperatorById(operatorId);
    if (!operator) return;
    const newOccurrence: Occurrence = {
      ...occurrenceData,
      id: `occ-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
    };
    const updatedLegacyRiskFactors = {
      ...operator.legacyRiskFactors,
      occurrences: [...(operator.legacyRiskFactors?.occurrences || []), newOccurrence],
    };
    const updatedOperator = { ...operator, legacyRiskFactors: updatedLegacyRiskFactors, lastUpdated: new Date().toISOString() };
    updateOperatorState(operators.map(op => op.id === operatorId ? updatedOperator : op));
    toast.success(`Occurrence report added to "${operator.name}".`);
  };

  const updateLegacyOccurrence = (operatorId: string, occurrenceId: string, updatedOccurrenceData: Partial<Omit<Occurrence, 'id'>>) => {
    const operator = getOperatorById(operatorId);
    if (!operator) return;
    const updatedOccurrences = (operator.legacyRiskFactors?.occurrences || []).map(occ =>
      occ.id === occurrenceId ? { ...occ, ...updatedOccurrenceData } : occ
    );
    const updatedLegacyRiskFactors = { ...(operator.legacyRiskFactors || DEFAULT_LEGACY_RISK_FACTORS), occurrences: updatedOccurrences };
    const updatedOperator = { ...operator, legacyRiskFactors: updatedLegacyRiskFactors, lastUpdated: new Date().toISOString() };
    updateOperatorState(operators.map(op => op.id === operatorId ? updatedOperator : op));
    toast.success(`Occurrence report updated for "${operator.name}".`);
  };

  const deleteLegacyOccurrence = (operatorId: string, occurrenceId: string) => {
    const operator = getOperatorById(operatorId);
    if (!operator) return;

    const currentOccurrences = operator.legacyRiskFactors?.occurrences || [];
    const updatedOccurrences = currentOccurrences.filter(occ => occ.id !== occurrenceId);

    if (updatedOccurrences.length === currentOccurrences.length) {
        console.warn(`Occurrence report with ID "${occurrenceId}" not found for operator "${operator.name}". No deletion occurred.`);
        return; 
    }

    const updatedLegacyRiskFactors = { 
      ...(operator.legacyRiskFactors || DEFAULT_LEGACY_RISK_FACTORS), 
      occurrences: updatedOccurrences 
    };
    const finalUpdatedOperator = { 
        ...operator, 
        legacyRiskFactors: updatedLegacyRiskFactors, 
        lastUpdated: new Date().toISOString() 
    };
    
    updateOperatorState(operators.map(op => 
        op.id === operatorId 
        ? finalUpdatedOperator 
        : op
    ));
    toast.success(`Occurrence report deleted from "${operator.name}".`);
  };
  
  const addSurveillanceFinding = (operatorId: string, findingData: Omit<SurveillanceFinding, 'id' | 'isCompleted' | 'dateAdded' | 'actualCompletionDate' | 'targetCompletionDate'>) => {
    const operator = getOperatorById(operatorId);
    if (!operator) return;
    const dateAdded = new Date().toISOString();
    
    let itemNumber = findingData.itemNumber;
    let areaDescription = findingData.areaDescription;

    if (findingData.predefinedAreaId) {
        const predefinedArea = PREDEFINED_SURVEILLANCE_AREAS.find(pa => pa.id === findingData.predefinedAreaId);
        if (predefinedArea) {
            itemNumber = predefinedArea.itemNumber;
            areaDescription = predefinedArea.areaDescription;
        }
    }

    const newFinding: SurveillanceFinding = {
      ...findingData,
      itemNumber,
      areaDescription,
      id: `sf-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      isCompleted: false, 
      dateAdded: dateAdded,
      targetCompletionDate: calculateTargetDate(dateAdded, findingData.findingCategory),
    };
    const updatedSurveillanceFindings = [...(operator.surveillanceFindings || []), newFinding];
    
    let updatedSurveillanceLogs = [...(operator.surveillanceLogs || [])];
    const predefinedAreaId = newFinding.predefinedAreaId;

    if (predefinedAreaId) {
        const logIndex = updatedSurveillanceLogs.findIndex(log => log.predefinedAreaId === predefinedAreaId);
        const areaDetails = PREDEFINED_SURVEILLANCE_AREAS.find(pa => pa.id === predefinedAreaId);

        if (logIndex > -1) {
            if (updatedSurveillanceLogs[logIndex].status === 'Not Done') {
                updatedSurveillanceLogs[logIndex] = { ...updatedSurveillanceLogs[logIndex], status: 'On Going', lastUpdated: new Date().toISOString(), notes: updatedSurveillanceLogs[logIndex].notes || 'Status automatically set to On Going.' };
                toast(`Status for area ${areaDetails?.itemNumber} set to "On Going".`, { icon: 'ℹ️' });
            }
        } else {
            if(areaDetails) {
                 const newLogItem: SurveillanceLogItem = {
                    id: `slog-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
                    predefinedAreaId: areaDetails.id,
                    category: areaDetails.category,
                    itemNumber: areaDetails.itemNumber,
                    area: areaDetails.areaDescription,
                    status: 'On Going',
                    notes: 'Status set to On Going due to new finding.',
                    lastUpdated: new Date().toISOString(),
                };
                updatedSurveillanceLogs.push(newLogItem);
                toast(`Status for area ${areaDetails.itemNumber} set to "On Going".`, { icon: 'ℹ️' });
            }
        }
    }

    updateOperatorState(operators.map(op => op.id === operatorId ? {...op, surveillanceFindings: updatedSurveillanceFindings, surveillanceLogs: updatedSurveillanceLogs, lastUpdated: new Date().toISOString()} : op));
    toast.success(`Surveillance finding added to "${operator.name}".`);
  };

  const updateSurveillanceFinding = (operatorId: string, findingId: string, updatedData: Partial<Omit<SurveillanceFinding, 'id' | 'dateAdded' | 'actualCompletionDate' | 'targetCompletionDate'> & { isCompleted?: boolean }>) => {
    const operator = getOperatorById(operatorId);
    if (!operator) return;
    const currentFindings = operator.surveillanceFindings || [];
    const originalFinding = currentFindings.find(f => f.id === findingId);
    if (!originalFinding) return;

    const updatedSurveillanceFindings = currentFindings.map(f => {
      if (f.id === findingId) {
        const newCategory = updatedData.findingCategory || f.findingCategory;
        const newIsCompleted = updatedData.isCompleted !== undefined ? updatedData.isCompleted : f.isCompleted;
        
        let actualCompletionDate = f.actualCompletionDate;
        if (newIsCompleted && !f.isCompleted) { 
            actualCompletionDate = new Date().toISOString();
            if(!updatedData.correctiveActionTaken?.trim() && !f.correctiveActionTaken?.trim()){
                 toast("Finding marked as completed. Please ensure 'Mitigation Action' is filled for Risk Mitigated credit.", {icon: 'ℹ️', duration: 5000});
            }
        } else if (!newIsCompleted && f.isCompleted) { 
            actualCompletionDate = undefined;
        } else if (newIsCompleted && f.isCompleted && !updatedData.correctiveActionTaken?.trim() && !f.correctiveActionTaken?.trim() && !updatedData.hasOwnProperty('correctiveActionTaken')) {
           if (!f.correctiveActionTaken?.trim()) {
                toast("Finding remains completed. Please ensure 'Mitigation Action' is filled for Risk Mitigated credit.", {icon: 'ℹ️', duration: 5000});
           }
        }


        let itemNumber = updatedData.itemNumber || f.itemNumber;
        let areaDescription = updatedData.areaDescription || f.areaDescription;

        if (updatedData.predefinedAreaId && updatedData.predefinedAreaId !== f.predefinedAreaId) {
            const predefinedArea = PREDEFINED_SURVEILLANCE_AREAS.find(pa => pa.id === updatedData.predefinedAreaId);
            if (predefinedArea) {
                itemNumber = predefinedArea.itemNumber;
                areaDescription = predefinedArea.areaDescription;
            }
        }

        return { 
          ...f, 
          ...updatedData, 
          itemNumber,
          areaDescription,
          targetCompletionDate: calculateTargetDate(f.dateAdded, newCategory),
          actualCompletionDate: actualCompletionDate,
          isCompleted: newIsCompleted, 
        };
      }
      return f;
    });

    const updatedFinding = updatedSurveillanceFindings.find(f => f.id === findingId)!;
    let updatedSurveillanceLogs = [...(operator.surveillanceLogs || [])];
    const predefinedAreaId = updatedFinding.predefinedAreaId;

    if (predefinedAreaId) {
        const wasCompleted = originalFinding.isCompleted;
        const isNowCompleted = updatedFinding.isCompleted;
        const areaDetails = PREDEFINED_SURVEILLANCE_AREAS.find(pa => pa.id === predefinedAreaId);

        if (isNowCompleted && !wasCompleted) {
            const hasOtherOpenFindings = updatedSurveillanceFindings.some(f => 
                f.id !== findingId && f.predefinedAreaId === predefinedAreaId && !f.isCompleted
            );
            if (!hasOtherOpenFindings) {
                const logIndex = updatedSurveillanceLogs.findIndex(l => l.predefinedAreaId === predefinedAreaId);
                if (logIndex > -1) {
                    updatedSurveillanceLogs[logIndex] = { ...updatedSurveillanceLogs[logIndex], status: 'Done', lastUpdated: new Date().toISOString(), notes: updatedSurveillanceLogs[logIndex].notes || 'Status automatically set to Done.' };
                    toast(`Status for area ${areaDetails?.itemNumber} set to "Done".`, { icon: 'ℹ️' });
                }
            }
        } else if (!isNowCompleted && wasCompleted) {
            const logIndex = updatedSurveillanceLogs.findIndex(l => l.predefinedAreaId === predefinedAreaId);
            if (logIndex > -1 && updatedSurveillanceLogs[logIndex].status === 'Done') {
                updatedSurveillanceLogs[logIndex] = { ...updatedSurveillanceLogs[logIndex], status: 'On Going', lastUpdated: new Date().toISOString(), notes: updatedSurveillanceLogs[logIndex].notes || 'Status automatically set to On Going.' };
                toast(`Status for area ${areaDetails?.itemNumber} set to "On Going".`, { icon: 'ℹ️' });
            }
        }
    }

    updateOperatorState(operators.map(op => op.id === operatorId ? {...op, surveillanceFindings: updatedSurveillanceFindings, surveillanceLogs: updatedSurveillanceLogs, lastUpdated: new Date().toISOString()} : op));
    toast.success(`Surveillance finding updated for "${operator.name}".`);
  };
  
  const deleteSurveillanceFinding = (operatorId: string, findingId: string) => {
    const operator = getOperatorById(operatorId);
    if (!operator) return;
    
    const currentFindings = operator.surveillanceFindings || [];
    const updatedSurveillanceFindings = currentFindings.filter(f => f.id !== findingId);

    if (updatedSurveillanceFindings.length === currentFindings.length) {
        console.warn(`Surveillance finding with ID "${findingId}" not found for operator "${operator.name}". No deletion occurred.`);
        return; 
    }

    updateOperatorState(operators.map(op => 
      op.id === operatorId 
        ? { ...op, surveillanceFindings: updatedSurveillanceFindings, lastUpdated: new Date().toISOString() } 
        : op
    ));
    toast.success(`Surveillance finding deleted from "${operator.name}".`);
  };

  const toggleSurveillanceFindingCompletion = (operatorId: string, findingId: string) => {
    const operator = getOperatorById(operatorId);
    if (!operator) return;
    const currentFindings = operator.surveillanceFindings || [];
    const originalFinding = currentFindings.find(f => f.id === findingId);
    if (!originalFinding) return;

    let findingForToast: SurveillanceFinding | undefined;
    
    const updatedSurveillanceFindings = currentFindings.map(f => {
      if (f.id === findingId) {
        const newIsCompleted = !f.isCompleted;
        let actualCompletionDate = f.actualCompletionDate;
        if(newIsCompleted) { 
            actualCompletionDate = new Date().toISOString();
            if(!f.correctiveActionTaken?.trim()){
                 toast("Finding marked as completed. Please ensure 'Mitigation Action' is filled for Risk Mitigated credit.", {icon: 'ℹ️', duration: 5000});
            }
        } else { 
            actualCompletionDate = undefined;
        }
        findingForToast = { ...f, isCompleted: newIsCompleted, actualCompletionDate };
        return findingForToast;
      }
      return f;
    });
    
    const updatedFinding = updatedSurveillanceFindings.find(f => f.id === findingId)!;
    let updatedSurveillanceLogs = [...(operator.surveillanceLogs || [])];
    const predefinedAreaId = updatedFinding.predefinedAreaId;

    if (predefinedAreaId) {
        const wasCompleted = originalFinding.isCompleted;
        const isNowCompleted = updatedFinding.isCompleted;
        const areaDetails = PREDEFINED_SURVEILLANCE_AREAS.find(pa => pa.id === predefinedAreaId);

        if (isNowCompleted && !wasCompleted) {
            const hasOtherOpenFindings = updatedSurveillanceFindings.some(f => 
                f.id !== findingId && f.predefinedAreaId === predefinedAreaId && !f.isCompleted
            );
            if (!hasOtherOpenFindings) {
                const logIndex = updatedSurveillanceLogs.findIndex(l => l.predefinedAreaId === predefinedAreaId);
                if (logIndex > -1) {
                    updatedSurveillanceLogs[logIndex] = { ...updatedSurveillanceLogs[logIndex], status: 'Done', lastUpdated: new Date().toISOString(), notes: updatedSurveillanceLogs[logIndex].notes || 'Status automatically set to Done.' };
                    toast(`Status for area ${areaDetails?.itemNumber} set to "Done".`, { icon: 'ℹ️' });
                }
            }
        } else if (!isNowCompleted && wasCompleted) {
            const logIndex = updatedSurveillanceLogs.findIndex(l => l.predefinedAreaId === predefinedAreaId);
            if (logIndex > -1 && updatedSurveillanceLogs[logIndex].status === 'Done') {
                updatedSurveillanceLogs[logIndex] = { ...updatedSurveillanceLogs[logIndex], status: 'On Going', lastUpdated: new Date().toISOString(), notes: updatedSurveillanceLogs[logIndex].notes || 'Status automatically set to On Going.' };
                toast(`Status for area ${areaDetails?.itemNumber} set to "On Going".`, { icon: 'ℹ️' });
            }
        }
    }

    updateOperatorState(operators.map(op => op.id === operatorId ? {...op, surveillanceFindings: updatedSurveillanceFindings, surveillanceLogs: updatedSurveillanceLogs, lastUpdated: new Date().toISOString()} : op));
    if (findingForToast) {
        toast.success(`Finding marked as ${findingForToast.isCompleted ? 'Completed' : 'Open'}.`);
    }
  };

  // Surveillance Log CRUD
  const upsertSurveillanceLogItem = (operatorId: string, predefinedAreaId: string, status: SurveillanceLogStatus, notes?: string) => {
    const operator = getOperatorById(operatorId);
    if (!operator) return;

    const predefinedAreaDetails = PREDEFINED_SURVEILLANCE_AREAS.find(pa => pa.id === predefinedAreaId);
    if (!predefinedAreaDetails) {
        toast.error(`Predefined area with ID ${predefinedAreaId} not found.`);
        return;
    }

    const existingLogIndex = (operator.surveillanceLogs || []).findIndex(log => log.predefinedAreaId === predefinedAreaId);
    let updatedSurveillanceLogs;

    if (existingLogIndex > -1) {
      // Update existing log item
      updatedSurveillanceLogs = (operator.surveillanceLogs || []).map((log, index) => {
        if (index === existingLogIndex) {
          return {
            ...log,
            status,
            notes: notes ?? log.notes ?? '', // Preserve existing notes if new notes are undefined
            lastUpdated: new Date().toISOString(),
          };
        }
        return log;
      });
      toast.success(`Surveillance log for area "${predefinedAreaDetails.itemNumber}" updated.`);
    } else {
      // Add new log item
      const newLogItem: SurveillanceLogItem = {
        id: `slog-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
        predefinedAreaId: predefinedAreaDetails.id,
        category: predefinedAreaDetails.category,
        itemNumber: predefinedAreaDetails.itemNumber,
        area: predefinedAreaDetails.areaDescription,
        status,
        notes: notes || '',
        lastUpdated: new Date().toISOString(),
      };
      updatedSurveillanceLogs = [...(operator.surveillanceLogs || []), newLogItem];
      toast.success(`Surveillance log for area "${predefinedAreaDetails.itemNumber}" added.`);
    }
    updateOperatorState(operators.map(op => op.id === operatorId ? {...op, surveillanceLogs: updatedSurveillanceLogs, lastUpdated: new Date().toISOString()} : op));
  };


  const deleteSurveillanceLogItem = (operatorId: string, predefinedAreaIdToDelete: string) => {
    const operator = getOperatorById(operatorId);
    if (!operator) return;
    const updatedSurveillanceLogs = (operator.surveillanceLogs || []).filter(log => log.predefinedAreaId !== predefinedAreaIdToDelete);
    const predefinedAreaDetails = PREDEFINED_SURVEILLANCE_AREAS.find(pa => pa.id === predefinedAreaIdToDelete);
    updateOperatorState(operators.map(op => op.id === operatorId ? {...op, surveillanceLogs: updatedSurveillanceLogs, lastUpdated: new Date().toISOString()} : op));
    toast.success(`Surveillance log for area "${predefinedAreaDetails?.itemNumber || 'Unknown'}" cleared.`);
  };

  const importOperatorData = (operatorId: string, jsonData: Partial<Operator>) => {
    const operatorToUpdate = getOperatorById(operatorId);
    if (!operatorToUpdate) {
      toast.error(`Operator with ID "${operatorId}" not found for import.`);
      return;
    }

    let updatedOperatorData = { ...operatorToUpdate };

    // Merge jsonData into operatorToUpdate, but explicitly ignore the 'id' field
    // from the JSON file to prevent changing the ID of the current operator.
    for (const key in jsonData) {
        if (Object.prototype.hasOwnProperty.call(jsonData, key)) {
            const typedKey = key as keyof Operator;
            
            // Skip the 'id' key to preserve the existing operator's ID
            if (typedKey === 'id') {
                continue;
            }

            if (jsonData[typedKey] !== undefined) {
                 (updatedOperatorData as any)[typedKey] = jsonData[typedKey];
            }
        }
    }
    
    // Ensure all default structures are present if partial data was imported
    // This is important because processOperatorData expects a complete Operator structure
    updatedOperatorData.complexityFactors = { ...DEFAULT_COMPLEXITY_FACTORS, ...(updatedOperatorData.complexityFactors || {}) };
    updatedOperatorData.complianceData = {
        ...DEFAULT_COMPLIANCE_DATA,
        ...(updatedOperatorData.complianceData || {}),
        findings: { ...DEFAULT_COMPLIANCE_DATA.findings, ...(updatedOperatorData.complianceData?.findings || {}) }
    };
    updatedOperatorData.deviationData = { ...DEFAULT_DEVIATION_DATA, ...(updatedOperatorData.deviationData || {}) };
    updatedOperatorData.improvementData = { ...DEFAULT_IMPROVEMENT_DATA, ...(updatedOperatorData.improvementData || {}) };
    updatedOperatorData.legacyRiskFactors = { 
        ...DEFAULT_LEGACY_RISK_FACTORS, 
        ...(updatedOperatorData.legacyRiskFactors || {}), 
        occurrences: updatedOperatorData.legacyRiskFactors?.occurrences || [] 
    };
    updatedOperatorData.surveillanceFindings = updatedOperatorData.surveillanceFindings || [];
    updatedOperatorData.surveillanceLogs = updatedOperatorData.surveillanceLogs || [];
    updatedOperatorData.riskIndicatorHistory = updatedOperatorData.riskIndicatorHistory || [];
    updatedOperatorData.economicFactors = { ...DEFAULT_ECONOMIC_FACTORS, ...(updatedOperatorData.economicFactors || {}) };
    updatedOperatorData.financialReportSources = updatedOperatorData.financialReportSources || [];

    // processOperatorData will handle recalculations and target dates
    const finalUpdatedOperator = processOperatorData(updatedOperatorData as Operator);
    
    setOperators(prevOperators => prevOperators.map(op => op.id === operatorId ? finalUpdatedOperator : op));
    toast.success(`Operator "${finalUpdatedOperator.name}" data imported and updated successfully!`);
  };


  useEffect(() => {
    let needsProcessing = operators.some(op => 
      !op.hasOwnProperty('overallPerformanceScore') || 
      !op.surveillanceFindings || 
      op.surveillanceFindings.some(sf => !sf.hasOwnProperty('findingCategory') || !sf.hasOwnProperty('surveillanceLogCategoryId') || !sf.hasOwnProperty('isCompleted')) || 
      !op.hasOwnProperty('economicIndicatorScore') || 
      !op.hasOwnProperty('economicIndicatorScoreLastUpdatedByAI') ||
      !op.hasOwnProperty('riskIndicatorHistory') ||
      (op.riskIndicatorHistory && op.riskIndicatorHistory.some(h => (h as any).hasOwnProperty('level') || !h.hasOwnProperty('economicIndicator'))) ||
      !op.hasOwnProperty('surveillanceLogs') ||
      !op.hasOwnProperty('economicFactors') ||
      op.surveillanceFindings.some(sf => !sf.hasOwnProperty('riskAssessment')) // Check for new field
    );

    // Specific migration for SurveillanceLogItem structure change
    const needsLogMigration = operators.some(op => 
        (op.surveillanceLogs || []).some(log => log.hasOwnProperty('lastConductedDate') || !log.hasOwnProperty('status') || log.status === ('On Going' as any))
    );
     if (needsLogMigration) console.log("Needs Surveillance Log Item migration");


    if (needsProcessing || needsLogMigration) {
      console.log("Processing or migrating operator data...");
      updateOperatorState(operators.map(op => {
        let migratedLogs = op.surveillanceLogs || [];
        if ((op.surveillanceLogs || []).some(log => (log as any).hasOwnProperty('lastConductedDate') || !log.hasOwnProperty('status'))){
            migratedLogs = (op.surveillanceLogs || []).map(log_any => {
                const log = log_any as any; // Allow access to old fields
                if (log.hasOwnProperty('lastConductedDate') || !log.hasOwnProperty('status')) {
                    const predefinedAreaDetails = PREDEFINED_SURVEILLANCE_AREAS.find(pa => pa.id === log.predefinedAreaId);
                    const newStatus: SurveillanceLogStatus = (log.lastConductedDate && String(log.lastConductedDate).trim() !== '') ? 'Done' : 'Not Done';
                    const newLastUpdated = (log.lastConductedDate && String(log.lastConductedDate).trim() !== '') ? new Date(log.lastConductedDate).toISOString() : new Date().toISOString();
                    
                    const migratedLog: SurveillanceLogItem = {
                        id: log.id,
                        predefinedAreaId: log.predefinedAreaId,
                        category: predefinedAreaDetails?.category || log.category, // Use predefined if available, else old
                        itemNumber: predefinedAreaDetails?.itemNumber || log.itemNumber,
                        area: predefinedAreaDetails?.areaDescription || log.area,
                        status: newStatus,
                        lastUpdated: newLastUpdated,
                        notes: log.notes || '',
                    };
                    // Remove old fields explicitly if they existed on `log`
                    // delete migratedLog.lastConductedDate; 
                    // delete migratedLog.formNumber;
                    return migratedLog;
                }
                return log as SurveillanceLogItem; // Already in new format
            });
        }


        return {
            ...op, 
            surveillanceFindings: (op.surveillanceFindings || []).map(sf_any => {
              const sf = sf_any as any; // To allow checking for old structure
              return {
                ...sf,
                surveillanceLogCategoryId: sf.surveillanceLogCategoryId, 
                predefinedAreaId: sf.predefinedAreaId,
                itemNumber: sf.itemNumber,
                areaDescription: sf.areaDescription,
                findingCategory: sf.findingCategory || FindingCategoryLevel.LEVEL_3,
                isCompleted: sf.isCompleted || false, 
                actualCompletionDate: sf.isCompleted ? (sf.actualCompletionDate || new Date().toISOString()) : undefined, 
                riskAssessment: sf.riskAssessment || '', // Add default for old data
              }
            }),
            surveillanceLogs: migratedLogs,
            legacyRiskFactors: { 
                ...(op.legacyRiskFactors || DEFAULT_LEGACY_RISK_FACTORS),
                occurrences: op.legacyRiskFactors?.occurrences || []
            },
            economicIndicatorScore: op.economicIndicatorScore ?? 2.5,
            operatorCategory: op.operatorCategory ?? OPERATOR_CATEGORIES[0],
            hadFatalAccidentLast3Years: op.hadFatalAccidentLast3Years ?? false,
            financialReportText: op.financialReportText ?? '',
            financialReportSources: op.financialReportSources ?? [],
            economicIndicatorScoreLastUpdatedByAI: op.economicIndicatorScoreLastUpdatedByAI,
            economicFactors: op.economicFactors || { ...DEFAULT_ECONOMIC_FACTORS }, 
            riskIndicatorHistory: (op.riskIndicatorHistory || []).map(h_any => {
                const h = h_any as any; 
                if (h.hasOwnProperty('level') && !h.hasOwnProperty('technicalIndicator')) {
                return {
                    date: h.date,
                    technicalIndicator: h.level,
                    economicIndicator: op.economicIndicatorScore ?? 2.5, 
                    performanceScore: h.performanceScore,
                    exposureLevel: h.exposureLevel,
                };
                }
                if (h.hasOwnProperty('technicalIndicator') && !h.hasOwnProperty('economicIndicator')) {
                    return {
                        ...h,
                        economicIndicator: op.economicIndicatorScore ?? 2.5, 
                    };
                }
                return h as RiskIndicatorHistoryEntry; 
            }),
        };
      }));
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); 

  const contextValue: OperatorContextType = { 
    operators, 
    getOperatorById, 
    addOperator, 
    updateOperatorBasicInfo,
    updateOperatorRBSData,
    updateOperatorMiscData,
    deleteOperator, 
    addLegacyOccurrence, 
    updateLegacyOccurrence, 
    deleteLegacyOccurrence,
    addSurveillanceFinding,
    updateSurveillanceFinding,
    deleteSurveillanceFinding,
    toggleSurveillanceFindingCompletion,
    upsertSurveillanceLogItem,
    deleteSurveillanceLogItem,
    importOperatorData,
  };

  return React.createElement(
    OperatorContext.Provider,
    { value: contextValue },
    children
  );
};

export const useOperators = (): OperatorContextType => {
  const context = useContext(OperatorContext);
  if (context === undefined) {
    throw new Error('useOperators must be used within an OperatorProvider');
  }
  return context;
};
