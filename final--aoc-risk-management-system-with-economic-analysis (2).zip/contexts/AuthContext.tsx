
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { UserProfile, UserRole } from '../types'; // Adjusted import
import useLocalStorage from '../hooks/useLocalStorage';

// Define mock users. In a real app, this would come from a backend.
export const MOCK_USER_PROFILES: UserProfile[] = [
  { id: 'admin_user', displayName: 'Administrator', role: UserRole.ADMIN },
  { id: 'garuda_mgr', displayName: 'Garuda Supervisor', role: UserRole.RESTRICTED_USER, managesOperatorNameContaining: 'Garuda' },
  { id: 'lion_mgr', displayName: 'Lion Air Supervisor', role: UserRole.RESTRICTED_USER, managesOperatorNameContaining: 'Lion Air' },
  { id: 'general_user', displayName: 'General Staff', role: UserRole.RESTRICTED_USER }, // Can see operators not matching specific names if logic allows
];

interface AuthContextType {
  currentUser: UserProfile | null;
  isAuthLoading: boolean; // Kept for potential async operations in future, though current is sync
  authError: string | null;
  login: (userId: string) => boolean; // userId refers to UserProfile.id
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useLocalStorage<UserProfile | null>('currentUserProfile_v1', null);
  const [isAuthLoading, setIsAuthLoading] = useState(true); // Set to true initially
  const [authError, setAuthError] = useState<string | null>(null);

  useEffect(() => {
    // Simulate initial loading check or validation if needed
    // For now, just set loading to false after initial check of localStorage
    setIsAuthLoading(false);
  }, []);

  const login = (userId: string): boolean => {
    setIsAuthLoading(true);
    setAuthError(null);
    const profileToLogin = MOCK_USER_PROFILES.find(p => p.id === userId);

    if (profileToLogin) {
      setCurrentUser(profileToLogin);
      setIsAuthLoading(false);
      return true;
    } else {
      setAuthError(`User profile "${userId}" not found.`);
      setCurrentUser(null);
      setIsAuthLoading(false);
      return false;
    }
  };

  const logout = () => {
    setCurrentUser(null);
    setAuthError(null);
    // No complex cleanup needed for mock auth
  };

  return (
    <AuthContext.Provider value={{ currentUser, isAuthLoading, authError, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
