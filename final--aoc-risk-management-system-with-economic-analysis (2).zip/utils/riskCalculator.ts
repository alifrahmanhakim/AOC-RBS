import { Operator, LegacyRiskFactors, Occurrence, SeverityLevel, RiskLevel, SEVERITY_WEIGHTS } from '../types';
import { RISK_LEVEL_THRESHOLDS, WEIGHT_AIRCRAFT_FREQUENCY, WEIGHT_ENVIRONMENTAL_COMPLEXITY, WEIGHT_OCCURRENCES_SCORE } from '../constants';

// --- LEGACY RISK CALCULATION FUNCTIONS ---

export const calculateOccurrencesScore = (occurrences: Occurrence[]): number => {
  return occurrences.reduce((totalScore, occurrence) => {
    return totalScore + (SEVERITY_WEIGHTS[occurrence.severity] || 0);
  }, 0);
};

export const calculateLegacyOverallRiskScore = (riskFactors: LegacyRiskFactors): number => {
  const occurrencesScore = calculateOccurrencesScore(riskFactors.occurrences);
  const score =
    (riskFactors.aircraftFrequency * WEIGHT_AIRCRAFT_FREQUENCY) +
    (riskFactors.environmentalComplexity * WEIGHT_ENVIRONMENTAL_COMPLEXITY) +
    (occurrencesScore * WEIGHT_OCCURRENCES_SCORE);
  return Math.max(0, score); // Ensure score is not negative
};

export const determineLegacyRiskLevel = (score: number): RiskLevel => {
  if (score <= RISK_LEVEL_THRESHOLDS[RiskLevel.LOW].max) return RiskLevel.LOW;
  if (score <= RISK_LEVEL_THRESHOLDS[RiskLevel.MEDIUM].max) return RiskLevel.MEDIUM;
  if (score <= RISK_LEVEL_THRESHOLDS[RiskLevel.HIGH].max) return RiskLevel.HIGH;
  return RiskLevel.CRITICAL;
};

// This function now specifically refers to the legacy calculation
export const updatedOperatorLegacyRiskProfile = <T extends Pick<Operator, 'legacyRiskFactors'>>(operatorData: T): Pick<Operator, 'legacyOverallRiskScore' | 'legacyOverallRiskLevel'> => {
  const legacyOverallRiskScore = calculateLegacyOverallRiskScore(operatorData.legacyRiskFactors);
  const legacyOverallRiskLevel = determineLegacyRiskLevel(legacyOverallRiskScore);
  return { legacyOverallRiskScore, legacyOverallRiskLevel };
};

// --- END OF LEGACY FUNCTIONS ---
// New RBS calculation functions will be in a separate file: utils/rbsCalculator.ts
