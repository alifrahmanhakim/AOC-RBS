import { 
  Operator, 
  ComplexityFactors, 
  ComplianceData, 
  DeviationData, 
  ImprovementData, 
  ExposureLevel,
  RiskLevel,
  SurveillanceFinding,
  FindingCategoryLevel,
  OccurrenceType
} from '../types';
import {
  RBS_WEIGHT_COMPLIANCE,
  RBS_WEIGHT_DEVIATION,
  RBS_WEIGHT_IMPROVEMENT,
  RBS_COMPLIANCE_FINDING_WEIGHTS,
  RBS_DEVIATION_CATEGORY_WEIGHTS,
  RBS_CORRECTIVE_ACTION_WEIGHTS,
  RBS_PERFORMANCE_TO_INDICATOR_LEVEL,
  RBS_MATRIX_SURVEILLANCE_CYCLES,
  RBS_MATRIX_CELL_KEYS
} from '../constants';

// --- RBS Calculation Functions ---

// 1. Calculate Exposure Score and Level (Slide 30)
export const calculateExposureProfile = (cf: ComplexityFactors): { score: number, level: ExposureLevel } => {
  let score = 0;

  // Jumlah penerbangan tahunan
  if (cf.annualFlightCount > 45000) score += 3;
  else if (cf.annualFlightCount >= 4000) score += 2; 
  else if (cf.annualFlightCount > 0) score += 1; 

  // Jumlah Karyawan
  if (cf.numEmployees > 100) score += 3;
  else if (cf.numEmployees >= 10) score += 2; 
  else if (cf.numEmployees > 0)score += 1; 

  // Jumlah pesawat
  if (cf.numAircraft > 10) score += 3;
  else if (cf.numAircraft >= 4) score += 2;
  else if (cf.numAircraft > 0) score += 1;

  // Jumlah model pesawat
  if (cf.numAircraftModels > 5) score += 3;
  else if (cf.numAircraftModels >= 2) score += 2;
  else if (cf.numAircraftModels > 0) score += 1;
  
  // Jumlah tujuan
  if (cf.numDestinations > 50) score += 3;
  else if (cf.numDestinations >= 11) score += 2;
  else if (cf.numDestinations > 0) score += 1;

  // Operasi internasional
  if (cf.hasInternationalOps) score += 2;
  else score += 1;

  // Usia armada rata-rata
  if (cf.avgFleetAge > 15) score += 3;
  else if (cf.avgFleetAge >= 5) score += 2;
  else if (cf.avgFleetAge >= 0) score += 1; 

  // Jumlah pangkalan domestik
  if (cf.numDomesticBases > 10) score += 3;
  else if (cf.numDomesticBases >= 2) score += 2;
  else if (cf.numDomesticBases > 0) score += 1;
  
  let level: ExposureLevel;
  if (score < 10) level = ExposureLevel.A;       
  else if (score < 12) level = ExposureLevel.B;  
  else if (score < 14) level = ExposureLevel.C;  
  else if (score < 16) level = ExposureLevel.D;  
  else level = ExposureLevel.E;                  

  return { score, level };
};

export const calculateComplianceFactorScore = (
  complianceData: ComplianceData,
  surveillanceFindings?: SurveillanceFinding[]
): number => {
  if (complianceData.totalChecklistItems === 0) return 0;

  let ncp = 0;
  let ncf = 0;
  let nad = 0;

  const openFindings = surveillanceFindings?.filter(sf => !sf.isCompleted) || [];

  if (openFindings.length > 0) {
    ncp = openFindings.filter(sf => sf.findingCategory === FindingCategoryLevel.LEVEL_1).length;
    ncf = openFindings.filter(sf => sf.findingCategory === FindingCategoryLevel.LEVEL_2).length;
    nad = openFindings.filter(sf => sf.findingCategory === FindingCategoryLevel.LEVEL_3).length;
  } else {
    ncp = complianceData.findings.ncp;
    ncf = complianceData.findings.ncf;
    nad = complianceData.findings.nad;
  }

  const Mf = (ncp * RBS_COMPLIANCE_FINDING_WEIGHTS.ncp) +
             (ncf * RBS_COMPLIANCE_FINDING_WEIGHTS.ncf) +
             (nad * RBS_COMPLIANCE_FINDING_WEIGHTS.nad);
             
  const xc = Mf / complianceData.totalChecklistItems;
  return Math.max(0, Math.min(1, 1 - xc)); // Clamp between 0 and 1
};


// 3. Calculate Deviation Factor D(p) (Slide 20)
export const calculateDeviationFactorScore = (data: DeviationData): number => {
  if (data.totalFlightCycles === 0) {
    // If no flight cycles, score is 0 if no incidents/accidents, otherwise max penalty (lower D(p) score is better, so return higher for penalty)
    if (data.accidentCount === 0 && data.seriousIncidentCount === 0 && data.incidentCount === 0) {
      return 0.0; // No occurrences, no flights - score is 0 (good)
    } else {
      return 1.0; // Occurrences exist with zero flight cycles - high penalty (bad D(p) score)
    }
  }
  const weightedDeviations = 
    (data.accidentCount * RBS_DEVIATION_CATEGORY_WEIGHTS.accident) +
    (data.seriousIncidentCount * RBS_DEVIATION_CATEGORY_WEIGHTS.seriousIncident) +
    (data.incidentCount * RBS_DEVIATION_CATEGORY_WEIGHTS.incident);
  
  const score = weightedDeviations / data.totalFlightCycles;
  return Math.max(0, score); // Score is per 10k cycles, higher is worse
};

// 4. Calculate Improvement Factor I(p) (Slide 21)
export const calculateImprovementFactorScore = (data: ImprovementData): number => {
  const Nf = data.totalFindingsNf; // Total number of surveillance findings
  const Nd = data.totalDeviationsNd; // Total number of mandatory occurrences

  if (Nf + Nd === 0) return 1; // Perfect improvement if nothing to improve (no findings, no deviations)
  
  const Nn1 = data.correctiveActionsRootCause;       
  const Nn2 = data.correctiveActionsHazardIdentified;  
  const Nn3 = data.correctiveActionsRiskAssessed;    
  const Nn4 = data.correctiveActionsRiskMitigated;   

  const sumWeightedEffectiveness = 
    (Nn1 * RBS_CORRECTIVE_ACTION_WEIGHTS.rootCause) +
    (Nn2 * RBS_CORRECTIVE_ACTION_WEIGHTS.hazardIdentified) +
    (Nn3 * RBS_CORRECTIVE_ACTION_WEIGHTS.riskAssessed) +
    (Nn4 * RBS_CORRECTIVE_ACTION_WEIGHTS.riskMitigated);
  
  const totalRelevantIssues = Nd + Nf;

  if (totalRelevantIssues === 0) return 1.0; 
  
  return Math.min(1, Math.max(0, sumWeightedEffectiveness / totalRelevantIssues));
};


// 5. Calculate Overall Performance Score F(P) (Slide 17)
export const calculateOverallPerformanceScore = (
  cp: number, 
  dp: number, 
  ip: number  
): number => {
  // Note: Higher dp is worse, so we subtract it.
  // Higher cp and ip are better.
  const performanceScore = (RBS_WEIGHT_COMPLIANCE * cp) - 
                           (RBS_WEIGHT_DEVIATION * dp) + // dp itself is already the calculated deviation "rate"
                           (RBS_WEIGHT_IMPROVEMENT * ip);
  return Math.max(0, Math.min(1, performanceScore)); // Clamp to 0-1 range
};

// 6. Map F(P) to Risk Indicator Level (IDR 1-5) (Slide 29)
export const getRiskIndicatorLevel = (performanceScore: number): { level: number, label: string } => {
  if (isNaN(performanceScore)) {
    return { level: 5, label: "Data Error ORP" }; // Highest risk if performance score is NaN
  }
  const scorePercent = performanceScore * 100;
  for (const range of RBS_PERFORMANCE_TO_INDICATOR_LEVEL) { 
    if (scorePercent <= range.thresholdMax) { 
      const lowerBoundEntry = RBS_PERFORMANCE_TO_INDICATOR_LEVEL.find(r => r.level === range.level + 1);
      // For level 5, lowerBound will be -Infinity (correct)
      // For level 1, lowerBoundEntry will be undefined, thus lowerBound will be -Infinity. This is incorrect.
      // The logic should be: find first range where scorePercent <= thresholdMax
      // However, the RBS_PERFORMANCE_TO_INDICATOR_LEVEL is sorted by thresholdMax ASC, so first match is correct.
      // Example: scorePercent = 30. First match: { thresholdMax: 35, level: 5, label: "Very High ORP" } -> Correct.
      // Example: scorePercent = 50. First match: { thresholdMax: 60, level: 4, label: "High ORP" } -> Correct.
      // Example: scorePercent = 90. First match: { thresholdMax: Infinity, level: 1, label: "Very Low ORP" } -> Correct.

      // The original complex logic with lowerBound was not strictly necessary given the array structure.
      // Simpler: First entry where scorePercent <= thresholdMax is the correct one.
      return { level: range.level, label: range.label };
    }
  }
  // This fallback should ideally not be reached if RBS_PERFORMANCE_TO_INDICATOR_LEVEL covers up to Infinity.
  const highestLevelEntry = RBS_PERFORMANCE_TO_INDICATOR_LEVEL[RBS_PERFORMANCE_TO_INDICATOR_LEVEL.length -1];
   return { level: highestLevelEntry.level, label: highestLevelEntry.label }; // Fallback to the last defined level
};


// 7. Determine Final Risk Category Key and Surveillance Cycle (Slide 26/31 Matrix)
export const getSurveillanceCycle = (
  exposureLevel: ExposureLevel, 
  riskIndicatorLevel: number 
): { cycleMonths: number, categoryKey: string } => {
  const matrixRow = RBS_MATRIX_CELL_KEYS[exposureLevel];
  if (!matrixRow) return { cycleMonths: 12, categoryKey: "N/A" }; 

  const categoryKey = matrixRow[riskIndicatorLevel];
  if (!categoryKey) return { cycleMonths: 12, categoryKey: "N/A" };

  const cycleMonths = RBS_MATRIX_SURVEILLANCE_CYCLES[categoryKey] || 12; 
  return { cycleMonths, categoryKey };
};


// Main function to update all RBS calculations for an operator
export const calculateAllRbsMetrics = (operator: Operator): Partial<Operator> => {
  const occurrences = operator.legacyRiskFactors.occurrences || [];
  const derivedAccidentCount = occurrences.filter(o => o.type === OccurrenceType.ACCIDENT).length;
  const derivedSeriousIncidentCount = occurrences.filter(o => o.type === OccurrenceType.SERIOUS_INCIDENT).length;
  const derivedIncidentCount = occurrences.filter(o => 
    o.type === OccurrenceType.INCIDENT ||
    o.type === OccurrenceType.SAFETY_REPORT ||
    o.type === OccurrenceType.SDR ||
    o.type === OccurrenceType.OTHER
  ).length;

  const currentDeviationData: DeviationData = {
    ...operator.deviationData,
    accidentCount: derivedAccidentCount,
    seriousIncidentCount: derivedSeriousIncidentCount,
    incidentCount: derivedIncidentCount,
  };

  const surveillanceFindings = operator.surveillanceFindings || [];
  const derivedTotalDeviationsNd = occurrences.length;
  const derivedTotalFindingsNf = surveillanceFindings.length;
  
  let derivedCorrectiveActionsRootCause = 0;
  let derivedCorrectiveActionsHazardIdentified = 0;
  let derivedCorrectiveActionsRiskAssessed = 0;
  let derivedCorrectiveActionsRiskMitigated = 0;

  surveillanceFindings.forEach(sf => {
    if (sf.isCompleted && sf.correctiveActionTaken && sf.correctiveActionTaken.trim() !== '') {
        derivedCorrectiveActionsRiskMitigated++;
    } else if (sf.riskAssessment && sf.riskAssessment.trim() !== '') {
        derivedCorrectiveActionsRiskAssessed++;
    } else if (sf.correctiveActionPlan && sf.correctiveActionPlan.trim() !== '') {
        derivedCorrectiveActionsHazardIdentified++;
    } else if (sf.rootCauseAnalysis && sf.rootCauseAnalysis.trim() !== '') {
        derivedCorrectiveActionsRootCause++;
    }
  });


  const currentImprovementData: ImprovementData = {
    ...operator.improvementData, 
    totalDeviationsNd: derivedTotalDeviationsNd,
    totalFindingsNf: derivedTotalFindingsNf,
    correctiveActionsRootCause: derivedCorrectiveActionsRootCause,
    correctiveActionsHazardIdentified: derivedCorrectiveActionsHazardIdentified,
    correctiveActionsRiskAssessed: derivedCorrectiveActionsRiskAssessed,
    correctiveActionsRiskMitigated: derivedCorrectiveActionsRiskMitigated,
  };

  const exposure = calculateExposureProfile(operator.complexityFactors);
  const cp = calculateComplianceFactorScore(operator.complianceData, operator.surveillanceFindings);
  const dp = calculateDeviationFactorScore(currentDeviationData); 
  const ip = calculateImprovementFactorScore(currentImprovementData);
  
  const overallPerformanceScore = calculateOverallPerformanceScore(cp, dp, ip);
  const riskIndicator = getRiskIndicatorLevel(overallPerformanceScore);
  const surveillance = getSurveillanceCycle(exposure.level, riskIndicator.level);

  return {
    exposureScore: exposure.score,
    exposureLevel: exposure.level,
    complianceFactorScore: cp,
    deviationFactorScore: dp, 
    improvementFactorScore: ip,
    overallPerformanceScore: overallPerformanceScore,
    riskIndicatorLevel: riskIndicator.level,
    finalRiskCategoryKey: surveillance.categoryKey,
    suggestedSurveillanceCycleMonths: surveillance.cycleMonths,
    deviationData: currentDeviationData,
    improvementData: currentImprovementData,
  };
};