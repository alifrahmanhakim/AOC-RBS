
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ChartBarIcon, PlaneIcon, UserCircleIcon } from '../icons'; // Added UserCircleIcon
import { useAuth } from '../../contexts/AuthContext';
import { LoadingSpinner } from './LoadingSpinner';

export const Header: React.FC = () => {
  const { currentUser, isAuthLoading, authError, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login'); // Redirect to login page after logout
  };

  return (
    <header className="bg-brand-primary shadow-lg">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center text-white hover:text-brand-secondary transition-colors">
            <PlaneIcon className="h-8 w-8 mr-3" />
            <h1 className="text-xl sm:text-2xl font-bold">AOC Risk Management</h1>
          </Link>
          <nav className="flex space-x-4 items-center">
            {currentUser && (
              <Link
                to="/"
                className="text-slate-300 hover:bg-brand-secondary hover:text-white px-3 py-2 rounded-md text-sm font-medium transition-colors flex items-center"
              >
                <ChartBarIcon className="h-5 w-5 mr-1" />
                Dashboard
              </Link>
            )}
            
            <div className="flex items-center">
              {isAuthLoading && <LoadingSpinner size="sm" />}
              {authError && !isAuthLoading && <span className="text-xs text-red-300" title={authError}>Auth Error</span>}
              
              {!isAuthLoading && !authError && currentUser && (
                <div className="flex items-center space-x-2">
                  <UserCircleIcon className="h-7 w-7 text-slate-300" />
                  <div className="text-xs text-slate-300 hidden sm:block">
                    <div>{currentUser.displayName}</div>
                    <div className="font-semibold">{currentUser.role}</div>
                  </div>
                  <button
                    onClick={handleLogout}
                    className="text-slate-300 hover:bg-red-600 hover:text-white px-2.5 py-1.5 rounded-md text-sm font-medium transition-colors"
                  >
                    Logout
                  </button>
                </div>
              )}
              {/* If no user and no error/loading, it implies they should be on login page or redirected there */}
            </div>
          </nav>
        </div>
      </div>
    </header>
  );
};
