
import React, { useState, useEffect } from 'react';
import { Modal } from '../shared/Modal';
import { PredefinedSurveillanceArea, SurveillanceFinding, FindingCategoryLevel, SurveillanceLogCategory } from '../../types';
import { FINDING_CATEGORY_OPTIONS, PREDEFINED_SURVEILLANCE_AREAS } from '../../constants';
import toast from 'react-hot-toast';

interface SurveillanceFindingFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  operatorId: string;
  addSurveillanceFinding: (operatorId: string, findingData: Omit<SurveillanceFinding, 'id' | 'isCompleted' | 'dateAdded' | 'actualCompletionDate' | 'targetCompletionDate'>) => void;
  updateSurveillanceFinding: (operatorId: string, findingId: string, updatedData: Partial<Omit<SurveillanceFinding, 'id' | 'dateAdded' | 'actualCompletionDate' | 'targetCompletionDate'> & { isCompleted?: boolean }>) => void;
  areaForNewFinding?: PredefinedSurveillanceArea;
  findingToEdit?: SurveillanceFinding;
}

const getInitialState = (areaForNewFinding?: PredefinedSurveillanceArea, findingToEdit?: SurveillanceFinding) => {
    if (findingToEdit) {
        return {
            surveillanceLogCategoryId: findingToEdit.surveillanceLogCategoryId,
            predefinedAreaId: findingToEdit.predefinedAreaId,
            finding: findingToEdit.finding,
            findingCategory: findingToEdit.findingCategory,
            rootCauseAnalysis: findingToEdit.rootCauseAnalysis || '',
            correctiveActionPlan: findingToEdit.correctiveActionPlan || '',
            riskAssessment: findingToEdit.riskAssessment || '',
            correctiveActionTaken: findingToEdit.correctiveActionTaken || '',
            isCompleted: findingToEdit.isCompleted,
        };
    }
    if (areaForNewFinding) {
        return {
            surveillanceLogCategoryId: areaForNewFinding.category,
            predefinedAreaId: areaForNewFinding.id,
            finding: '',
            findingCategory: FindingCategoryLevel.LEVEL_3,
            rootCauseAnalysis: '',
            correctiveActionPlan: '',
            riskAssessment: '',
            correctiveActionTaken: '',
            isCompleted: false,
        };
    }
    // Fallback for adding a finding without pre-selected area (less common now but good practice)
    return {
        surveillanceLogCategoryId: undefined as SurveillanceLogCategory | undefined,
        predefinedAreaId: undefined as string | undefined,
        finding: '',
        findingCategory: FindingCategoryLevel.LEVEL_3,
        rootCauseAnalysis: '',
        correctiveActionPlan: '',
        riskAssessment: '',
        correctiveActionTaken: '',
        isCompleted: false,
    };
};

export const SurveillanceFindingFormModal: React.FC<SurveillanceFindingFormModalProps> = ({
  isOpen,
  onClose,
  operatorId,
  addSurveillanceFinding,
  updateSurveillanceFinding,
  areaForNewFinding,
  findingToEdit,
}) => {
  const [formData, setFormData] = useState(() => getInitialState(areaForNewFinding, findingToEdit));
  const isEditMode = !!findingToEdit;
  
  const [availableAreas, setAvailableAreas] = useState<PredefinedSurveillanceArea[]>([]);

  useEffect(() => {
    setFormData(getInitialState(areaForNewFinding, findingToEdit));
  }, [isOpen, areaForNewFinding, findingToEdit]);

  useEffect(() => {
      if(formData.surveillanceLogCategoryId){
          setAvailableAreas(PREDEFINED_SURVEILLANCE_AREAS.filter(a => a.category === formData.surveillanceLogCategoryId))
      } else {
          setAvailableAreas([]);
      }
  }, [formData.surveillanceLogCategoryId])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    const isCheckbox = type === 'checkbox';

    setFormData(prev => ({
      ...prev,
      [name]: isCheckbox ? (e.target as HTMLInputElement).checked : value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.finding.trim() || !formData.findingCategory || !formData.predefinedAreaId) {
        toast.error("Area, Finding Description, and Finding Level are required.");
        return;
    }
    
    const areaDetails = PREDEFINED_SURVEILLANCE_AREAS.find(a => a.id === formData.predefinedAreaId);

    const dataToSubmit = {
        ...formData,
        itemNumber: areaDetails?.itemNumber,
        areaDescription: areaDetails?.areaDescription,
    };

    if (isEditMode) {
      updateSurveillanceFinding(operatorId, findingToEdit.id, dataToSubmit);
    } else {
      const { isCompleted, ...addData } = dataToSubmit;
      addSurveillanceFinding(operatorId, addData);
    }
    onClose();
  };
  
  const selectedAreaDetails = PREDEFINED_SURVEILLANCE_AREAS.find(a => a.id === formData.predefinedAreaId);

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={isEditMode ? 'Edit Surveillance Finding' : 'Add New Surveillance Finding'}
      size="lg"
    >
      <form onSubmit={handleSubmit} className="space-y-4 text-sm">
        
        {/* Section 1: Finding Identification */}
        <fieldset className="p-3 border border-slate-200 rounded-md">
            <legend className="px-2 text-xs font-semibold text-slate-600">Finding Identification</legend>
            <div className="space-y-3">
                <div className="bg-slate-50 p-2 rounded-md">
                    <p className="font-medium text-slate-800">{selectedAreaDetails?.category}</p>
                    <p className="text-xs text-slate-600">
                        {selectedAreaDetails?.itemNumber} - {selectedAreaDetails?.areaDescription}
                    </p>
                </div>
                <div>
                    <label htmlFor="finding" className="block font-medium text-slate-700">Finding Description <span className="text-red-500">*</span></label>
                    <textarea id="finding" name="finding" value={formData.finding} onChange={handleInputChange} required rows={3} className="w-full mt-1 p-1.5 border border-slate-300 rounded" />
                </div>
                <div>
                    <label htmlFor="findingCategory" className="block font-medium text-slate-700">Finding Level <span className="text-red-500">*</span></label>
                    <select id="findingCategory" name="findingCategory" value={formData.findingCategory} onChange={handleInputChange} required className="w-full mt-1 p-1.5 border border-slate-300 rounded bg-white">
                        {FINDING_CATEGORY_OPTIONS.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
                    </select>
                </div>
            </div>
        </fieldset>

        {/* Section 2: Analysis & Actions */}
        <fieldset className="p-3 border border-slate-200 rounded-md">
            <legend className="px-2 text-xs font-semibold text-slate-600">Analysis & Corrective Actions</legend>
            <div className="space-y-3">
                <div>
                    <label htmlFor="rootCauseAnalysis" className="block font-medium text-slate-700">Root Cause Analysis (RCA)</label>
                    <textarea id="rootCauseAnalysis" name="rootCauseAnalysis" value={formData.rootCauseAnalysis} onChange={handleInputChange} rows={3} className="w-full mt-1 p-1.5 border border-slate-300 rounded" />
                </div>
                <div>
                    <label htmlFor="correctiveActionPlan" className="block font-medium text-slate-700">Hazard Identification / Corrective Action Plan (CAP)</label>
                    <textarea id="correctiveActionPlan" name="correctiveActionPlan" value={formData.correctiveActionPlan} onChange={handleInputChange} rows={3} className="w-full mt-1 p-1.5 border border-slate-300 rounded" />
                </div>
                <div>
                    <label htmlFor="riskAssessment" className="block font-medium text-slate-700">Risk Assessment</label>
                    <textarea id="riskAssessment" name="riskAssessment" value={formData.riskAssessment} onChange={handleInputChange} rows={3} className="w-full mt-1 p-1.5 border border-slate-300 rounded" />
                </div>
                <div>
                    <label htmlFor="correctiveActionTaken" className="block font-medium text-slate-700">Mitigation Action / Corrective Action Taken</label>
                    <textarea id="correctiveActionTaken" name="correctiveActionTaken" value={formData.correctiveActionTaken} onChange={handleInputChange} rows={3} className="w-full mt-1 p-1.5 border border-slate-300 rounded" />
                    <p className="text-xs text-slate-500 mt-1">Note: This is required for 'Risk Mitigated' credit in the I(p) score.</p>
                </div>
            </div>
        </fieldset>
        
        {isEditMode && (
          <div className="flex items-center p-3 border border-slate-200 rounded-md">
            <input
                id="isCompleted"
                name="isCompleted"
                type="checkbox"
                checked={formData.isCompleted}
                onChange={handleInputChange}
                className="h-4 w-4 rounded border-gray-300 text-brand-primary focus:ring-brand-secondary"
            />
            <label htmlFor="isCompleted" className="ml-2 block text-sm font-medium text-gray-900">Mark as Completed</label>
          </div>
        )}

        <div className="flex justify-end space-x-3 pt-3">
          <button type="button" onClick={onClose} className="px-4 py-2 border rounded-md shadow-sm hover:bg-slate-50">Cancel</button>
          <button type="submit" className="px-4 py-2 bg-brand-primary text-white rounded-md shadow-sm hover:bg-blue-800">{isEditMode ? 'Update Finding' : 'Add Finding'}</button>
        </div>
      </form>
    </Modal>
  );
};
