
import React, { useState, useEffect } from 'react';
import { Modal } from '../shared/Modal';
import { SurveillanceLogItem, PredefinedSurveillanceArea, SurveillanceLogStatus } from '../../types';
import toast from 'react-hot-toast';

interface SurveillanceLogModalProps {
  isOpen: boolean;
  onClose: () => void;
  operatorId: string;
  predefinedArea: PredefinedSurveillanceArea;
  currentLogItem: SurveillanceLogItem | null;
  upsertLogItem: (operatorId: string, predefinedAreaId: string, status: SurveillanceLogStatus, notes?: string) => void;
}

const getDefaultFormState = (currentLogItem: SurveillanceLogItem | null): { status: SurveillanceLogStatus; notes: string } => {
  if (currentLogItem) {
    return {
      status: currentLogItem.status,
      notes: currentLogItem.notes || '',
    };
  }
  return {
    status: 'Not Done', // Default to Not Done when adding new
    notes: '',
  };
};

export const SurveillanceLogModal: React.FC<SurveillanceLogModalProps> = ({
  isOpen,
  onClose,
  operatorId,
  predefinedArea,
  currentLogItem,
  upsertLogItem,
}) => {
  const [formData, setFormData] = useState(getDefaultFormState(currentLogItem));

  useEffect(() => {
    if (isOpen) {
      setFormData(getDefaultFormState(currentLogItem));
    }
  }, [currentLogItem, isOpen]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    upsertLogItem(operatorId, predefinedArea.id, formData.status, formData.notes);
    onClose();
  };

  return (
    <Modal 
        isOpen={isOpen} 
        onClose={onClose} 
        title={`Update Log: ${predefinedArea.itemNumber} - ${predefinedArea.areaDescription.substring(0,50)}${predefinedArea.areaDescription.length > 50 ? '...' : ''}`}
        size="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4 text-sm">
        <div>
            <p className="text-xs text-slate-600 mb-1">
                <strong>Area:</strong> {predefinedArea.itemNumber} - {predefinedArea.areaDescription}
            </p>
            {predefinedArea.defaultFormNumber && (
                <p className="text-xs text-slate-500 mb-2">
                    <strong>Formulir:</strong> {predefinedArea.defaultFormNumber}
                </p>
            )}
        </div>
        
        <div>
          <label htmlFor="status" className="block text-xs font-medium text-slate-700">Status</label>
          <select
            name="status"
            id="status"
            value={formData.status}
            onChange={handleInputChange}
            required
            className="w-full p-1.5 border border-slate-300 rounded-md shadow-sm text-xs bg-white"
          >
            <option value="Not Done">Not Done</option>
            <option value="On Going">On Going</option>
            <option value="Done">Done</option>
          </select>
        </div>
        
        <div>
          <label htmlFor="notes" className="block text-xs font-medium text-slate-700">Notes</label>
          <textarea 
            name="notes" 
            id="notes" 
            value={formData.notes} 
            onChange={handleInputChange} 
            rows={4} 
            className="w-full p-1.5 border border-slate-300 rounded-md shadow-sm text-xs" 
            placeholder="Optional notes regarding this surveillance area's status"
          />
        </div>

        <div className="flex justify-end space-x-3 pt-3">
          <button type="button" onClick={onClose} className="px-4 py-2 border border-slate-300 rounded-md shadow-sm hover:bg-slate-50 text-slate-700 text-xs">Cancel</button>
          <button type="submit" className="px-4 py-2 bg-brand-primary text-white rounded-md shadow-sm hover:bg-blue-700 text-xs">Save Status</button>
        </div>
      </form>
    </Modal>
  );
};