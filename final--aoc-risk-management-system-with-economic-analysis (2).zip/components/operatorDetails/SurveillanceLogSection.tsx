
import React, { useState, useMemo } from 'react';
import { Operator, SurveillanceLogCategory, SurveillanceLogItem, PredefinedSurveillanceArea, SurveillanceLogStatus, UserRole, SurveillanceFinding, FindingCategoryLevel } from '../../types';
import { PlusIcon, PencilIcon, TrashIcon, ListBulletIcon, ChevronDownIcon, ChevronUpIcon, CheckCircleIcon, XCircleIcon, LayersIcon, ExclamationTriangleIcon } from '../icons';
import { SurveillanceLogModal } from './SurveillanceLogModal';
import { SurveillanceBatchUpdateModal } from './SurveillanceBatchUpdateModal';
import { PREDEFINED_SURVEILLANCE_AREAS } from '../../constants';
import { useAuth } from '../../contexts/AuthContext';

interface SurveillanceLogSectionProps {
  operator: Operator;
  upsertLogItem: (operatorId: string, predefinedAreaId: string, status: SurveillanceLogStatus, notes?: string) => void;
  deleteSurveillanceLogItem: (operatorId: string, predefinedAreaId: string) => void;
  onOpenFindingModal: (config: { area?: PredefinedSurveillanceArea; finding?: SurveillanceFinding }) => void;
  deleteSurveillanceFinding: (operatorId: string, findingId: string) => void;
  toggleSurveillanceFindingCompletion: (operatorId: string, findingId: string) => void;
}

const initialExpandedCategoriesState = (): Record<SurveillanceLogCategory, boolean> => {
  const initialState: Partial<Record<SurveillanceLogCategory, boolean>> = {};
  for (const category in SurveillanceLogCategory) {
    if (isNaN(Number(category))) { 
      initialState[category as SurveillanceLogCategory] = true; // Default to expanded
    }
  }
  return initialState as Record<SurveillanceLogCategory, boolean>;
};

export const SurveillanceLogSection: React.FC<SurveillanceLogSectionProps> = ({
  operator,
  upsertLogItem,
  deleteSurveillanceLogItem,
  onOpenFindingModal,
  deleteSurveillanceFinding,
  toggleSurveillanceFindingCompletion,
}) => {
  const [isLogStatusModalOpen, setIsLogStatusModalOpen] = useState(false);
  const [editingPredefinedAreaForLog, setEditingPredefinedAreaForLog] = useState<PredefinedSurveillanceArea | null>(null);
  const [currentLogForItem, setCurrentLogForItem] = useState<SurveillanceLogItem | null>(null);
  
  const [showOverallSection, setShowOverallSection] = useState(true);
  const [expandedCategories, setExpandedCategories] = useState<Record<SurveillanceLogCategory, boolean>>(initialExpandedCategoriesState());

  const { currentUser } = useAuth();
  const isAdmin = currentUser?.role === UserRole.ADMIN;

  const [selectedAreaIds, setSelectedAreaIds] = useState<string[]>([]);
  const [isBatchModalOpen, setIsBatchModalOpen] = useState(false);

  const handleOpenLogStatusModal = (area: PredefinedSurveillanceArea) => {
    if (!isAdmin) return;
    setEditingPredefinedAreaForLog(area);
    const existingLog = operator.surveillanceLogs?.find(log => log.predefinedAreaId === area.id) || null;
    setCurrentLogForItem(existingLog);
    setIsLogStatusModalOpen(true);
  };
  
  const handleDeleteLog = (predefinedAreaId: string) => {
    if (!isAdmin) return;
    if (window.confirm('Are you sure you want to clear the log for this area? This will mark it as Not Done if no open findings exist, or clear its current "Done" status.')) {
      deleteSurveillanceLogItem(operator.id, predefinedAreaId);
    }
  };

  const getStatusDisplay = (predefinedArea: PredefinedSurveillanceArea): { text: string; colorClass: string; icon: JSX.Element } => {
    const logItem = operator.surveillanceLogs?.find(log => log.predefinedAreaId === predefinedArea.id);
    if (logItem) {
      if (logItem.status === 'Done') {
        return { text: 'Done', colorClass: 'bg-green-100 text-green-700', icon: <CheckCircleIcon className="h-3 w-3 mr-1" /> };
      }
      if (logItem.status === 'On Going') {
        return { text: 'On Going', colorClass: 'bg-yellow-100 text-yellow-800', icon: <ExclamationTriangleIcon className="h-3 w-3 mr-1" /> };
      }
      return { text: 'Not Done', colorClass: 'bg-red-100 text-red-700', icon: <XCircleIcon className="h-3 w-3 mr-1" /> };
    }
    return { text: 'N/A', colorClass: 'bg-slate-100 text-slate-500', icon: <ListBulletIcon className="h-3 w-3 mr-1 text-slate-400" /> };
  };

  const toggleCategoryExpansion = (category: SurveillanceLogCategory) => {
    setExpandedCategories(prev => ({ ...prev, [category]: !prev[category] }));
  };

  const handleSelectArea = (areaId: string) => {
    setSelectedAreaIds(prevSelected =>
      prevSelected.includes(areaId)
        ? prevSelected.filter(id => id !== areaId)
        : [...prevSelected, areaId]
    );
  };
  
  const handleDeselectAll = () => setSelectedAreaIds([]);

  const selectedPredefinedAreasForBatch = useMemo(() => {
    return PREDEFINED_SURVEILLANCE_AREAS.filter(area => selectedAreaIds.includes(area.id));
  }, [selectedAreaIds]);

  return (
    <div className="bg-white shadow-xl rounded-xl p-6">
      <button
        onClick={() => setShowOverallSection(!showOverallSection)}
        className="w-full flex justify-between items-center text-left text-xl font-semibold text-slate-700 mb-2 focus:outline-none"
        aria-expanded={showOverallSection}
        aria-controls="surveillance-log-content"
      >
        <div className="flex items-center">
            <ListBulletIcon className="h-6 w-6 mr-2 text-brand-primary" />
            Surveillance Program & Findings
        </div>
        {showOverallSection ? <ChevronUpIcon className="h-5 w-5 text-slate-500" /> : <ChevronDownIcon className="h-5 w-5 text-slate-500" /> }
      </button>

      {showOverallSection && (
        <div id="surveillance-log-content">
          {isAdmin && selectedAreaIds.length > 0 && (
            <div className="my-3 p-3 bg-sky-50 border border-sky-200 rounded-lg flex flex-col sm:flex-row justify-between items-center space-y-2 sm:space-y-0 sm:space-x-3">
              <span className="text-sm font-medium text-sky-700">{selectedAreaIds.length} area(s) selected</span>
              <div className="flex space-x-2">
                <button
                  onClick={() => setIsBatchModalOpen(true)}
                  className="text-xs bg-sky-600 hover:bg-sky-700 text-white font-semibold py-1.5 px-3 rounded-md shadow-sm flex items-center"
                >
                  <LayersIcon className="h-3.5 w-3.5 mr-1" /> Batch Update Status
                </button>
                <button
                  onClick={handleDeselectAll}
                  className="text-xs bg-slate-200 hover:bg-slate-300 text-slate-700 font-medium py-1.5 px-3 rounded-md shadow-sm"
                >
                  Deselect All
                </button>
              </div>
            </div>
          )}

          <div className="space-y-4">
            {Object.values(SurveillanceLogCategory).map(category => {
              const isCategoryExpanded = expandedCategories[category] || false;
              const areasInCategory = PREDEFINED_SURVEILLANCE_AREAS.filter(area => area.category === category)
                .sort((a,b) => a.itemNumber.localeCompare(b.itemNumber, undefined, { numeric: true, sensitivity: 'base'}));

              if (areasInCategory.length === 0) return null;

              return (
                  <div key={category} className="border border-slate-200 rounded-lg">
                      <button
                          onClick={() => toggleCategoryExpansion(category)}
                          className="w-full flex justify-between items-center text-left font-semibold text-slate-600 p-3 bg-slate-50 hover:bg-slate-100 focus:outline-none rounded-t-lg"
                      >
                          <span>{category}</span>
                          {isCategoryExpanded ? <ChevronUpIcon className="h-4 w-4 text-slate-500" /> : <ChevronDownIcon className="h-4 w-4 text-slate-500" /> }
                      </button>
                      {isCategoryExpanded && (
                          <div className="p-3 space-y-2">
                              {areasInCategory.map(predefinedArea => {
                                  const logItem = operator.surveillanceLogs?.find(log => log.predefinedAreaId === predefinedArea.id);
                                  const statusDisplay = getStatusDisplay(predefinedArea);
                                  const isSelected = selectedAreaIds.includes(predefinedArea.id);
                                  const findingsForThisArea = operator.surveillanceFindings?.filter(f => f.predefinedAreaId === predefinedArea.id) || [];
                                  
                                  return (
                                    <div key={predefinedArea.id} className={`py-2 border-b border-slate-100 last:border-b-0 -mx-3 px-3 rounded-sm ${isSelected ? 'bg-sky-50' : ''}`}>
                                        <div className="flex flex-col sm:flex-row justify-between items-start">
                                            <div className="flex-grow mb-1 sm:mb-0 flex items-start">
                                                {isAdmin && (
                                                    <input
                                                        type="checkbox"
                                                        checked={isSelected}
                                                        onChange={() => handleSelectArea(predefinedArea.id)}
                                                        className="mr-2.5 mt-1 h-3.5 w-3.5 text-sky-600 border-slate-300 rounded focus:ring-sky-500"
                                                    />
                                                )}
                                                <div>
                                                    <span className="font-semibold text-xs text-slate-700 mr-2">{predefinedArea.itemNumber}</span>
                                                    <span className="text-xs text-slate-800">{predefinedArea.areaDescription}</span>
                                                </div>
                                            </div>
                                            {isAdmin && (
                                                <div className="flex-shrink-0 flex items-center space-x-2 self-start sm:self-center ml-auto pl-2">
                                                    <button onClick={() => handleOpenLogStatusModal(predefinedArea)} className="text-xs bg-slate-200 hover:bg-slate-300 text-slate-700 font-medium py-1 px-2.5 rounded-md flex items-center shadow-sm"><PencilIcon className="h-3 w-3 mr-1" /> Status</button>
                                                    <button onClick={() => onOpenFindingModal({ area: predefinedArea })} className="text-xs bg-teal-500 hover:bg-teal-600 text-white font-medium py-1 px-2.5 rounded-md flex items-center shadow-sm"><PlusIcon className="h-3 w-3 mr-1" /> Add Finding</button>
                                                </div>
                                            )}
                                        </div>
                                        <div className={`mt-1 flex flex-col sm:flex-row sm:items-center sm:space-x-4 text-xs ${isAdmin ? 'ml-6' : ''}`}>
                                            <span className={`inline-flex items-center px-1.5 py-0.5 rounded-full text-[10px] font-medium ${statusDisplay.colorClass}`}>{statusDisplay.icon} {statusDisplay.text}</span>
                                            {logItem?.lastUpdated && <span className="text-slate-500 text-[10px]">Updated: {new Date(logItem.lastUpdated).toLocaleDateString()}</span>}
                                        </div>

                                        {findingsForThisArea.length > 0 && (
                                            <div className={`mt-2 space-y-2 ${isAdmin ? 'ml-6' : ''}`}>
                                            {findingsForThisArea.sort((a,b) => new Date(b.dateAdded).getTime() - new Date(a.dateAdded).getTime()).map(finding => {
                                                 const isOverdue = !finding.isCompleted && new Date(finding.targetCompletionDate) < new Date();
                                                return(
                                                <div key={finding.id} className="p-2 border border-slate-200 bg-white rounded-md shadow-sm">
                                                    <div className="flex justify-between items-start">
                                                        <p className="text-xs text-slate-800 pr-2"><strong className="font-semibold">Finding:</strong> {finding.finding}</p>
                                                        {isAdmin && <div className="flex-shrink-0 flex space-x-1">
                                                            <button onClick={() => onOpenFindingModal({ finding })} className="text-brand-secondary hover:text-sky-700 p-0.5" title="Edit"><PencilIcon className="h-3.5 w-3.5"/></button>
                                                            <button onClick={() => deleteSurveillanceFinding(operator.id, finding.id)} className="text-red-500 hover:text-red-700 p-0.5" title="Delete"><TrashIcon className="h-3.5 w-3.5"/></button>
                                                        </div>}
                                                    </div>
                                                    <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-[10px] text-slate-600">
                                                        <span><strong>Level:</strong> {finding.findingCategory.split(' ')[1]}</span>
                                                        <span className={`${isOverdue ? 'text-red-600 font-semibold' : ''}`}><strong>Target:</strong> {new Date(finding.targetCompletionDate).toLocaleDateString()}</span>
                                                        <span>
                                                            {finding.isCompleted ? 
                                                                <span className="inline-flex items-center text-green-700"><CheckCircleIcon className="h-3 w-3 mr-1"/>Completed {finding.actualCompletionDate && `(${new Date(finding.actualCompletionDate).toLocaleDateString()})`}</span> :
                                                                <span className="inline-flex items-center text-yellow-700"><XCircleIcon className="h-3 w-3 mr-1"/>Open</span>
                                                            }
                                                        </span>
                                                         {!finding.isCompleted && isAdmin && (
                                                            <button onClick={() => toggleSurveillanceFindingCompletion(operator.id, finding.id)} className="text-green-600 hover:text-green-800 font-semibold flex items-center"><CheckCircleIcon className="h-3 w-3 mr-1"/> Mark Complete</button>
                                                        )}
                                                    </div>
                                                </div>
                                            )})}
                                            </div>
                                        )}
                                    </div>
                                  );
                              })}
                          </div>
                      )}
                  </div>
              );
            })}
          </div>
        </div>
      )}

      {isAdmin && isLogStatusModalOpen && editingPredefinedAreaForLog && (
        <SurveillanceLogModal
          isOpen={isLogStatusModalOpen}
          onClose={() => setIsLogStatusModalOpen(false)}
          operatorId={operator.id}
          predefinedArea={editingPredefinedAreaForLog}
          currentLogItem={currentLogForItem}
          upsertLogItem={upsertLogItem}
        />
      )}

      {isAdmin && isBatchModalOpen && (
        <SurveillanceBatchUpdateModal
          isOpen={isBatchModalOpen}
          onClose={() => setIsBatchModalOpen(false)}
          operatorId={operator.id}
          selectedPredefinedAreas={selectedPredefinedAreasForBatch}
          upsertLogItem={upsertLogItem}
        />
      )}
    </div>
  );
};