
import React from 'react';
import { Modal } from '../shared/Modal';
import { SurveillanceFinding } from '../../types';
import { PREDEFINED_SURVEILLANCE_AREAS } from '../../constants';
import { CheckCircleIcon, XCircleIcon } from '../icons';

interface FindingsDisplayModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  findings: SurveillanceFinding[];
}

export const FindingsDisplayModal: React.FC<FindingsDisplayModalProps> = ({ isOpen, onClose, title, findings }) => {
  const sortedFindings = [...findings].sort((a, b) => new Date(b.dateAdded).getTime() - new Date(a.dateAdded).getTime());

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={title} size="xl">
      <div className="max-h-[70vh] overflow-y-auto pr-2">
        {sortedFindings.length > 0 ? (
          <div className="space-y-4">
            {sortedFindings.map(finding => {
              const area = PREDEFINED_SURVEILLANCE_AREAS.find(a => a.id === finding.predefinedAreaId);
              const isOverdue = !finding.isCompleted && new Date(finding.targetCompletionDate) < new Date();

              return (
                <div key={finding.id} className="p-3 border border-slate-200 rounded-lg bg-white shadow-sm text-sm">
                  {/* Header */}
                  <div className="pb-2 mb-2 border-b border-slate-200">
                    <p className="font-semibold text-slate-700">
                      Area: {area?.itemNumber} - {area?.areaDescription}
                    </p>
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-600 mt-1">
                      <span><strong>Level:</strong> {finding.findingCategory.split(' ')[1]}</span>
                      <span className={`${isOverdue ? 'text-red-600 font-semibold' : ''}`}>
                        <strong>Target:</strong> {new Date(finding.targetCompletionDate).toLocaleDateString()}
                      </span>
                      <span>
                        {finding.isCompleted ? (
                          <span className="inline-flex items-center text-green-700">
                            <CheckCircleIcon className="h-3 w-3 mr-1" />
                            Completed {finding.actualCompletionDate && `(${new Date(finding.actualCompletionDate).toLocaleDateString()})`}
                          </span>
                        ) : (
                          <span className="inline-flex items-center text-yellow-700">
                            <XCircleIcon className="h-3 w-3 mr-1" />Open
                          </span>
                        )}
                      </span>
                    </div>
                  </div>

                  {/* Body */}
                  <div className="space-y-2 text-xs">
                    <div>
                        <strong className="font-medium text-slate-500">Finding:</strong>
                        <p className="mt-0.5 text-slate-800">{finding.finding}</p>
                    </div>
                    <div>
                        <strong className="font-medium text-slate-500">Root Cause Analysis (RCA):</strong>
                        <p className="mt-0.5 text-slate-800">{finding.rootCauseAnalysis || 'N/A'}</p>
                    </div>
                    <div>
                        <strong className="font-medium text-slate-500">Hazard ID / Corrective Action Plan (CAP):</strong>
                        <p className="mt-0.5 text-slate-800">{finding.correctiveActionPlan || 'N/A'}</p>
                    </div>
                     <div>
                        <strong className="font-medium text-slate-500">Risk Assessment:</strong>
                        <p className="mt-0.5 text-slate-800">{finding.riskAssessment || 'N/A'}</p>
                    </div>
                    <div>
                        <strong className="font-medium text-slate-500">Mitigation Action / Corrective Action Taken:</strong>
                        <p className="mt-0.5 text-slate-800">{finding.correctiveActionTaken || 'N/A'}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-8">
            <p className="text-slate-500">No findings to display for this selection.</p>
          </div>
        )}
      </div>
      <div className="mt-6 flex justify-end">
        <button
          type="button"
          onClick={onClose}
          className="px-4 py-2 bg-brand-primary text-white rounded-md shadow-sm hover:bg-blue-800 text-sm"
        >
          Close
        </button>
      </div>
    </Modal>
  );
};
