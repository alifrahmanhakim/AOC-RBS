
import React, { useState } from 'react';
import { Modal } from '../shared/Modal';
import { PredefinedSurveillanceArea, SurveillanceLogStatus } from '../../types';
import toast from 'react-hot-toast';

interface SurveillanceBatchUpdateModalProps {
  isOpen: boolean;
  onClose: () => void;
  operatorId: string;
  selectedPredefinedAreas: PredefinedSurveillanceArea[];
  upsertLogItem: (operatorId: string, predefinedAreaId: string, status: SurveillanceLogStatus, notes?: string) => void;
}

export const SurveillanceBatchUpdateModal: React.FC<SurveillanceBatchUpdateModalProps> = ({
  isOpen,
  onClose,
  operatorId,
  selectedPredefinedAreas,
  upsertLogItem,
}) => {
  const [newStatus, setNewStatus] = useState<SurveillanceLogStatus>('Not Done');
  const [commonNotes, setCommonNotes] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedPredefinedAreas.length === 0) {
      toast.error("No areas selected for batch update.");
      return;
    }

    selectedPredefinedAreas.forEach(area => {
      upsertLogItem(operatorId, area.id, newStatus, commonNotes);
    });

    toast.success(`${selectedPredefinedAreas.length} area(s) status updated to "${newStatus}". Notes ${commonNotes ? 'applied.' : 'not changed (if blank).'}`);
    onClose(); 
  };

  if (!isOpen) return null;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`Batch Update Status (${selectedPredefinedAreas.length} Area${selectedPredefinedAreas.length === 1 ? '' : 's'})`}
      size="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4 text-sm">
        <div>
          <p className="font-medium text-slate-700 mb-1">Updating status for the following areas:</p>
          <div className="max-h-32 overflow-y-auto bg-slate-50 p-2 border border-slate-200 rounded-md text-xs space-y-1">
            {selectedPredefinedAreas.map(area => (
              <p key={area.id} className="truncate" title={`${area.itemNumber} - ${area.areaDescription}`}>
                <span className="font-semibold">{area.itemNumber}</span> - {area.areaDescription}
              </p>
            ))}
          </div>
        </div>

        <div>
          <label htmlFor="batchStatus" className="block text-xs font-medium text-slate-700">Set Status to:</label>
          <select
            id="batchStatus"
            value={newStatus}
            onChange={(e) => setNewStatus(e.target.value as SurveillanceLogStatus)}
            className="w-full p-1.5 border border-slate-300 rounded-md shadow-sm text-xs bg-white mt-1"
          >
            <option value="Not Done">Not Done</option>
            <option value="On Going">On Going</option>
            <option value="Done">Done</option>
          </select>
        </div>

        <div>
          <label htmlFor="commonNotes" className="block text-xs font-medium text-slate-700">Common Notes (Optional)</label>
          <textarea
            id="commonNotes"
            value={commonNotes}
            onChange={(e) => setCommonNotes(e.target.value)}
            rows={3}
            className="w-full p-1.5 border border-slate-300 rounded-md shadow-sm text-xs mt-1"
            placeholder="These notes will be applied to all selected items. Existing notes will be overwritten if text is entered here."
          />
        </div>

        <div className="flex justify-end space-x-3 pt-3">
          <button type="button" onClick={onClose} className="px-4 py-2 border border-slate-300 rounded-md shadow-sm hover:bg-slate-50 text-slate-700 text-xs">Cancel</button>
          <button type="submit" className="px-4 py-2 bg-brand-primary text-white rounded-md shadow-sm hover:bg-blue-700 text-xs">Apply to Selected</button>
        </div>
      </form>
    </Modal>
  );
};