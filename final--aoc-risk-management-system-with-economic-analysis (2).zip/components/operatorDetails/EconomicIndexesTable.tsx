import React from 'react';
import { EconomicFactors } from '../../types';

interface EconomicIndexesTableProps {
  economicFactors?: EconomicFactors;
}

const getHeatmapColor = (score: number | undefined): string => {
  if (score === undefined) return 'bg-slate-100 text-slate-500'; // Not available
  if (score <= 2.0) return 'bg-green-100 text-green-800';       // Good
  if (score <= 4.0) return 'bg-lime-100 text-lime-800';        
  if (score <= 6.0) return 'bg-yellow-100 text-yellow-800';     // Caution
  if (score <= 8.0) return 'bg-orange-100 text-orange-800';    
  return 'bg-red-100 text-red-800';                             // Problematic
};

const indexDisplayOrder: Array<keyof Omit<EconomicFactors, 'lastUpdatedByAI' | `${keyof EconomicFactors}Details`>> = [
  'liquidity',
  'shortTermDebt',
  'longTermDebt',
  'decapitalization',
  'profitabilityAndCashFlows',
];

const indexFriendlyNames: Record<string, string> = {
  liquidity: "Liquidity",
  shortTermDebt: "Short-Term Debt",
  longTermDebt: "Long-Term Debt",
  decapitalization: "Decapitalization",
  profitabilityAndCashFlows: "Profitability & Cash Flows",
};

export const EconomicIndexesTable: React.FC<EconomicIndexesTableProps> = ({ economicFactors }) => {
  if (!economicFactors) {
    return <p className="text-xs text-slate-500 italic">Economic factors data not available.</p>;
  }

  return (
    <div className="space-y-3 text-xs">
      {indexDisplayOrder.map(key => {
        const factorKey = key as keyof Omit<EconomicFactors, 'lastUpdatedByAI' | `${keyof EconomicFactors}Details`>;
        const score = economicFactors[factorKey];
        const detailsKey = `${factorKey}Details` as keyof EconomicFactors;
        const details = economicFactors[detailsKey] as Record<string, string | number> | undefined;
        const colorClass = getHeatmapColor(score);

        return (
          <div key={factorKey} className={`p-2 border rounded-md ${colorClass}`}>
            <div className="flex justify-between items-center font-semibold mb-1">
              <span>{indexFriendlyNames[factorKey]}</span>
              <span>Score: {score !== undefined ? score.toFixed(1) : 'N/A'} / 10</span>
            </div>

            {/* Display representative formula */}
            <div className="text-[10px] text-slate-600 mb-1">
              <p className="font-medium">Example Formula(s):</p>
              {factorKey === 'liquidity' && (
                <>
                  <p><em>Current Ratio = Current Assets / Current Liabilities</em></p>
                  <p><em>Acid-Test Ratio = (Cash + Marketable Securities + Receivables) / Current Liabilities</em></p>
                </>
              )}
              {factorKey === 'shortTermDebt' && (
                <p><em>Short-Term Debt to Equity = Short-Term Liabilities / Shareholder's Equity</em></p>
              )}
              {factorKey === 'longTermDebt' && (
                <p><em>Long-Term Debt to Equity = Long-Term Liabilities / Shareholder's Equity</em></p>
              )}
              {factorKey === 'decapitalization' && (
                // Decapitalization is often assessed via Debt-to-Assets or Debt-to-Capital ratios.
                <p><em>Debt-to-Total-Assets = Total Liabilities / Total Assets</em></p>
              )}
              {factorKey === 'profitabilityAndCashFlows' && (
                <>
                  <p><em>Net Profit Margin = Net Income / Total Revenue</em></p>
                  <p><em>Operating Cash Flow Margin = Operating Cash Flow / Total Revenue</em></p>
                </>
              )}
            </div>
            
            {/* Display details (components and their values) provided by AI */}
            {details && Object.keys(details).length > 0 && (
              <div className="mt-1 pt-1 border-t border-current opacity-60">
                <p className="text-[10px] font-medium text-slate-700">Contributing Factors & Values (from AI):</p>
                {Object.entries(details).map(([detailKey, detailValue]) => (
                  <div key={detailKey} className="flex justify-between text-[10px]">
                    <span className="italic">{detailKey}:</span>
                    <span>{String(detailValue)}</span>
                  </div>
                ))}
              </div>
            )}
            {!details && <p className="text-[10px] italic opacity-70">No detailed contributing factors & values provided by AI.</p>}
          </div>
        );
      })}
       <p className="text-[10px] text-slate-500 mt-1">
        Note: Scores are 0-10, where a higher score indicates a worse economic situation.
        {economicFactors.lastUpdatedByAI && ` Last updated by AI: ${new Date(economicFactors.lastUpdatedByAI).toLocaleDateString()}.`}
      </p>
    </div>
  );
};