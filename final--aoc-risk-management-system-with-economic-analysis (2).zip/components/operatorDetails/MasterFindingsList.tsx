
import React, { useState, useMemo } from 'react';
import { Operator, SurveillanceFinding, UserRole } from '../../types';
import { useAuth } from '../../contexts/AuthContext';
import { PREDEFINED_SURVEILLANCE_AREAS } from '../../constants';
import { PencilIcon, TrashIcon, CheckCircleIcon, XCircleIcon, ExclamationTriangleIcon, ListBulletIcon } from '../icons';
import toast from 'react-hot-toast';

interface MasterFindingsListProps {
  operator: Operator;
  onOpenFindingModal: (config: { finding: SurveillanceFinding }) => void;
  onDeleteFinding: (operatorId: string, findingId: string) => void;
  onToggleFindingCompletion: (operatorId: string, findingId: string) => void;
}

type FilterType = 'all' | 'open' | 'completed';

export const MasterFindingsList: React.FC<MasterFindingsListProps> = ({
  operator,
  onOpenFindingModal,
  onDeleteFinding,
  onToggleFindingCompletion,
}) => {
  const { currentUser } = useAuth();
  const isAdmin = currentUser?.role === UserRole.ADMIN;
  const [filter, setFilter] = useState<FilterType>('open');

  const filteredFindings = useMemo(() => {
    const findings = operator.surveillanceFindings || [];
    if (filter === 'open') {
      return findings.filter(f => !f.isCompleted);
    }
    if (filter === 'completed') {
      return findings.filter(f => f.isCompleted);
    }
    return findings;
  }, [operator.surveillanceFindings, filter]);
  
  const sortedFindings = useMemo(() => {
    return [...filteredFindings].sort((a, b) => {
        if (a.isCompleted !== b.isCompleted) {
            return a.isCompleted ? 1 : -1;
        }
        return new Date(b.targetCompletionDate).getTime() - new Date(a.targetCompletionDate).getTime();
    });
  }, [filteredFindings]);
  
  const FilterButton: React.FC<{
    buttonFilter: FilterType;
    currentFilter: FilterType;
    setFilter: (filter: FilterType) => void;
    text: string;
    count: number;
  }> = ({ buttonFilter, currentFilter, setFilter, text, count }) => (
    <button
      onClick={() => setFilter(buttonFilter)}
      className={`px-3 py-1 text-xs rounded-md font-medium transition-colors ${
        currentFilter === buttonFilter
          ? 'bg-brand-primary text-white shadow'
          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
      }`}
    >
      {text} <span className="ml-1 px-1.5 py-0.5 text-[10px] bg-black/10 rounded-full">{count}</span>
    </button>
  );

  return (
    <div className="bg-white shadow-xl rounded-xl p-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4">
            <h3 className="text-xl font-semibold text-slate-700 mb-2 sm:mb-0 flex items-center">
                <ListBulletIcon className="h-6 w-6 mr-2 text-brand-primary" />
                Master Surveillance Findings List
            </h3>
            <div className="flex space-x-2">
                <FilterButton buttonFilter="all" currentFilter={filter} setFilter={setFilter} text="All" count={operator.surveillanceFindings?.length || 0} />
                <FilterButton buttonFilter="open" currentFilter={filter} setFilter={setFilter} text="Open" count={operator.surveillanceFindings?.filter(f => !f.isCompleted).length || 0} />
                <FilterButton buttonFilter="completed" currentFilter={filter} setFilter={setFilter} text="Completed" count={operator.surveillanceFindings?.filter(f => f.isCompleted).length || 0} />
            </div>
        </div>
        
        <div className="overflow-x-auto">
            {sortedFindings.length > 0 ? (
                <table className="min-w-full text-xs">
                    <thead className="bg-slate-50">
                        <tr>
                            <th className="p-2 text-left font-medium text-slate-500">Area No.</th>
                            <th className="p-2 text-left font-medium text-slate-500">Finding</th>
                            <th className="p-2 text-left font-medium text-slate-500">Level</th>
                            <th className="p-2 text-left font-medium text-slate-500">Target Date</th>
                            <th className="p-2 text-left font-medium text-slate-500">Completed Date</th>
                            <th className="p-2 text-left font-medium text-slate-500">Status</th>
                            {isAdmin && <th className="p-2 text-left font-medium text-slate-500">Actions</th>}
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {sortedFindings.map(finding => {
                            const area = PREDEFINED_SURVEILLANCE_AREAS.find(a => a.id === finding.predefinedAreaId);
                            const isOverdue = !finding.isCompleted && new Date(finding.targetCompletionDate) < new Date();
                            return (
                                <tr key={finding.id} className="hover:bg-slate-50">
                                    <td className="p-2 font-mono text-slate-600" title={area?.areaDescription}>{area?.itemNumber || 'N/A'}</td>
                                    <td className="p-2 max-w-sm">
                                        <p className="font-medium text-slate-800 truncate" title={finding.finding}>{finding.finding}</p>
                                        <p className="text-slate-500 truncate" title={area?.areaDescription}>{area?.areaDescription}</p>
                                    </td>
                                    <td className="p-2">{finding.findingCategory.split(' ')[1]}</td>
                                    <td className={`p-2 ${isOverdue ? 'text-red-600 font-semibold' : ''}`}>{new Date(finding.targetCompletionDate).toLocaleDateString()}</td>
                                    <td className="p-2">
                                        {finding.isCompleted && finding.actualCompletionDate 
                                            ? new Date(finding.actualCompletionDate).toLocaleDateString() 
                                            : 'N/A'}
                                    </td>
                                    <td className="p-2">
                                        {finding.isCompleted ? (
                                            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium bg-green-100 text-green-800">
                                                <CheckCircleIcon className="h-3 w-3 mr-1"/> Completed
                                            </span>
                                        ) : (
                                            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium bg-yellow-100 text-yellow-800">
                                                <XCircleIcon className="h-3 w-3 mr-1"/> Open
                                            </span>
                                        )}
                                    </td>
                                    {isAdmin && <td className="p-2 whitespace-nowrap">
                                        <div className="flex items-center space-x-1">
                                            <button onClick={() => onOpenFindingModal({ finding })} title="Edit" className="p-1 text-brand-secondary hover:text-sky-700"><PencilIcon className="h-3.5 w-3.5"/></button>
                                            <button onClick={() => onDeleteFinding(operator.id, finding.id)} title="Delete" className="p-1 text-red-500 hover:text-red-700"><TrashIcon className="h-3.5 w-3.5"/></button>
                                            {!finding.isCompleted && (
                                                <button onClick={() => onToggleFindingCompletion(operator.id, finding.id)} title="Mark as Completed" className="p-1 text-green-600 hover:text-green-800"><CheckCircleIcon className="h-4 w-4"/></button>
                                            )}
                                        </div>
                                    </td>}
                                </tr>
                            )
                        })}
                    </tbody>
                </table>
            ) : (
                <div className="text-center py-8 text-sm text-slate-500 bg-slate-50 rounded-md">
                    <ExclamationTriangleIcon className="mx-auto h-6 w-6 text-slate-400 mb-2"/>
                    No {filter} findings for this operator.
                </div>
            )}
        </div>
    </div>
  );
};