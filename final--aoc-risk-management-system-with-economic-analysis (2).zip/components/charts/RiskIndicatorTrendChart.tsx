
import React, { useState, useMemo, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine } from 'recharts';
import { RiskIndicatorHistoryEntry } from '../../types';
import { LoadingSpinner } from '../shared/LoadingSpinner';
import { ArrowPathIcon, SparklesIcon } from '../icons'; 
import { GoogleGenAI, GenerateContentResponse } from '@google/genai';
import toast from 'react-hot-toast';

type Period = 'Daily' | 'Monthly' | 'Annually';

interface ChartDataPoint {
  date: string; // Formatted date for display
  level: number | null; // Null for gaps in prediction or if actual data point is missing
  type: 'historical' | 'predicted';
  originalDate?: Date; // For sorting and processing
}

const formatDateForDisplay = (dateStr: string, period: Period): string => {
    const dateObj = new Date(dateStr);
    if (period === 'Monthly') return dateObj.toLocaleDateString('en-US', { year: 'numeric', month: 'short' });
    if (period === 'Annually') return dateObj.toLocaleDateString('en-US', { year: 'numeric' });
    return dateObj.toLocaleDateString('en-CA'); // YYYY-MM-DD for Daily
};

const processHistoryData = (historyData: RiskIndicatorHistoryEntry[], period: Period): ChartDataPoint[] => {
  if (!historyData || historyData.length === 0) return [];

  if (period === 'Daily') {
    return historyData.map(entry => ({
      date: entry.date, 
      level: entry.technicalIndicator,
      type: 'historical' as 'historical',
      originalDate: new Date(entry.date)
    })).sort((a,b) => a.originalDate!.getTime() - b.originalDate!.getTime())
     .map(item => ({ ...item, date: formatDateForDisplay(item.date, period) }));
  }

  const aggregated: Record<string, { sumLevel: number, count: number, firstDate: Date }> = {};

  historyData.forEach(entry => {
    const entryDate = new Date(entry.date);
    let key = '';
    if (period === 'Monthly') {
      key = `${entryDate.getFullYear()}-${String(entryDate.getMonth() + 1).padStart(2, '0')}`;
    } else { // Annually
      key = `${entryDate.getFullYear()}`;
    }

    if (!aggregated[key]) {
      aggregated[key] = { sumLevel: 0, count: 0, firstDate: entryDate };
    }
    aggregated[key].sumLevel += entry.technicalIndicator;
    aggregated[key].count++;
    if (entryDate < aggregated[key].firstDate) {
        aggregated[key].firstDate = entryDate;
    }
  });
  
  return Object.entries(aggregated).map(([dateKey, { sumLevel, count, firstDate }]) => ({
    date: period === 'Monthly' ? `${dateKey}-01` : `${dateKey}-01-01`, 
    level: parseFloat((sumLevel / count).toFixed(2)),
    type: 'historical' as 'historical',
    originalDate: firstDate
  })).sort((a,b) => new Date(a.date).getTime() - new Date(b.date).getTime())
   .map(item => ({ ...item, date: formatDateForDisplay(item.date, period) }));
};

interface RiskIndicatorTrendChartProps {
  historyData: RiskIndicatorHistoryEntry[];
  aiClient: GoogleGenAI | null;
  operatorName: string;
  operatorAoc: string;
}

export const RiskIndicatorTrendChart: React.FC<RiskIndicatorTrendChartProps> = ({ historyData, aiClient, operatorName, operatorAoc }) => {
  const [period, setPeriod] = useState<Period>('Monthly');
  const [chartKey, setChartKey] = useState(0); 
  const [showPrediction, setShowPrediction] = useState(false);
  const [predictedData, setPredictedData] = useState<ChartDataPoint[]>([]);
  const [isPredictionLoading, setIsPredictionLoading] = useState(false);
  const [predictionError, setPredictionError] = useState<string | null>(null);

  const historicalChartData = useMemo(() => processHistoryData(historyData || [], period), [historyData, period]);

  const combinedChartData = useMemo(() => {
    if (showPrediction && predictedData.length > 0) {
      // Simple merge, assuming dates are aligned or prediction follows history
      // More sophisticated merging might be needed for perfect alignment if historical data is sparse
      return [...historicalChartData, ...predictedData];
    }
    return historicalChartData;
  }, [historicalChartData, predictedData, showPrediction]);

  const fetchPrediction = async () => {
    if (!aiClient || !showPrediction || (period !== 'Monthly' && period !== 'Annually')) {
      setPredictedData([]); // Clear predictions if conditions not met
      return;
    }
    
    setIsPredictionLoading(true);
    setPredictionError(null);
    setPredictedData([]); // Clear previous predictions

    const numPeriodsToPredict = period === 'Monthly' ? 6 : 2; // Predict 6 months or 2 years
    const lastHistoricalDateStr = historicalChartData.length > 0 ? historicalChartData[historicalChartData.length - 1].date : new Date().toISOString().split('T')[0];
    const historicalContext = historicalChartData.slice(-12).map(p => `Date: ${p.date}, Level: ${p.level}`).join('\n'); // Last 12 points of current view

    const prompt = `
      Operator: ${operatorName} (AOC: ${operatorAoc})
      Current Risk Indicator Level Trend (up to 12 recent points for the ${period} view):
      ${historicalContext || "No historical data provided for this view."}

      Based on this historical trend, predict the Risk Indicator Level for the next ${numPeriodsToPredict} ${period === 'Monthly' ? 'months' : 'years'}.
      The Risk Indicator Level is a score from 1 (Very Low Risk) to 5 (Very High Risk).
      Return your response ONLY as a JSON object with a single key "predictions", which is an array of objects.
      Each object in the array should have "date" (format "YYYY-MM" for Monthly, "YYYY" for Annually, starting from the period after the last historical data point: ${lastHistoricalDateStr}) and "level" (a number between 1 and 5, can be float).

      Example for Monthly from last historical YYYY-MM: {"predictions": [{"date": "YYYY-MM+1", "level": 3.2}, {"date": "YYYY-MM+2", "level": 3.1}, ...]}
      Example for Annually from last historical YYYY: {"predictions": [{"date": "YYYY+1", "level": 2.8}, {"date": "YYYY+2", "level": 2.7}, ...]}
    `;

    try {
      const response: GenerateContentResponse = await aiClient.models.generateContent({
        model: 'gemini-2.5-flash-preview-04-17', // Ensure this model exists and is suitable
        contents: prompt,
        config: { responseMimeType: "application/json" }
      });

      const responseText = response.text;
      if (!responseText || responseText.trim() === '') {
        throw new Error("AI returned an empty prediction.");
      }
      let jsonStr = responseText.trim();
      const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
      const match = jsonStr.match(fenceRegex);
      if (match && match[2]) jsonStr = match[2].trim();

      const parsed = JSON.parse(jsonStr);
      if (parsed.predictions && Array.isArray(parsed.predictions)) {
        const formattedPredictions: ChartDataPoint[] = parsed.predictions.map((p: any) => ({
          date: formatDateForDisplay(period === 'Monthly' ? `${p.date}-01` : `${p.date}-01-01`, period),
          level: typeof p.level === 'number' && p.level >=1 && p.level <=5 ? parseFloat(p.level.toFixed(2)) : null,
          type: 'predicted'
        }));
        setPredictedData(formattedPredictions);
      } else {
        throw new Error("AI prediction response is not in the expected format.");
      }
    } catch (error: any) {
      console.error("Error fetching AI prediction:", error);
      setPredictionError(`Prediction failed: ${error.message || 'Unknown AI error'}`);
      toast.error(`Prediction failed: ${error.message || 'Unknown AI error'}`);
    } finally {
      setIsPredictionLoading(false);
    }
  };

  useEffect(() => {
    if (showPrediction && aiClient) {
      fetchPrediction();
    } else {
      setPredictedData([]); // Clear predictions if toggle is off or AI client not ready
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showPrediction, period, aiClient]); // Re-fetch if period or AI client changes while toggle is on


  useEffect(() => {
    setChartKey(prevKey => prevKey + 1);
  }, [combinedChartData, period]);


  if (!historyData || historyData.length === 0) {
    return <p className="text-slate-500 text-sm italic">No historical risk indicator data available.</p>;
  }
  
  const yDomain: [number, number] = [0, 5.5];

  const CustomTooltipContent = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const dataPoint = payload[0].payload as ChartDataPoint;
      return (
        <div className="bg-white p-2 border border-slate-300 rounded shadow-lg text-xs">
          <p className="font-bold">{label}</p>
          <p style={{ color: payload[0].color }}>
            Level: {dataPoint.level?.toFixed(2) ?? 'N/A'} 
            {dataPoint.type === 'predicted' && <span className="italic text-sky-600"> (Predicted)</span>}
          </p>
        </div>
      );
    }
    return null;
  };


  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div className="flex items-center">
            {(period === 'Monthly' || period === 'Annually') && API_KEY && aiClient && (
                <label htmlFor="showPredictionToggle" className="flex items-center cursor-pointer mr-4">
                <div className="relative">
                    <input 
                        type="checkbox" 
                        id="showPredictionToggle" 
                        className="sr-only" 
                        checked={showPrediction}
                        onChange={() => setShowPrediction(!showPrediction)} 
                        disabled={isPredictionLoading}
                    />
                    <div className={`block w-10 h-6 rounded-full transition-colors ${showPrediction ? 'bg-teal-500' : 'bg-slate-300'}`}></div>
                    <div className={`dot absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform ${showPrediction ? 'translate-x-full' : ''}`}></div>
                </div>
                <div className="ml-2 text-xs text-slate-700 flex items-center">
                    <SparklesIcon className={`h-3.5 w-3.5 mr-1 ${showPrediction ? 'text-teal-500' : 'text-slate-400'}`} /> Show AI Prediction
                </div>
                </label>
            )}
            {isPredictionLoading && <LoadingSpinner size="sm"/>}
        </div>
        <div className="flex space-x-2">
            {(['Daily', 'Monthly', 'Annually'] as Period[]).map(p => (
            <button
                key={p}
                onClick={() => setPeriod(p)}
                className={`px-3 py-1 text-xs rounded-md transition-colors ${
                period === p 
                    ? 'bg-brand-primary text-white shadow-md' 
                    : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                }`}
            >
                {p}
            </button>
            ))}
        </div>
      </div>
      {predictionError && (
        <p className="text-xs text-red-500 bg-red-50 p-2 rounded-md border border-red-200">{predictionError}</p>
      )}

      {(historicalChartData.length === 0 && (!showPrediction || predictedData.length === 0)) && (
          <div className="flex items-center justify-center h-64 bg-slate-50 rounded-md">
            <p className="text-slate-500">No data available for the selected period.</p>
          </div>
      )}
      {(historicalChartData.length > 0 || (showPrediction && predictedData.length > 0)) && (
        <ResponsiveContainer key={chartKey} width="100%" height={300}>
          <LineChart data={combinedChartData} margin={{ top: 5, right: 20, left: -20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
            <XAxis 
                dataKey="date" 
                tick={{ fontSize: 10 }} 
                angle={period === 'Daily' ? -30 : 0} 
                textAnchor={period === 'Daily' ? 'end' : 'middle'}
                height={period === 'Daily' ? 40 : 20}
                interval="preserveStartEnd"
            />
            <YAxis domain={yDomain} ticks={[1, 2, 3, 4, 5]} tick={{ fontSize: 10 }} />
            <Tooltip content={<CustomTooltipContent />} />
            <Legend wrapperStyle={{fontSize: "12px"}}/>
            <Line 
              type="monotone" 
              dataKey="level" 
              name="Historical Risk Level" 
              stroke="#1e3a8a" 
              strokeWidth={2} 
              dot={{ r: 3 }} 
              activeDot={{ r: 5 }} 
              connectNulls={false} // Important for separating historical from prediction
              data={historicalChartData} // Ensure only historical data is passed here
            />
            {showPrediction && predictedData.length > 0 && (
              <Line 
                type="monotone" 
                dataKey="level" 
                name="Predicted Risk Level" 
                stroke="#0ea5e9" 
                strokeWidth={2} 
                strokeDasharray="5 5"
                dot={{ r: 3, fill: '#0ea5e9' }} 
                activeDot={{ r: 5, stroke: '#0ea5e9' }}
                connectNulls={false}
                data={predictedData} // Pass only predicted data
              />
            )}
          </LineChart>
        </ResponsiveContainer>
      )}
    </div>
  );
};
