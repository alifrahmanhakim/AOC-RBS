
import React from 'react';
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { EconomicFactors } from '../../types';
import { LoadingSpinner } from '../shared/LoadingSpinner';

interface EconomicSpiderwebChartProps {
  economicFactors?: EconomicFactors;
}

const chartSubjects = [
  { name: 'Liquidity', dataKey: 'liquidity', A: 0, fullMark: 10 },
  { name: 'S-Term Debt', dataKey: 'shortTermDebt', A: 0, fullMark: 10 },
  { name: 'L-Term Debt', dataKey: 'longTermDebt', A: 0, fullMark: 10 },
  { name: 'Decapital.', dataKey: 'decapitalization', A: 0, fullMark: 10 },
  { name: 'Profit/Cash', dataKey: 'profitabilityAndCashFlows', A: 0, fullMark: 10 },
];

export const EconomicSpiderwebChart: React.FC<EconomicSpiderwebChartProps> = ({ economicFactors }) => {
  if (!economicFactors) {
    return (
      <div className="h-[300px] flex items-center justify-center bg-slate-50 rounded-md">
        <p className="text-xs text-slate-500">Economic factors data not available.</p>
      </div>
    );
  }

  const data = chartSubjects.map(subject => ({
    subject: subject.name,
    A: economicFactors[subject.dataKey as keyof Omit<EconomicFactors, 'lastUpdatedByAI' | `${keyof EconomicFactors}Details`>] ?? 5, // Default to 5 if undefined
    fullMark: 10,
  }));
  
  const lastUpdated = economicFactors.lastUpdatedByAI 
    ? new Date(economicFactors.lastUpdatedByAI).toLocaleDateString() 
    : 'N/A';

  return (
    <div className="h-[300px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart cx="50%" cy="50%" outerRadius="80%" data={data}>
          <PolarGrid />
          <PolarAngleAxis dataKey="subject" tick={{ fontSize: 10 }} />
          <PolarRadiusAxis angle={30} domain={[0, 10]} tickCount={6} tick={{ fontSize: 9 }} />
          <Radar name={`Operator (Updated: ${lastUpdated})`} dataKey="A" stroke="#ef4444" fill="#ef4444" fillOpacity={0.4} strokeWidth={2} />
          <Tooltip 
            contentStyle={{ backgroundColor: 'rgba(255,255,255,0.9)', border: '1px solid #ccc', borderRadius: '5px', fontSize: '11px', padding: '8px'}}
            formatter={(value: number, name: string, props: any) => {
                 return [`${value.toFixed(1)} / 10 (Higher is worse)`, props.payload.subject];
            }}
          />
          <Legend wrapperStyle={{fontSize: "10px", paddingTop: "10px"}} />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
};
