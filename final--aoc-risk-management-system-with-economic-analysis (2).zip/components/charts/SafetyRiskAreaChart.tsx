import React, { useState, useEffect, useRef, useMemo } from 'react';
import { ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, Legend as RechartsLegend, ResponsiveContainer, ReferenceArea, LabelList, ZAxis, Line } from 'recharts';
import { Operator, RiskIndicatorHistoryEntry, OPERATOR_CATEGORIES } from '../../types';
import { LoadingSpinner } from '../shared/LoadingSpinner'; 
import { HistoricalPathPeriod } from '../../pages/OperatorDetailPage'; // Import the type

interface SafetyRiskAreaChartProps {
  currentOperator: Operator;
  allOperators: Operator[];
  historicalPathPeriod: HistoricalPathPeriod;
}

interface HistoricalPoint {
  x: number; // economicIndicator
  y: number; // technicalIndicator
  date: string;
  name: string; 
}

// Helper function to get week number (ISO 8601)
const getWeekNumber = (d: Date): number => {
  const date = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  date.setUTCDate(date.getUTCDate() + 4 - (date.getUTCDay() || 7));
  const yearStart = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil((((date.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
  return weekNo;
};

const aggregateHistoryByPeriod = (
  history: RiskIndicatorHistoryEntry[],
  period: HistoricalPathPeriod
): HistoricalPoint[] => {
  if (!history || history.length === 0) return [];

  const sortedHistory = [...history].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  if (period === 'Daily') {
    return sortedHistory.map(entry => ({
      x: entry.economicIndicator,
      y: entry.technicalIndicator,
      date: entry.date,
      name: `Historical (Daily)`
    }));
  }

  const aggregated: Record<string, { sumEcon: number; sumTech: number; count: number; firstDate: string }> = {};

  sortedHistory.forEach(entry => {
    const entryDate = new Date(entry.date);
    let key = '';

    if (period === 'Weekly') {
      const year = entryDate.getUTCFullYear();
      const week = getWeekNumber(entryDate);
      key = `${year}-W${String(week).padStart(2, '0')}`;
    } else if (period === 'Monthly') {
      key = `${entryDate.getUTCFullYear()}-${String(entryDate.getUTCMonth() + 1).padStart(2, '0')}`;
    } else { // Yearly
      key = `${entryDate.getUTCFullYear()}`;
    }

    if (!aggregated[key]) {
      aggregated[key] = { sumEcon: 0, sumTech: 0, count: 0, firstDate: entry.date };
    }
    aggregated[key].sumEcon += entry.economicIndicator;
    aggregated[key].sumTech += entry.technicalIndicator;
    aggregated[key].count++;
    if (new Date(entry.date) < new Date(aggregated[key].firstDate)) {
        aggregated[key].firstDate = entry.date;
    }
  });

  return Object.values(aggregated).map(({ sumEcon, sumTech, count, firstDate }) => ({
    x: parseFloat((sumEcon / count).toFixed(2)),
    y: parseFloat((sumTech / count).toFixed(2)),
    date: firstDate, 
    name: `Historical (${period})`
  })).sort((a,b) => new Date(a.date).getTime() - new Date(b.date).getTime());
};

const formatDateForTimestamp = (dateString: string | undefined, period?: HistoricalPathPeriod): string => {
  if (!dateString) return '';
  try {
    const dateObj = new Date(dateString);
    if (period === 'Daily') {
      return dateObj.toLocaleDateString('en-US', { month: '2-digit', day: '2-digit' }); // e.g., 06/15
    } else if (period === 'Weekly') {
      // For aggregated weekly points, the 'date' is the firstDate of that week.
      return dateObj.toLocaleDateString('en-US', { month: '2-digit', day: '2-digit' }); // e.g., 06/12
    } else if (period === 'Monthly') {
      return dateObj.toLocaleDateString('en-US', { month: 'short', year: '2-digit' }); // e.g., Jun '23
    } else if (period === 'Yearly') {
      return dateObj.toLocaleDateString('en-US', { year: 'numeric' }); // e.g., 2023
    }
    // Default for operator points (no period provided)
    return dateObj.toLocaleDateString('en-US', { month: '2-digit', day: '2-digit' }); // MM/DD
  } catch (e) {
    console.error("Error formatting date for timestamp:", e);
    return ''; 
  }
};


export const SafetyRiskAreaChart: React.FC<SafetyRiskAreaChartProps> = ({ currentOperator, allOperators, historicalPathPeriod }) => {
  const [chartReady, setChartReady] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const relevantOperators = allOperators.filter(
    op => op.operatorCategory === currentOperator.operatorCategory &&
          op.economicIndicatorScore !== undefined &&
          op.riskIndicatorLevel !== undefined 
  );

  const scatterData = relevantOperators.map(op => ({
    x: op.economicIndicatorScore, 
    y: op.riskIndicatorLevel,     
    name: op.name.length > 15 ? op.name.substring(0,12) + "..." : op.name,
    isCurrent: op.id === currentOperator.id,
    hasFatalAccident: op.hadFatalAccidentLast3Years,
    z: op.id === currentOperator.id ? 200 : 100, 
    id: op.id,
    lastUpdated: op.lastUpdated, // Added for timestamp
  }));

  const historicalPathData = useMemo(() => {
    if (!currentOperator.riskIndicatorHistory || currentOperator.riskIndicatorHistory.length === 0) {
      return [];
    }
    
    const aggregated = aggregateHistoryByPeriod(currentOperator.riskIndicatorHistory, historicalPathPeriod);

    const path: HistoricalPoint[] = aggregated.map(entry => ({
      x: entry.x,
      y: entry.y,
      date: entry.date,
      name: `${currentOperator.name} (${historicalPathPeriod})`
    }));
    
    const lastAggregatedEntry = path.length > 0 ? path[path.length - 1] : null;
    
    if (currentOperator.economicIndicatorScore !== undefined && currentOperator.riskIndicatorLevel !== undefined) {
        let shouldAddCurrent = true;
        if (lastAggregatedEntry) {
            const lastEntryDate = new Date(lastAggregatedEntry.date);
            const currentDate = new Date(currentOperator.lastUpdated); // Use operator's lastUpdated for current point
            let samePeriod = false;

            if (historicalPathPeriod === 'Daily') {
                samePeriod = lastEntryDate.toDateString() === currentDate.toDateString();
            } else if (historicalPathPeriod === 'Weekly') {
                samePeriod = getWeekNumber(lastEntryDate) === getWeekNumber(currentDate) && lastEntryDate.getUTCFullYear() === currentDate.getUTCFullYear();
            } else if (historicalPathPeriod === 'Monthly') {
                samePeriod = lastEntryDate.getUTCMonth() === currentDate.getUTCMonth() && lastEntryDate.getUTCFullYear() === currentDate.getUTCFullYear();
            } else if (historicalPathPeriod === 'Yearly') {
                samePeriod = lastEntryDate.getUTCFullYear() === currentDate.getUTCFullYear();
            }

            if (samePeriod &&
                Math.abs(lastAggregatedEntry.x - currentOperator.economicIndicatorScore) < 0.01 && 
                Math.abs(lastAggregatedEntry.y - currentOperator.riskIndicatorLevel) < 0.01) {
                shouldAddCurrent = false;
            }
        }

        if (shouldAddCurrent) {
            path.push({
                x: currentOperator.economicIndicatorScore,
                y: currentOperator.riskIndicatorLevel,
                date: currentOperator.lastUpdated, 
                name: `${currentOperator.name} (Current)`
            });
        }
    }
    return path.sort((a,b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [currentOperator, historicalPathPeriod]);


  useEffect(() => {
    let animationFrameId: number | null = null;
    let timerId: number | null = null;

    const attemptSetReady = () => {
      if (containerRef.current && containerRef.current.offsetWidth > 0 && containerRef.current.offsetHeight > 0) {
        animationFrameId = requestAnimationFrame(() => {
          if (containerRef.current) {
            setChartReady(true);
          }
        });
      } else {
        timerId = window.setTimeout(attemptSetReady, 100);
      }
    };

    if (containerRef.current) {
      attemptSetReady();
    }

    return () => {
      if (animationFrameId) {
        cancelAnimationFrame(animationFrameId);
      }
      if (timerId) {
        clearTimeout(timerId);
      }
    };
  }, [currentOperator.id, historicalPathPeriod]); 

  useEffect(() => {
    setChartReady(false); 
  }, [currentOperator.id, historicalPathPeriod]);


  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const pointData = payload[0].payload; 
      return (
        <div className="bg-white p-2 border border-slate-300 rounded shadow-lg text-xs">
          <p className="font-bold text-brand-primary">{pointData.name}</p>
          <p>Economic Indicator: <span className="font-semibold">{pointData.x?.toFixed(1)}</span></p>
          <p>Technical Indicator (IDR): <span className="font-semibold">{pointData.y?.toFixed(historicalPathPeriod === 'Daily' ? 0 : 2)}</span></p>
          {pointData.hasFatalAccident && <p className="text-red-600 font-semibold">Had fatal accident (3 yrs)</p>}
          {pointData.date && <p>Date: <span className="font-semibold">{new Date(pointData.date).toLocaleDateString()}</span></p>}
        </div>
      );
    }
    return null;
  };

    const OperatorPointShape = (props: any) => {
        const { cx, cy, payload } = props; 
        if (!payload || typeof payload !== 'object' || cx === undefined || cy === undefined ) {
            return null;
        }
        const size = payload.isCurrent ? 12 : 8;
        const color = payload.hasFatalAccident ? '#ef4444' : (payload.isCurrent ? '#1e3a8a' : '#9ca3af');
        const strokeColor = payload.hasFatalAccident ? '#b91c1c' : (payload.isCurrent ? '#0ea5e9' : '#6b7280');
        const fillOpacity = payload.hasFatalAccident ? 1 : (payload.isCurrent ? 0.9 : 0.7);
        const timestampYOffset = (size / 2) + 8; // circle radius + gap
        
        return (
            <g>
                <circle cx={cx} cy={cy} r={size/2} fill={color} stroke={strokeColor} strokeWidth={payload.isCurrent ? 2 : 1} fillOpacity={fillOpacity} />
                <text x={cx} y={cy + timestampYOffset} textAnchor="middle" fontSize="8px" fill="#475569" style={{ pointerEvents: 'none' }}>
                    {formatDateForTimestamp(payload.lastUpdated)}
                </text>
            </g>
        );
    };
  
    const HistoricalPathPointShape = (props: any) => {
        const { cx, cy, payload, period } = props; // period is passed via dot prop now
        if (cx === undefined || cy === undefined || !payload) return null;
        const isCurrentDataPoint = payload.name && payload.name.includes('(Current)');
        const radius = isCurrentDataPoint ? 3 : 2;
        const timestampYOffset = radius + 6; // circle radius + gap

        return (
            <g>
                <circle cx={cx} cy={cy} r={radius} fill={isCurrentDataPoint ? '#1e3a8a' : '#475569'} />
                 <text x={cx} y={cy + timestampYOffset} textAnchor="middle" fontSize="8px" fill="#475569" style={{ pointerEvents: 'none' }}>
                    {formatDateForTimestamp(payload.date, period)}
                </text>
            </g>
        );
    };


  if (!chartReady && scatterData.length === 0 && !containerRef.current) {
    return (
      <div ref={containerRef} className="h-[450px] bg-slate-50 p-4 rounded-lg border border-slate-200 flex items-center justify-center">
        <p className="text-slate-500 text-sm">
          No operators with sufficient data found in category '{currentOperator.operatorCategory || 'N/A'}' for the Safety Risk Area chart.
        </p>
      </div>
    );
  }

  return (
    <div ref={containerRef} className="h-[450px] bg-slate-50 p-4 rounded-lg border border-slate-200">
      {!chartReady ? (
        <div className="flex items-center justify-center h-full">
          <LoadingSpinner /> <span className="ml-2 text-sm text-slate-500">Loading chart...</span>
        </div>
      ) : scatterData.length === 0 && historicalPathData.length === 0 ? (
         <div className="flex items-center justify-center h-full">
            <p className="text-slate-500 text-sm">
            No operators or historical data in category '{currentOperator.operatorCategory || 'N/A'}' for chart.
            </p>
        </div>
      ) : (
        <ResponsiveContainer key={`${currentOperator.id}-${historicalPathData.length}-${historicalPathPeriod}`} width="100%" height="100%">
          <ScatterChart
            margin={{
              top: 20, right: 30, bottom: 40, left: 10,
            }}
          >
            <CartesianGrid strokeDasharray="3 3" />

            <XAxis
              type="number"
              dataKey="x"
              name="Economic Indicator"
              domain={[0, 5]}
              ticks={[0, 1, 2, 3, 4, 5]}
              label={{ value: "Economic Indicator", position: 'insideBottom', offset: -15, fontSize: 12 }}
              tick={{fontSize: 10}}
            />
            <YAxis
              type="number"
              dataKey="y"
              name="Technical Indicator (IDR)"
              domain={[0, 5]} 
              ticks={[0, 1, 2, 3, 4, 5]}
              label={{ value: "Technical Indicator (IDR)", angle: -90, position: 'insideLeft', offset: 0, fontSize: 12 }}
              tick={{fontSize: 10}}
            />
            <ZAxis type="number" dataKey="z" range={[60, 200]} />

            <ReferenceArea x1={0} x2={3} y1={0} y2={3} strokeOpacity={0.3} fill="#22c55e" fillOpacity={0.1} label={{ value: "Satisfactory", position: "inside", fontSize:10, fill: "#166534" }} ifOverflow="visible" />
            <ReferenceArea x1={3} x2={5} y1={0} y2={3} strokeOpacity={0.3} fill="#eab308" fillOpacity={0.1} label={{ value: "Negative", position: "inside", fontSize:10, fill: "#713f12" }} ifOverflow="visible" />
            <ReferenceArea x1={0} x2={3} y1={3} y2={5} strokeOpacity={0.3} fill="#eab308" fillOpacity={0.1} ifOverflow="visible" /> 
            <ReferenceArea x1={3} x2={4} y1={3} y2={4} strokeOpacity={0.3} fill="#f97316" fillOpacity={0.1} label={{ value: "Serious", position: "inside", fontSize:10, fill: "#7c2d12"}} ifOverflow="visible" />
            <ReferenceArea x1={4} x2={5} y1={3} y2={5} strokeOpacity={0.3} fill="#ef4444" fillOpacity={0.1} label={{ value: "Critical", position: "insideTopRight", dy:-5, dx:-5, fontSize:10, fill: "#7f1d1d" }} ifOverflow="visible" />
            <ReferenceArea x1={3} x2={4} y1={4} y2={5} strokeOpacity={0.3} fill="#ef4444" fillOpacity={0.1} ifOverflow="visible" />

            <Tooltip content={<CustomTooltip />} cursor={{ strokeDasharray: '3 3' }}/>
            <RechartsLegend
              payload={[
                { value: 'Current Operator', type: 'circle', id: 'currentOperator', color: '#1e3a8a'},
                { value: 'Other Operators', type: 'circle', id: 'otherOperators', color: '#9ca3af'},
                { value: 'Fatal Accident (3 yrs)', type: 'circle', id: 'fatalAccident', color: '#ef4444'},
                { value: `Historical Path (${historicalPathPeriod})`, type: 'line', id: 'historicalPath', color: '#64748b'}
              ]}
              iconSize={10}
              wrapperStyle={{ fontSize: "10px", bottom: -5, left: 20 }}
            />

            <Scatter name="All Operators" data={scatterData} shape={<OperatorPointShape />}>
              {scatterData.map((entry) => (
                <LabelList
                  key={`label-${entry.id}`}
                  dataKey="name"
                  position="top"
                  offset={entry.isCurrent ? 12: 8}
                  fontSize={entry.isCurrent ? 9 : 8}
                  fill={entry.hasFatalAccident ? '#ef4444' : (entry.isCurrent ? '#1e3a8a' : '#6b7280')}
                  style={{ pointerEvents: 'none' }}
                  visibility={entry.isCurrent ? 'visible' : 'hidden'}
                />
              ))}
            </Scatter>
            
            {historicalPathData.length > 0 && (
                 <Line
                    type="monotone"
                    dataKey="y" 
                    data={historicalPathData} 
                    name={`Historical Path (${historicalPathPeriod})`}
                    stroke="#64748b" 
                    strokeWidth={1.5}
                    strokeDasharray="3 3"
                    dot={(props: any) => <HistoricalPathPointShape {...props} period={historicalPathPeriod} />}
                    activeDot={{ r: 4, fill: '#475569', stroke: '#cbd5e1' }}
                    isAnimationActive={false} 
                />
            )}
          </ScatterChart>
        </ResponsiveContainer>
      )}
    </div>
  );
};
