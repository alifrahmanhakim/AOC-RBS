
import React, { useMemo, useState } from 'react';
import { Operator, SurveillanceLogCategory, PredefinedSurveillanceArea, SurveillanceLogItem, SurveillanceFinding, FindingCategoryLevel, SurveillanceLogStatus } from '../../types';
import { PREDEFINED_SURVEILLANCE_AREAS, RBS_COMPLIANCE_FINDING_WEIGHTS } from '../../constants';
import { TableCellsIcon, ChevronDownIcon, ChevronUpIcon, ListBulletIcon } from '../icons';
import toast from 'react-hot-toast';

interface SurveillanceComplianceHeatmapProps {
  operator: Operator;
  onCellClick: (findings: SurveillanceFinding[], title: string) => void;
}

const N_CHECKLIST_ITEMS_PER_AREA = 10; 

interface AreaComplianceData {
  predefinedArea: PredefinedSurveillanceArea;
  logItemStatus?: SurveillanceLogStatus;
  lastLogUpdate?: string;
  cpArea?: number;
  openFindingsCount: number;
  ncpOpen: number;
  ncfOpen: number;
  nadOpen: number;
  isActive: boolean; // Renamed from 'inspected' for clarity
}

interface CategorySummaryData {
  category: SurveillanceLogCategory;
  areas: AreaComplianceData[];
  aggregatedCp?: number;
  activeAreasCount: number;
  totalCount: number;
}

const calculateAreaCp = (
  area: PredefinedSurveillanceArea,
  logs: SurveillanceLogItem[] = [],
  findings: SurveillanceFinding[] = []
): AreaComplianceData => {
  const logItem = logs.find(log => log.predefinedAreaId === area.id);
  const relevantOpenFindings = findings.filter(f => f.predefinedAreaId === area.id && !f.isCompleted);
  const hasOpenFindingsForArea = relevantOpenFindings.length > 0;

  const isLogicallyDone = logItem?.status === 'Done';
  const isActive = isLogicallyDone || hasOpenFindingsForArea;

  let cpArea: number | undefined = undefined;
  let openFindingsCount = 0;
  let ncpOpen = 0;
  let ncfOpen = 0;
  let nadOpen = 0;

  if (isActive) { 
    openFindingsCount = relevantOpenFindings.length;
    
    relevantOpenFindings.forEach(f => {
      if (f.findingCategory === FindingCategoryLevel.LEVEL_1) ncpOpen++;
      else if (f.findingCategory === FindingCategoryLevel.LEVEL_2) ncfOpen++;
      else if (f.findingCategory === FindingCategoryLevel.LEVEL_3) nadOpen++;
    });

    if (hasOpenFindingsForArea) {
        const Mf_area = (ncpOpen * RBS_COMPLIANCE_FINDING_WEIGHTS.ncp) +
                        (ncfOpen * RBS_COMPLIANCE_FINDING_WEIGHTS.ncf) +
                        (nadOpen * RBS_COMPLIANCE_FINDING_WEIGHTS.nad);
        
        const Xc_area = N_CHECKLIST_ITEMS_PER_AREA > 0 ? Mf_area / N_CHECKLIST_ITEMS_PER_AREA : Mf_area > 0 ? 1 : 0;
        cpArea = Math.max(0, Math.min(1, 1 - Xc_area));
    } else if (isLogicallyDone) { // No open findings, but log status is 'Done'
        cpArea = 1.0;
    }
  }

  return {
    predefinedArea: area,
    logItemStatus: logItem?.status,
    lastLogUpdate: logItem?.lastUpdated,
    cpArea,
    openFindingsCount,
    ncpOpen,
    ncfOpen,
    nadOpen,
    isActive, 
  };
};

const getCpColorAndText = (cpScore?: number, isActive?: boolean, isCategorySummary: boolean = false): { bgColor: string, textColor: string, textValue: string } => {
  if (!isActive) {
    return { bgColor: 'bg-slate-200', textColor: 'text-slate-500', textValue: isCategorySummary ? 'N/A' : 'N/I' };
  }
  if (cpScore === undefined) { 
    // This case should ideally not happen if isActive is true, means it's 'Done' with no findings (Cp=1) or has findings (Cp calculated)
    return { bgColor: 'bg-slate-300', textColor: 'text-slate-600', textValue: 'Error' };
  }

  const valueStr = cpScore.toFixed(2);
  if (cpScore >= 0.99) return { bgColor: 'bg-green-700', textColor: 'text-white', textValue: valueStr };
  if (cpScore >= 0.8) return { bgColor: 'bg-green-500', textColor: 'text-white', textValue: valueStr };
  if (cpScore >= 0.6) return { bgColor: 'bg-yellow-400', textColor: 'text-slate-800', textValue: valueStr };
  if (cpScore >= 0.4) return { bgColor: 'bg-orange-500', textColor: 'text-white', textValue: valueStr };
  return { bgColor: 'bg-red-600', textColor: 'text-white', textValue: valueStr };
};

const HeatmapLegend: React.FC = () => (
  <div className="mt-6 p-2 border border-slate-200 rounded-md bg-slate-50">
    <h5 className="text-sm font-semibold text-slate-700 mb-2">Legend (C(p) Score):</h5>
    <div className="flex flex-wrap gap-x-3 gap-y-1 text-xs">
      <div className="flex items-center"><span className="h-3 w-3 rounded-sm mr-1.5 bg-green-700"></span> Excellent (0.99-1.00)</div>
      <div className="flex items-center"><span className="h-3 w-3 rounded-sm mr-1.5 bg-green-500"></span> Good (0.80-0.98)</div>
      <div className="flex items-center"><span className="h-3 w-3 rounded-sm mr-1.5 bg-yellow-400"></span> Fair (0.60-0.79)</div>
      <div className="flex items-center"><span className="h-3 w-3 rounded-sm mr-1.5 bg-orange-500"></span> Poor (0.40-0.59)</div>
      <div className="flex items-center"><span className="h-3 w-3 rounded-sm mr-1.5 bg-red-600"></span> Critical (&lt;0.40)</div>
      <div className="flex items-center"><span className="h-3 w-3 rounded-sm mr-1.5 bg-slate-200"></span> N/I (Not Active)</div>
    </div>
     <p className="text-xs text-slate-500 mt-2">
        Note: C(p) for individual areas is calculated assuming {N_CHECKLIST_ITEMS_PER_AREA} checklist items for normalization if open findings exist.
        An area is "Active" if its Surveillance Log status is 'Done' OR it has open findings. If 'Done' with no open findings, C(p) = 1.00.
        Category C(p) is the average C(p) of its active areas.
      </p>
  </div>
);

export const SurveillanceComplianceHeatmap: React.FC<SurveillanceComplianceHeatmapProps> = ({ operator, onCellClick }) => {
  const [expandedCategory, setExpandedCategory] = useState<SurveillanceLogCategory | null>(null);

  const categorySummaries = useMemo((): CategorySummaryData[] => {
    return Object.values(SurveillanceLogCategory).map(catEnum => {
      const areasForThisCat = PREDEFINED_SURVEILLANCE_AREAS.filter(pa => pa.category === catEnum);
      
      if (areasForThisCat.length === 0) {
          return { category: catEnum, areas: [], totalCount: 0, activeAreasCount: 0, aggregatedCp: undefined };
      }

      const areaDetails = areasForThisCat
        .map(area => calculateAreaCp(area, operator.surveillanceLogs, operator.surveillanceFindings))
        .sort((a,b) => 
            a.predefinedArea.itemNumber.localeCompare(b.predefinedArea.itemNumber, undefined, { numeric: true, sensitivity: 'base' })
        );
      
      const activeAreas = areaDetails.filter(a => a.isActive); 
      let aggCp: number | undefined = undefined;
      if (activeAreas.length > 0) {
        const sumCp = activeAreas.reduce((sum, areaData) => sum + (areaData.cpArea ?? 0), 0);
        aggCp = sumCp / activeAreas.length;
      }
      
      return {
        category: catEnum,
        areas: areaDetails,
        aggregatedCp: aggCp,
        activeAreasCount: activeAreas.length,
        totalCount: areasForThisCat.length
      };
    }).filter(summary => summary.totalCount > 0); 
  }, [operator.surveillanceLogs, operator.surveillanceFindings]);

  const handleCategoryToggle = (category: SurveillanceLogCategory) => {
    setExpandedCategory(prev => (prev === category ? null : category));
  };
  
  const handleCategoryFindingsClick = (e: React.MouseEvent, summary: CategorySummaryData) => {
    e.stopPropagation(); // Prevent toggling expansion
    const allFindingsForCategory = operator.surveillanceFindings?.filter(f => f.surveillanceLogCategoryId === summary.category) || [];

    if (allFindingsForCategory.length === 0) {
      toast('No findings for this category.');
      return;
    }
    onCellClick(allFindingsForCategory, `All Findings for: ${summary.category}`);
  };

  const handleAreaClick = (areaData: AreaComplianceData) => {
    const findingsForArea = operator.surveillanceFindings?.filter(f => f.predefinedAreaId === areaData.predefinedArea.id) || [];
    if (findingsForArea.length === 0) {
      toast.error('No findings recorded for this specific area.');
      return;
    }
    onCellClick(findingsForArea, `Findings for Area ${areaData.predefinedArea.itemNumber}: ${areaData.predefinedArea.areaDescription}`);
  };

  return (
    <div className="bg-white shadow-xl rounded-xl p-6">
      <h3 className="text-xl font-semibold text-slate-700 mb-4 flex items-center">
        <TableCellsIcon className="h-6 w-6 mr-2 text-brand-primary" />
        Surveillance Area Compliance
      </h3>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {categorySummaries.map(summary => {
          const { bgColor, textColor } = getCpColorAndText(summary.aggregatedCp, summary.activeAreasCount > 0, true);
          const isExpanded = expandedCategory === summary.category;
          return (
            <div
              key={summary.category}
              onClick={() => handleCategoryToggle(summary.category)}
              className={`p-3 rounded-lg shadow-md flex flex-col justify-between cursor-pointer transition-all hover:shadow-lg ${bgColor} ${textColor} ${isExpanded ? 'ring-2 ring-brand-primary' : ''}`}
              style={{ minHeight: '112px' }} 
            >
              <div>
                <h4 className="font-semibold text-sm mb-1 flex justify-between items-center">
                  <span className="flex-grow pr-2">{summary.category.replace(' Surveillance Area', '').replace(' System (SMS) Surveillance', ' SMS').replace(' System (QMS) Surveillance', ' QMS')}</span>
                  <span className="flex-shrink-0 flex items-center">
                    <button onClick={(e) => handleCategoryFindingsClick(e, summary)} title="View all findings for this category" className="p-1 hover:bg-black/10 rounded-full"><ListBulletIcon className="h-3.5 w-3.5"/></button>
                    <span className="p-1">{isExpanded ? <ChevronUpIcon className="h-3.5 w-3.5"/> : <ChevronDownIcon className="h-3.5 w-3.5"/>}</span>
                  </span>
                </h4>
                <p className="text-xs">
                  {summary.activeAreasCount} / {summary.totalCount} Areas Active
                </p>
              </div>
              <p className="text-lg font-bold mt-1">
                Avg. C(p): {summary.aggregatedCp !== undefined ? summary.aggregatedCp.toFixed(2) : 'N/A'}
              </p>
            </div>
          );
        })}
      </div>

      {expandedCategory && (
        <div className="mt-6 p-4 border border-slate-200 rounded-lg bg-slate-50">
          <h4 className="text-md font-semibold text-slate-700 mb-3 border-b pb-2">
            Details for: {expandedCategory}
          </h4>
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-7 gap-2">
            {categorySummaries.find(s => s.category === expandedCategory)?.areas.map(data => {
              const { bgColor: cellBgColor, textColor: cellTextColor, textValue: cellTextValue } = getCpColorAndText(data.cpArea, data.isActive);
              let tooltipText = `Area: ${data.predefinedArea.areaDescription}\nItem No: ${data.predefinedArea.itemNumber}\nForm: ${data.predefinedArea.defaultFormNumber || 'N/A'}`;
              if (data.isActive) { 
                tooltipText += `\nStatus: Active (Log: ${data.logItemStatus || 'N/A'}, Cp: ${data.cpArea?.toFixed(2) ?? 'N/A'})`;
                tooltipText += `\nOpen Findings: ${data.openFindingsCount} (L1: ${data.ncpOpen}, L2: ${data.ncfOpen}, L3: ${data.nadOpen})`;
                if(data.lastLogUpdate) tooltipText += `\nLog Updated: ${new Date(data.lastLogUpdate).toLocaleDateString()}`
              } else {
                tooltipText += `\nStatus: Not Active (Log: ${data.logItemStatus || 'N/A'}, No Open Findings)`;
              }
              const borderClass = cellTextColor === 'text-white' ? 'border-white/30' : 'border-slate-400/50';

              return (
                <div
                  key={data.predefinedArea.id}
                  title={tooltipText}
                  onClick={() => handleAreaClick(data)}
                  className={`p-1.5 rounded-md shadow ${cellBgColor} ${cellTextColor} flex flex-col justify-between h-16 min-w-[96px] text-left transition-all hover:ring-2 hover:ring-brand-primary cursor-pointer`}
                >
                  <p 
                    className="text-[10px] leading-snug font-medium flex-grow overflow-hidden" 
                    style={{ display: '-webkit-box', WebkitBoxOrient: 'vertical', WebkitLineClamp: 2 }}
                  >
                    {data.predefinedArea.areaDescription}
                  </p>
                  <div className={`flex justify-between items-baseline w-full text-[9px] mt-1 pt-0.5 border-t ${borderClass}`}> 
                    <span className="font-normal">{data.predefinedArea.itemNumber}</span>
                    <span className="font-semibold">{cellTextValue}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
      <HeatmapLegend />
    </div>
  );
};
